// 배포 버전 — OAuth 기반으로 동작. 이 파일은 빈 상태로 유지.
// importScripts 실패 방지용 placeholder.
