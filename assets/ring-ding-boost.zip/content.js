// NotionAI Ring Ding Done v0.5
// - Notion AI 응답 stream 종료 감지 → 선택한 사운드 재생
// - 요청 body + 응답 전체 텍스트 캡처 → bridge.js 로 postMessage
//   → bridge → background.js → Slack Webhook + Notion API 적재
// 설정은 popup → chrome.storage.sync → bridge → window.postMessage 로 전달.

(function () {
  const TAG = '[RingDingDone]';
  const TARGET_ENDPOINT = 'runInferenceTranscript';
  const COOLDOWN_MS = 2000;
  const MSG_SOURCE = 'notion-ai-bot';

  const SOUNDS = (typeof NOTION_AI_BOT_SOUNDS !== 'undefined') ? NOTION_AI_BOT_SOUNDS : {};

  let currentSound = 'ding';
  let volume = 1.0;

  let audioCtx = null;
  let lastPlayAt = 0;

  function getAudioCtx() {
    if (!audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      audioCtx = new AC();
    }
    if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    return audioCtx;
  }

  function playSound(name) {
    const sound = SOUNDS[name] || SOUNDS.ding;
    if (!sound || volume <= 0) return;
    try {
      const ctx = getAudioCtx();
      if (!ctx) return;
      const t0 = ctx.currentTime;
      for (const n of sound.notes) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = n.type || 'sine';
        osc.frequency.value = n.freq;
        const peak = Math.max(0.0001, n.vol * volume);
        gain.gain.setValueAtTime(0, t0 + n.start);
        gain.gain.linearRampToValueAtTime(peak, t0 + n.start + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0008, t0 + n.start + n.dur);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t0 + n.start);
        osc.stop(t0 + n.start + n.dur + 0.05);
      }
    } catch (e) {
      console.warn(`${TAG} audio failed`, e);
    }
  }

  function playWithCooldown() {
    const now = Date.now();
    if (now - lastPlayAt < COOLDOWN_MS) return;
    lastPlayAt = now;
    playSound(currentSound);
    console.log(`${TAG} 🔔 ${currentSound} @ ${Math.round(volume * 100)}%`);
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    const data = e.data;
    if (!data || data.source !== MSG_SOURCE) return;

    if (data.type === 'config-update' && data.config) {
      if (data.config.sound && SOUNDS[data.config.sound]) {
        currentSound = data.config.sound;
      }
      if (typeof data.config.volume === 'number' && isFinite(data.config.volume)) {
        volume = Math.max(0, Math.min(1.5, data.config.volume));
      }
    } else if (data.type === 'preview' && data.sound) {
      const prevVol = volume;
      if (typeof data.volume === 'number') volume = Math.max(0, Math.min(1.5, data.volume));
      playSound(data.sound);
      volume = prevVol;
    }
  });

  window.postMessage({ source: MSG_SOURCE, type: 'request-config' }, '*');

  function getUrl(input) {
    if (typeof input === 'string') return input;
    if (input && typeof input.url === 'string') return input.url;
    try { return String(input); } catch { return ''; }
  }

  async function extractRequestBody(input, init) {
    try {
      if (init && init.body != null) {
        const b = init.body;
        if (typeof b === 'string') return b;
        if (b instanceof Blob) return await b.text();
        if (b instanceof ArrayBuffer) return new TextDecoder().decode(new Uint8Array(b));
        if (ArrayBuffer.isView(b)) return new TextDecoder().decode(b);
        if (b instanceof URLSearchParams) return b.toString();
        if (b instanceof FormData) {
          const obj = {};
          for (const [k, v] of b.entries()) obj[k] = typeof v === 'string' ? v : '[file]';
          return JSON.stringify(obj);
        }
        // ReadableStream 은 소비하면 원본이 깨짐 → 스킵
      }
      if (typeof Request !== 'undefined' && input instanceof Request) {
        try { return await input.clone().text(); } catch {}
      }
    } catch {}
    return '';
  }

  function toKSTISO(date) {
    const d = new Date(date.getTime() + 9 * 60 * 60 * 1000);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}+09:00`;
  }

  // 노션 URL 에서 채팅 세션 ID(?t=...) + base URL(파라미터 제외) 추출.
  // 같은 문서 내 여러 세션을 구분하는 핵심 키. 없으면 sessionId=null.
  function extractNotionSessionInfo(fullUrl) {
    try {
      const u = new URL(fullUrl);
      const sessionId = u.searchParams.get('t') || null;
      const baseUrl = `${u.origin}${u.pathname}`;
      return { sessionId, baseUrl };
    } catch {
      return { sessionId: null, baseUrl: fullUrl };
    }
  }

  const origFetch = window.fetch.bind(window);
  window.fetch = async function (input, init) {
    const url = getUrl(input);
    if (!url.includes(TARGET_ENDPOINT)) return origFetch(input, init);

    console.log(`${TAG} AI 요청 감지`);
    const startedAt = Date.now();
    const startedAtIso = toKSTISO(new Date(startedAt));
    const requestBody = await extractRequestBody(input, init);

    const response = await origFetch(input, init);

    try {
      const clone = response.clone();
      const reader = clone.body && clone.body.getReader ? clone.body.getReader() : null;
      if (reader) {
        (async () => {
          const decoder = new TextDecoder();
          let rawText = '';
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              if (value) rawText += decoder.decode(value, { stream: true });
            }
            rawText += decoder.decode();
          } catch (e) {
            console.warn(`${TAG} stream read failed`, e);
          }

          console.log(`${TAG} AI 완료 ✓ (${rawText.length.toLocaleString()}B)`);
          playWithCooldown();

          const durationSec = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
          const fullUrl = window.location.href;
          const { sessionId, baseUrl } = extractNotionSessionInfo(fullUrl);
          // 실제 세션 ID 캐시 — URL 이 ?t=new 로 남아있는 경우 popup 이 여기 값을 사용
          if (sessionId && sessionId !== 'new') {
            try { localStorage.setItem('rdb_last_session_id', sessionId); } catch {}
          }
          try {
            window.postMessage({
              source: MSG_SOURCE,
              type: 'log-turn',
              payload: {
                requestBody,
                responseText: rawText,
                url: fullUrl,
                baseUrl,
                sessionId,
                pageTitle: document.title || '',
                durationSec,
                startedAtIso,
              },
            }, '*');
          } catch (e) {
            console.warn(`${TAG} postMessage log-turn failed`, e);
          }
        })();
      }
    } catch {}

    return response;
  };

  // ── 메모리 감시 ─────────────────────────────────────────────────
  // 5초마다 performance.memory 측정 → bridge → background 로 forward
  // background 가 배지 색/텍스트 업데이트
  if (performance && performance.memory) {
    setInterval(() => {
      try {
        const m = performance.memory;
        window.postMessage({
          source: MSG_SOURCE,
          type: 'mem-stat',
          mb: Math.round(m.usedJSHeapSize / 1048576),
          limitMb: Math.round(m.jsHeapSizeLimit / 1048576),
        }, '*');
      } catch {}
    }, 5000);
  }

  // ── AI composer 찾기 + pending prompt 자동 주입 ─────────────────
  function findAIComposer() {
    // 노션 페이지엔 같은 placeholder 의 composer 가 여러 개 있음:
    //   - 페이지 본문에 임베드된 AI 블록 (DOMLock 적용, 편집 불가) — 보통 DOM 앞쪽
    //   - 실제 플로팅 AI 채팅 입력창 (편집 가능) — 보통 DOM 마지막
    // 마지막 것 선택이 진짜 입력창.
    const all = document.querySelectorAll(
      'div[contenteditable="true"][placeholder^="AI로"]',
    );
    if (all.length > 0) return all[all.length - 1];
    // 폴백
    const fallback = document.querySelectorAll(
      'div[data-content-editable-leaf="true"][contenteditable="true"][aria-multiline="true"][role="textbox"][placeholder]',
    );
    return fallback[fallback.length - 1] || null;
  }

  async function waitForAIComposer(timeoutMs = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const el = findAIComposer();
      if (el) return el;
      await new Promise((r) => setTimeout(r, 200));
    }
    return null;
  }

  function insertIntoComposer(el, text) {
    el.focus();
    try {
      const ok = document.execCommand('insertText', false, text);
      if (ok) return true;
    } catch {}
    try {
      el.textContent = text;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    } catch {}
    return false;
  }

  async function tryInjectPendingPrompt() {
    if (!/[?&]t=new\b/.test(location.search)) return;
    let pending;
    try { pending = sessionStorage.getItem('rdd-pending-prompt'); } catch { return; }
    if (!pending) return;

    console.log(`${TAG} pending prompt 감지 — AI composer 대기`);
    const composer = await waitForAIComposer(20000);
    if (!composer) {
      console.warn(`${TAG} AI composer 못 찾음 — 주입 실패`);
      return;
    }
    try { sessionStorage.removeItem('rdd-pending-prompt'); } catch {}
    const ok = insertIntoComposer(composer, pending);
    console.log(`${TAG} 프롬프트 주입 ${ok ? '성공' : '실패'} (${pending.length}B)`);

    // 전송 버튼 클릭 (aria-label="AI 메시지 제출하기")
    await new Promise((r) => setTimeout(r, 500));
    const sendBtn = document.querySelector('button[aria-label="AI 메시지 제출하기"]');
    if (sendBtn) {
      const isDisabled = sendBtn.disabled || sendBtn.getAttribute('aria-disabled') === 'true';
      console.log(`${TAG} 전송 버튼 발견. disabled=${isDisabled}`);
      if (!isDisabled) {
        sendBtn.click();
        console.log(`${TAG} 전송 버튼 클릭`);
      }
    } else {
      console.warn(`${TAG} 전송 버튼 못 찾음`);
    }
  }

  tryInjectPendingPrompt();

  window.__notionAIBot = {
    version: '0.7.0',
    current() { return { sound: currentSound, volume }; },
    list() {
      console.log(`${TAG} 사용 가능한 사운드:`);
      console.table(
        Object.entries(SOUNDS).map(([k, v]) => ({
          key: k,
          label: v.label,
          active: k === currentSound ? '★' : '',
        }))
      );
    },
    preview(name) {
      if (!SOUNDS[name]) {
        console.warn(`${TAG} 없는 사운드: ${name}. __notionAIBot.list() 로 확인`);
        return;
      }
      playSound(name);
    },
  };

  console.log(`${TAG} v0.7.0 installed. sound=${currentSound}, volume=${volume}. 익스텐션 아이콘으로 설정 변경`);
})();
