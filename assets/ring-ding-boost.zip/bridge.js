// NotionAI Ring Ding Done — ISOLATED world bridge
// chrome.storage.sync ↔ MAIN world(content.js) 를 window.postMessage 로 연결
// + content.js 에서 log-turn 메시지 오면 service worker(background.js) 로 포워딩
// webhook/token/dbId 는 extension/config.js 에 하드코딩. 여기서는 로그 ON/OFF 만 본다.

(function () {
  const MSG_SOURCE = 'notion-ai-bot';
  const DEFAULTS = {
    sound: 'ding',
    volume: 1.0,
    logEnabled: true,
  };

  function isContextAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch { return false; }
  }

  function postConfig(config) {
    window.postMessage({ source: MSG_SOURCE, type: 'config-update', config }, '*');
  }

  function pushCurrentConfig() {
    if (!isContextAlive()) { console.warn('[RingDingDone bridge] context invalidated, 노션 탭 새로고침 필요'); return; }
    try {
      chrome.storage.sync.get(DEFAULTS, (cfg) => {
        if (chrome.runtime.lastError) { console.warn('[RingDingDone bridge] storage get failed', chrome.runtime.lastError.message); return; }
        postConfig({ sound: cfg.sound, volume: cfg.volume });
      });
    } catch (e) {
      console.warn('[RingDingDone bridge] storage get threw', e.message);
    }
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    const data = e.data;
    if (!data || data.source !== MSG_SOURCE) return;

    if (data.type === 'request-config') {
      pushCurrentConfig();
    } else if (data.type === 'mem-stat') {
      if (!isContextAlive()) return;
      try {
        chrome.runtime.sendMessage({
          source: MSG_SOURCE,
          type: 'mem-stat',
          mb: data.mb,
          limitMb: data.limitMb,
        });
      } catch {}
    } else if (data.type === 'log-turn') {
      console.log('[RingDingDone bridge] log-turn received, size=', (data.payload?.responseText || '').length);
      if (!isContextAlive()) {
        console.warn('[RingDingDone bridge] context invalidated — 노션 탭 F5로 새로고침해야 로그 적재 재개됨');
        return;
      }
      try {
        chrome.storage.sync.get(DEFAULTS, (cfg) => {
          if (chrome.runtime.lastError) {
            console.warn('[RingDingDone bridge] storage get failed', chrome.runtime.lastError.message);
            return;
          }
          if (!cfg.logEnabled) { console.log('[RingDingDone bridge] logEnabled=false, skip'); return; }
          chrome.runtime.sendMessage({
            source: MSG_SOURCE,
            type: 'log-turn',
            payload: data.payload,
            // config 는 비워서 보냄 → background 가 config.js 의 값 사용
            config: {},
          }, (resp) => {
            if (chrome.runtime.lastError) {
              console.warn('[RingDingDone bridge] sendMessage failed', chrome.runtime.lastError.message);
            } else if (resp && !resp.ok) {
              console.warn('[RingDingDone bridge] background error', resp.error);
            } else {
              console.log('[RingDingDone bridge] background responded', resp);
            }
          });
        });
      } catch (e) {
        console.warn('[RingDingDone bridge] sendMessage threw', e.message);
      }
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    const partial = {};
    if (changes.sound) partial.sound = changes.sound.newValue;
    if (changes.volume) partial.volume = changes.volume.newValue;
    if (Object.keys(partial).length) postConfig(partial);
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.source !== MSG_SOURCE) return;
    if (msg.type === 'preview') {
      window.postMessage({
        source: MSG_SOURCE,
        type: 'preview',
        sound: msg.sound,
        volume: msg.volume,
      }, '*');
    }
  });

  pushCurrentConfig();
})();
