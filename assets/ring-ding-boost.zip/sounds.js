var NOTION_AI_BOT_SOUNDS = {
  ding: {
    label: '디링~ (기본)',
    notes: [
      { freq: 880,  start: 0.00, dur: 0.18, vol: 0.22, type: 'sine' },
      { freq: 1174, start: 0.10, dur: 0.45, vol: 0.22, type: 'sine' },
    ],
  },
  chime: {
    label: '차임 (3음 도미솔)',
    notes: [
      { freq: 1047, start: 0.00, dur: 0.60, vol: 0.20, type: 'sine' },
      { freq: 1319, start: 0.08, dur: 0.60, vol: 0.20, type: 'sine' },
      { freq: 1568, start: 0.16, dur: 0.60, vol: 0.20, type: 'sine' },
    ],
  },
  bell: {
    label: '벨 (묵직한 종)',
    notes: [
      { freq: 800,  start: 0.00, dur: 0.90, vol: 0.22, type: 'triangle' },
      { freq: 2400, start: 0.00, dur: 0.25, vol: 0.08, type: 'sine' },
    ],
  },
  coin: {
    label: '코인 (8비트 게임)',
    notes: [
      { freq: 988,  start: 0.00, dur: 0.08, vol: 0.18, type: 'square' },
      { freq: 1319, start: 0.08, dur: 0.30, vol: 0.18, type: 'square' },
    ],
  },
  pop: {
    label: '뿅 (귀여운)',
    notes: [
      { freq: 500,  start: 0.00, dur: 0.05, vol: 0.22, type: 'triangle' },
      { freq: 1200, start: 0.04, dur: 0.10, vol: 0.25, type: 'triangle' },
      { freq: 1600, start: 0.10, dur: 0.12, vol: 0.20, type: 'sine' },
    ],
  },
  success: {
    label: '성공 (상승 3음)',
    notes: [
      { freq: 784,  start: 0.00, dur: 0.12, vol: 0.22, type: 'sine' },
      { freq: 988,  start: 0.10, dur: 0.12, vol: 0.22, type: 'sine' },
      { freq: 1319, start: 0.20, dur: 0.30, vol: 0.22, type: 'sine' },
    ],
  },
  marimba: {
    label: '마림바 (부드러움)',
    notes: [
      { freq: 698, start: 0.00, dur: 0.50, vol: 0.24, type: 'triangle' },
      { freq: 880, start: 0.08, dur: 0.50, vol: 0.24, type: 'triangle' },
    ],
  },
  woodblock: {
    label: '나무 (짧고 담백)',
    notes: [
      { freq: 1500, start: 0.00, dur: 0.06, vol: 0.22, type: 'triangle' },
      { freq: 800,  start: 0.00, dur: 0.10, vol: 0.15, type: 'sine' },
    ],
  },

  /* ───── 프리미엄 톤 (v0.4) ───── */

  celeste: {
    label: '셀레스트 (Cmaj7 하프)',
    notes: [
      { freq: 523,  start: 0.00, dur: 1.60, vol: 0.18, type: 'sine' },
      { freq: 659,  start: 0.08, dur: 1.50, vol: 0.18, type: 'sine' },
      { freq: 784,  start: 0.16, dur: 1.40, vol: 0.18, type: 'sine' },
      { freq: 988,  start: 0.24, dur: 1.30, vol: 0.18, type: 'sine' },
      { freq: 1047, start: 0.00, dur: 1.60, vol: 0.05, type: 'sine' },
      { freq: 1976, start: 0.24, dur: 1.00, vol: 0.03, type: 'sine' },
    ],
  },

  crystal: {
    label: '크리스탈 (고역 샤이머)',
    notes: [
      { freq: 1760, start: 0.00, dur: 0.80, vol: 0.14, type: 'sine' },
      { freq: 2637, start: 0.00, dur: 0.60, vol: 0.06, type: 'sine' },
      { freq: 2093, start: 0.10, dur: 0.75, vol: 0.12, type: 'sine' },
      { freq: 3136, start: 0.10, dur: 0.50, vol: 0.04, type: 'sine' },
      { freq: 2349, start: 0.22, dur: 0.80, vol: 0.10, type: 'sine' },
    ],
  },

  zenGong: {
    label: '젠 공 (깊은 여운)',
    notes: [
      { freq: 110,  start: 0.00, dur: 2.20, vol: 0.22, type: 'sine' },
      { freq: 220,  start: 0.00, dur: 2.00, vol: 0.16, type: 'sine' },
      { freq: 330,  start: 0.04, dur: 1.80, vol: 0.10, type: 'triangle' },
      { freq: 660,  start: 0.08, dur: 1.20, vol: 0.05, type: 'sine' },
      { freq: 1320, start: 0.12, dur: 0.80, vol: 0.03, type: 'sine' },
    ],
  },

  lofiKeys: {
    label: '로파이 (따뜻한 건반)',
    notes: [
      { freq: 349,  start: 0.00, dur: 1.00, vol: 0.22, type: 'triangle' },
      { freq: 440,  start: 0.12, dur: 1.10, vol: 0.22, type: 'triangle' },
      { freq: 698,  start: 0.00, dur: 0.90, vol: 0.07, type: 'sine' },
      { freq: 880,  start: 0.12, dur: 1.00, vol: 0.07, type: 'sine' },
      { freq: 175,  start: 0.00, dur: 1.20, vol: 0.10, type: 'sine' },
    ],
  },

  aurora: {
    label: '오로라 (부드러운 상승)',
    notes: [
      { freq: 523,  start: 0.00, dur: 0.55, vol: 0.18, type: 'sine' },
      { freq: 659,  start: 0.10, dur: 0.60, vol: 0.18, type: 'sine' },
      { freq: 784,  start: 0.20, dur: 0.70, vol: 0.20, type: 'sine' },
      { freq: 880,  start: 0.30, dur: 0.80, vol: 0.20, type: 'sine' },
      { freq: 1047, start: 0.40, dur: 1.10, vol: 0.22, type: 'sine' },
      { freq: 2093, start: 0.40, dur: 0.90, vol: 0.04, type: 'sine' },
    ],
  },

  velvet: {
    label: '벨벳 (따뜻한 저음)',
    notes: [
      { freq: 220,  start: 0.00, dur: 1.30, vol: 0.24, type: 'triangle' },
      { freq: 277,  start: 0.06, dur: 1.25, vol: 0.20, type: 'triangle' },
      { freq: 330,  start: 0.12, dur: 1.20, vol: 0.20, type: 'triangle' },
      { freq: 440,  start: 0.00, dur: 1.20, vol: 0.07, type: 'sine' },
      { freq: 554,  start: 0.12, dur: 1.10, vol: 0.05, type: 'sine' },
    ],
  },

  twinkle: {
    label: '트윙클 (반짝이는 아르페지오)',
    notes: [
      { freq: 1047, start: 0.00, dur: 0.18, vol: 0.18, type: 'sine' },
      { freq: 1319, start: 0.08, dur: 0.22, vol: 0.18, type: 'sine' },
      { freq: 1568, start: 0.16, dur: 0.26, vol: 0.20, type: 'sine' },
      { freq: 2093, start: 0.24, dur: 0.55, vol: 0.20, type: 'sine' },
      { freq: 3136, start: 0.24, dur: 0.40, vol: 0.05, type: 'sine' },
    ],
  },

  ocean: {
    label: '오션 (깊은 저음)',
    notes: [
      { freq: 174,  start: 0.00, dur: 1.90, vol: 0.22, type: 'sine' },
      { freq: 261,  start: 0.08, dur: 1.70, vol: 0.14, type: 'sine' },
      { freq: 349,  start: 0.14, dur: 1.55, vol: 0.10, type: 'sine' },
      { freq: 523,  start: 0.20, dur: 1.40, vol: 0.06, type: 'sine' },
      { freq: 87,   start: 0.00, dur: 2.00, vol: 0.12, type: 'sine' },
    ],
  },

  moonlight: {
    label: '문라이트 (몽환 Dm7)',
    notes: [
      { freq: 587,  start: 0.00, dur: 1.50, vol: 0.18, type: 'sine' },
      { freq: 698,  start: 0.10, dur: 1.45, vol: 0.18, type: 'sine' },
      { freq: 880,  start: 0.20, dur: 1.40, vol: 0.18, type: 'sine' },
      { freq: 1047, start: 0.30, dur: 1.30, vol: 0.18, type: 'sine' },
      { freq: 293,  start: 0.00, dur: 1.50, vol: 0.08, type: 'triangle' },
    ],
  },

  etheric: {
    label: '이서릭 (오픈 5도)',
    notes: [
      { freq: 392,  start: 0.00, dur: 1.50, vol: 0.20, type: 'sine' },
      { freq: 587,  start: 0.08, dur: 1.45, vol: 0.20, type: 'sine' },
      { freq: 784,  start: 0.18, dur: 1.30, vol: 0.18, type: 'sine' },
      { freq: 1175, start: 0.28, dur: 1.10, vol: 0.08, type: 'sine' },
      { freq: 1568, start: 0.28, dur: 0.90, vol: 0.05, type: 'sine' },
    ],
  },
};
