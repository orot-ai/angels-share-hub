// NotionAI Ring Ding Done — service worker
// content.js(MAIN) → bridge.js(ISOLATED) → 여기로 log-turn 메시지 도착
// Notion API 호출 (host_permissions 로 CORS 우회). 배포 버전 — Slack 기능 없음.

const TAG = '[RingDingDone bg]';
const MSG_SOURCE = 'notion-ai-bot';
const NOTION_VERSION = '2022-06-28';

// config.js 는 개발자용 fallback. gitignored. 없어도 OK.
// 프로덕션에선 미시소 OAuth 로 받은 token + dbId 를 chrome.storage.local 에 저장해 사용.
try { importScripts('config.js'); } catch (e) { /* OAuth 로 토큰 얻으면 무시 가능 */ }
const CONFIG = (self.NOTION_AI_BOT_CONFIG || { notionToken: '', notionDbId: '' });

// 미시소 OAuth 토큰 프록시 주소. 로컬 개발 시 localhost 로 전환됨 (아래 함수).
const MISISO_TOKEN_URL_PROD = 'https://misiso.com/api/notion/oauth/token';
const MISISO_TOKEN_URL_DEV = 'http://localhost:3000/api/notion/oauth/token';

// 토큰 캐시 TTL (재fetch 간격). 기본 10분. 401 나면 즉시 재fetch.
const TOKEN_CACHE_TTL_MS = 10 * 60 * 1000;

async function fetchMisisoToken() {
  // 프로덕션 우선 시도, 실패 시 로컬 dev 서버 fallback (미리 개발 환경 대응).
  // 404 는 두 종류:
  //   (a) 라우트 자체가 없음 (프로덕션 미배포) → HTML 응답 → 다음 URL 시도
  //   (b) 라우트 있지만 해당 유저의 연결 레코드 없음 → JSON 응답 → not-connected
  let lastAuthFailure = null;
  for (const url of [MISISO_TOKEN_URL_PROD, MISISO_TOKEN_URL_DEV]) {
    try {
      const res = await fetch(url, { credentials: 'include', cache: 'no-store' });
      const contentType = res.headers.get('content-type') || '';
      const isJson = contentType.includes('application/json');

      if (res.status === 401 && isJson) {
        lastAuthFailure = 'login-required';
        continue;
      }
      if (res.status === 404 && isJson) {
        lastAuthFailure = 'not-connected';
        continue;
      }
      if (!res.ok) continue; // 라우트 없음/기타 에러 → 다음 URL

      const data = await res.json();
      if (!data.token) continue;
      return {
        ok: true,
        token: data.token,
        dbId: data.database_id || '',
        workspaceName: data.workspace_name || '',
        origin: url,
      };
    } catch {
      // 네트워크 실패 → 다음 URL 로 continue
    }
  }
  return { ok: false, reason: lastAuthFailure || 'network' };
}

async function getCachedAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['rdb_token', 'rdb_db_id', 'rdb_workspace', 'rdb_fetched_at'], (v) => resolve(v || {}));
  });
}

async function setCachedAuth(token, dbId, workspaceName) {
  return new Promise((resolve) => {
    chrome.storage.local.set({
      rdb_token: token,
      rdb_db_id: dbId,
      rdb_workspace: workspaceName,
      rdb_fetched_at: Date.now(),
    }, resolve);
  });
}

async function clearCachedAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(['rdb_token', 'rdb_db_id', 'rdb_workspace', 'rdb_fetched_at'], resolve);
  });
}

// 현재 사용할 auth 정보 조회. 우선순위:
// 1) chrome.storage 캐시 (TTL 유효)
// 2) 미시소 토큰 프록시 fetch → 성공 시 캐시
// 3) config.js fallback (개발자 수동 입력)
async function resolveAuth({ forceRefresh = false } = {}) {
  if (!forceRefresh) {
    const cached = await getCachedAuth();
    const fresh = cached.rdb_fetched_at && (Date.now() - cached.rdb_fetched_at) < TOKEN_CACHE_TTL_MS;
    if (fresh && cached.rdb_token) {
      return { source: 'cache', token: cached.rdb_token, dbId: cached.rdb_db_id || CONFIG.notionDbId, workspaceName: cached.rdb_workspace };
    }
  }

  const remote = await fetchMisisoToken();
  if (remote.ok) {
    await setCachedAuth(remote.token, remote.dbId, remote.workspaceName);
    return { source: 'misiso', token: remote.token, dbId: remote.dbId || CONFIG.notionDbId, workspaceName: remote.workspaceName };
  }

  // fallback: config.js
  if (CONFIG.notionToken && CONFIG.notionDbId) {
    return { source: 'config', token: CONFIG.notionToken, dbId: CONFIG.notionDbId, workspaceName: '(로컬 설정)' };
  }

  return { source: 'none', token: '', dbId: '', reason: remote.reason || 'no-auth' };
}

console.log(TAG, 'service worker loaded', { hasFallbackConfig: !!(CONFIG.notionToken && CONFIG.notionDbId) });

// 탭별 최신 메모리 사용량 (popup 이 조회)
const memByTab = new Map();

// 임계값 (MB) — performance.memory.usedJSHeapSize 기준
// 미리 실측: 2GB 근처에서 크래시 경험. 여유 두고 1GB 경고 / 1.5GB 위험.
const MEM_WARN = 1000;
const MEM_CRIT = 1500;

function updateBadge(tabId, mb) {
  let text = '';
  let color = '#777';
  if (mb >= MEM_CRIT) { text = '!'; color = '#d33'; }
  else if (mb >= MEM_WARN) { text = '!'; color = '#e8a000'; }
  try {
    chrome.action.setBadgeText({ text, tabId });
    if (text) chrome.action.setBadgeBackgroundColor({ color, tabId });
  } catch {}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.source !== MSG_SOURCE) return;

  if (msg.type === 'mem-stat') {
    const tabId = sender.tab && sender.tab.id;
    if (typeof tabId !== 'number') return;
    memByTab.set(tabId, { mb: msg.mb, limitMb: msg.limitMb, ts: Date.now() });
    updateBadge(tabId, msg.mb);
    return;
  }

  if (msg.type === 'mem-query') {
    const tabId = msg.tabId;
    const info = memByTab.get(tabId);
    sendResponse(info ? { ok: true, ...info, warn: MEM_WARN, crit: MEM_CRIT }
                      : { ok: true, mb: 0, limitMb: 0, warn: MEM_WARN, crit: MEM_CRIT });
    return true;
  }

  if (msg.type === 'get-db-info') {
    // popup 이 "이어가기" 프롬프트 만들 때 호출. 최신 auth 기준 DB ID 반환.
    resolveAuth().then((auth) => {
      sendResponse({ ok: true, dbId: auth.dbId || CONFIG.notionDbId || '', source: auth.source });
    });
    return true;
  }

  if (msg.type === 'auth-status') {
    // popup 의 "미시소 연결" 섹션이 표시할 상태 조회.
    resolveAuth().then((auth) => {
      sendResponse({
        ok: true,
        connected: Boolean(auth.token && auth.dbId),
        source: auth.source,
        workspaceName: auth.workspaceName || '',
        reason: auth.reason || null,
      });
    });
    return true;
  }

  if (msg.type === 'auth-refresh') {
    // popup "연결 새로고침" 버튼 — 캐시 무시하고 fetch.
    clearCachedAuth().then(() => resolveAuth({ forceRefresh: true })).then((auth) => {
      sendResponse({
        ok: true,
        connected: Boolean(auth.token && auth.dbId),
        source: auth.source,
        workspaceName: auth.workspaceName || '',
        reason: auth.reason || null,
      });
    });
    return true;
  }

  if (msg.type !== 'log-turn') return;
  console.log(TAG, 'log-turn received',
    { responseLen: (msg.payload?.responseText || '').length,
      hasNotion: !!(msg.config?.notionToken && msg.config?.notionDbId) });
  handleLogTurn(msg.payload, msg.config)
    .then((r) => { console.log(TAG, 'done', r); sendResponse({ ok: true, ...r }); })
    .catch((err) => {
      console.warn(TAG, 'handleLogTurn failed', err);
      sendResponse({ ok: false, error: String(err && err.message || err) });
    });
  return true; // async response
});

// 탭 닫힘 시 메모리 기록 정리
chrome.tabs.onRemoved.addListener((tabId) => { memByTab.delete(tabId); });


async function handleLogTurn(payload, config) {
  const { requestBody, responseText, url, baseUrl, sessionId, pageTitle, durationSec, startedAtIso } = payload || {};

  // OAuth 기반 auth 조회. 401 나면 강제 refresh 한 번 더.
  let auth = await resolveAuth();
  if (!auth.token && auth.reason === 'login-required') {
    await clearCachedAuth();
    auth = await resolveAuth({ forceRefresh: true });
  }
  const notionToken = auth.token || '';
  const notionDbId = auth.dbId || '';

  const prompt = extractPrompt(requestBody);
  if (prompt === null) {
    console.log(TAG, 'skip: no user turn (follow-up/confirmation call)');
    return { skipped: true, reason: 'no-user-turn' };
  }
  const parsed = parseStream(responseText || '');
  const answer = parsed.answer || (responseText || '').slice(0, 2000);
  const thinking = parsed.thinking || '';
  const tools = parsed.tools;
  const toolCount = parsed.toolCount;
  const status = parsed.status;

  const results = { notion: null };

  if (notionToken && notionDbId) {
    results.notion = await sendNotion(notionToken, notionDbId, {
      prompt, answer, thinking,
      rawRequest: requestBody || '',
      rawResponse: responseText || '',
      url, baseUrl, sessionId,
      pageTitle, durationSec, tools, toolCount, status,
      startedAtIso,
    }).catch((e) => ({ error: String(e) }));
  } else {
    results.notion = { skipped: true, reason: auth.reason || 'no-auth' };
  }

  return results;
}

// ── 요청 body 에서 프롬프트 뽑기 ───────────────────────────────────
// Notion AI transcript: 배열의 각 항목이 {type, ...}. type === "user" 만 진짜 사용자 발화.
// 나머지(config/context/user-specified-context/agent-records-updated/updated-config)는 메타.

// Notion rich-value: [[seg, annotations?], ...] 또는 [seg, ...] 평탄화
function flattenNotionValue(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  if (!Array.isArray(v)) return '';
  const parts = [];
  for (const row of v) {
    if (typeof row === 'string') { parts.push(row); continue; }
    if (!Array.isArray(row)) continue;
    // row = [seg, [annotations]] 또는 [seg1, seg2, ...]
    if (typeof row[0] === 'string') parts.push(row[0]);
    else {
      for (const seg of row) {
        if (typeof seg === 'string') parts.push(seg);
        else if (Array.isArray(seg) && typeof seg[0] === 'string') parts.push(seg[0]);
      }
    }
  }
  return parts.join('');
}

// 반환값 규약:
//   null       → transcript 에 type:"user" 항목 없음 (= confirmation/follow-up 호출). 로그 적재 skip.
//   ''         → user turn 있는데 텍스트 비었음. 적재는 하되 "(빈 프롬프트)" 표기.
//   string     → 진짜 사용자 발화.
function extractPrompt(requestBody) {
  if (!requestBody) return null;
  let obj;
  try { obj = JSON.parse(requestBody); } catch { return String(requestBody).slice(0, 2000); }
  if (typeof obj === 'string') return obj;

  const transcript = Array.isArray(obj.transcript) ? obj.transcript : null;
  if (transcript) {
    let foundUserTurn = false;
    for (let i = transcript.length - 1; i >= 0; i--) {
      const item = transcript[i];
      if (!item || item.type !== 'user') continue;
      foundUserTurn = true;
      const text = flattenNotionValue(item.value).trim();
      if (text) return text;
    }
    if (!foundUserTurn) return null; // user turn 자체가 없는 follow-up 호출
    return ''; // user turn 있는데 텍스트 비어있음 (이상 케이스)
  }

  if (typeof obj.prompt === 'string' && obj.prompt.trim()) return obj.prompt;
  return null;
}

// ── 응답 stream 파싱 ─────────────────────────────────────────────
// Notion AI 응답은 JSON Patch 스트림:
//   {"type":"patch-start","data":{"s":[...]}}       — 초기 state
//   {"type":"patch","v":[{"o":"a","p":"/s/-","v":<slot>}]}  — 슬롯 추가
//   {"type":"patch","v":[{"o":"x","p":"/s/N/value/0/content","v":"텍스트 조각"}]}  — 문자열 확장
//   {"type":"patch","v":[{"o":"s","p":"...","v":...}]}       — 값 set
// 최종 state 재구성 후 slot.type 별로 텍스트/생각/도구 분류.

function parseStream(raw) {
  const out = { answer: '', thinking: '', tools: [], toolCount: 0, status: '성공' };
  if (!raw) return out;

  const lines = raw.split(/\n/).map((s) => s.trim()).filter(Boolean);
  const slots = [];
  for (const line of lines) {
    let pkt;
    try { pkt = JSON.parse(line); } catch { continue; }
    if (!pkt || typeof pkt !== 'object') continue;

    if (pkt.type === 'patch-start') {
      const initS = pkt.data && Array.isArray(pkt.data.s) ? pkt.data.s : [];
      for (const it of initS) slots.push(it);
      continue;
    }
    if (pkt.type === 'patch' && Array.isArray(pkt.v)) {
      for (const op of pkt.v) applyPatchOp(slots, op);
    }
  }

  // slots 순회 → 분류
  const toolSet = new Set();
  for (const slot of slots) {
    if (!slot || typeof slot !== 'object' || !slot.type) continue;
    const t = String(slot.type);

    if (t === 'agent-tool-result' || t === 'agent-tool-call') {
      const name = slot.toolName || slot.toolType || slot.name;
      if (name) toolSet.add(String(name));
      // input.function 도 도구명으로 기록 (loadPage 등)
      if (slot.input && slot.input.function) toolSet.add(String(slot.input.function));
    } else if (t === 'agent-inference' || t === 'agent-message' || t === 'agent-text') {
      const items = Array.isArray(slot.value) ? slot.value : [];
      for (const it of items) {
        if (!it || typeof it !== 'object') continue;
        const itype = String(it.type || '').toLowerCase();
        const content = typeof it.content === 'string' ? it.content : '';
        if (!content) continue;
        if (itype.includes('think') || itype.includes('reason') || itype === 'reflection') {
          out.thinking += content;
        } else {
          out.answer += content;
        }
      }
    } else if (/thinking|reason/i.test(t)) {
      const c = typeof slot.content === 'string' ? slot.content
              : typeof slot.value === 'string' ? slot.value : '';
      if (c) out.thinking += c;
    }
  }

  out.tools = [...toolSet];
  out.toolCount = out.tools.length;
  if (!out.answer.trim()) out.answer = '(응답 텍스트 추출 실패 — 원본 응답 (raw) 참조)';
  return out;
}

// JSON Patch 한 개 적용
function applyPatchOp(slots, op) {
  if (!op || typeof op !== 'object') return;
  const path = String(op.p || '');
  if (!path.startsWith('/s')) return;

  // "/s/-" → slots.push
  if (op.o === 'a' && (path === '/s/-' || path === '/s')) {
    if (op.v !== undefined) slots.push(op.v);
    return;
  }

  // "/s/2/value/0/content" 형태 분해
  const parts = path.split('/').filter(Boolean); // ["s", "2", "value", "0", "content"]
  if (parts[0] !== 's') return;
  const rest = parts.slice(1);
  if (rest.length === 0) return;

  const idx = parseInt(rest[0], 10);
  if (!Number.isFinite(idx) || slots[idx] == null) return;

  const subpath = rest.slice(1);
  if (subpath.length === 0) {
    // 슬롯 자체를 교체/확장
    if (op.o === 's') slots[idx] = op.v;
    return;
  }

  // subpath 마지막 직전까지 navigate
  let node = slots[idx];
  for (let i = 0; i < subpath.length - 1; i++) {
    const seg = subpath[i];
    const key = /^\d+$/.test(seg) ? parseInt(seg, 10) : seg;
    if (node == null) return;
    if (!(key in node)) return;
    node = node[key];
  }
  if (node == null) return;

  const lastSeg = subpath[subpath.length - 1];
  const lastKey = /^\d+$/.test(lastSeg) ? parseInt(lastSeg, 10) : lastSeg;

  if (op.o === 'x') {
    // 문자열 확장
    const cur = node[lastKey];
    node[lastKey] = (typeof cur === 'string' ? cur : '') + String(op.v ?? '');
  } else if (op.o === 's') {
    node[lastKey] = op.v;
  } else if (op.o === 'a') {
    if (Array.isArray(node[lastKey])) node[lastKey].push(op.v);
    else if (Array.isArray(node) && lastSeg === '-') node.push(op.v);
  }
  // op.o === 'd' 등은 스킵
}

// ── Notion ────────────────────────────────────────────────────────
async function sendNotion(token, dbId, data) {
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Notion-Version': NOTION_VERSION,
    'Content-Type': 'application/json',
  };

  const title = truncate((data.prompt || '').replace(/\s+/g, ' '), 80) || '(제목 없음)';
  const startedAt = data.startedAtIso || toKSTISO(new Date());

  const properties = {
    '제목': { title: [{ text: { content: title } }] },
    '시각': { date: { start: startedAt } },
    '채팅 세션 ID': { rich_text: [{ text: { content: data.sessionId || '' } }] },
    '페이지 base URL': { url: data.baseUrl || null },
    '페이지 URL': { url: data.url || null },
    '페이지 제목': { rich_text: [{ text: { content: truncate(data.pageTitle || '', 1900) } }] },
    '프롬프트': { rich_text: [{ text: { content: truncate(data.prompt || '', 1900) } }] },
    '응답 미리보기': { rich_text: [{ text: { content: truncate(data.answer || '', 1900) } }] },
    '소요 시간(초)': { number: Number.isFinite(data.durationSec) ? data.durationSec : null },
    '상태': { select: { name: data.status || '성공' } },
    '도구 호출 수': { number: data.toolCount || 0 },
  };
  if (data.tools && data.tools.length) {
    properties['사용한 도구'] = {
      multi_select: data.tools.slice(0, 20).map((t) => ({ name: String(t).slice(0, 100) })),
    };
  }

  const createRes = await fetch('https://api.notion.com/v1/pages', {
    method: 'POST',
    headers,
    body: JSON.stringify({ parent: { database_id: dbId }, properties }),
  });
  const created = await createRes.json();
  if (!created.id) {
    const errSummary = {
      status: created.status || createRes.status,
      code: created.code,
      message: created.message,
      response: created,
      dbId,
      tokenHead: (notionToken || '').slice(0, 15),
      propertiesKeys: Object.keys(properties),
      timestamp: new Date().toISOString(),
    };
    try { chrome.storage.local.set({ last_notion_error: errSummary }); } catch {}
    console.warn(TAG, 'notion page create failed', errSummary);
    return { error: created.message || 'create failed', response: created };
  }

  // 본문: 섹션별 토글 헤딩 (heading_2 + is_toggleable)
  // - 응답 전문/생각: 마크다운 파싱 → Notion blocks
  // - 프롬프트: 평문 paragraph
  // - 원본 요청/응답: code block (JSON)
  const sections = [
    { heading: '프롬프트', text: data.prompt || '(없음)', kind: 'plain' },
    { heading: '응답 전문', text: data.answer || '(없음)', kind: 'markdown' },
  ];
  if ((data.thinking || '').trim()) {
    sections.push({ heading: '생각 (AI reasoning)', text: data.thinking, kind: 'markdown' });
  }
  if ((data.rawRequest || '').length > 0) {
    sections.push({ heading: '원본 요청 (raw)', text: (data.rawRequest || '').slice(0, 80000), kind: 'code' });
  }
  if ((data.rawResponse || '').length > 0) {
    sections.push({ heading: '원본 응답 (raw)', text: (data.rawResponse || '').slice(0, 80000), kind: 'code' });
  }

  const blocks = [];
  for (const s of sections) {
    let inner;
    if (s.kind === 'code') inner = textToCodeBlock(s.text);
    else if (s.kind === 'markdown') inner = markdownToBlocks(s.text);
    else inner = textToParagraphs(s.text);

    const MAX_CHILDREN = 90;
    const firstBatch = inner.slice(0, MAX_CHILDREN);
    const overflow = inner.slice(MAX_CHILDREN);

    blocks.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ text: { content: s.heading } }],
        is_toggleable: true,
        children: firstBatch,
      },
    });
    if (overflow.length) blocks.push(...overflow);
  }

  for (let i = 0; i < blocks.length; i += 100) {
    const chunk = blocks.slice(i, i + 100);
    const appendRes = await fetch(`https://api.notion.com/v1/blocks/${created.id}/children`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ children: chunk }),
    });
    if (!appendRes.ok) {
      const errJson = await appendRes.json().catch(() => ({}));
      console.warn(TAG, 'notion append failed', appendRes.status, errJson);
      break;
    }
  }

  return { pageId: created.id, url: created.url };
}

// 코드 섹션용: text → 단일 code block (긴 경우 rich_text 여러 chunk)
function textToCodeBlock(text) {
  const MAX_CHARS = 1900;
  const MAX_CHUNKS = 20;
  let t = String(text || '');
  if (t.length > MAX_CHARS * MAX_CHUNKS) t = t.slice(0, MAX_CHARS * MAX_CHUNKS) + '\n…(truncated)';
  const chunks = [];
  for (let i = 0; i < t.length; i += MAX_CHARS) chunks.push(t.slice(i, i + MAX_CHARS));
  if (!chunks.length) chunks.push('(없음)');
  return [{
    object: 'block',
    type: 'code',
    code: {
      language: 'json',
      rich_text: chunks.map((c) => ({ type: 'text', text: { content: c } })),
    },
  }];
}

// 평문 섹션용: text → paragraph 배열 (개행 단위 단순 분할)
function textToParagraphs(text) {
  const MAX_CHARS = 1900;
  let t = String(text || '').trim();
  if (!t) return [{ object: 'block', type: 'paragraph', paragraph: { rich_text: [{ type: 'text', text: { content: '(없음)' } }] } }];
  const blocks = [];
  for (let i = 0; i < t.length; i += MAX_CHARS) {
    blocks.push({
      object: 'block',
      type: 'paragraph',
      paragraph: { rich_text: [{ type: 'text', text: { content: t.slice(i, i + MAX_CHARS) } }] },
    });
  }
  return blocks;
}

// 마크다운 → Notion blocks (핵심 기능 커버: heading, list, quote, code, divider, table, bold/italic/code/link)
function markdownToBlocks(md) {
  const lines = String(md || '').split('\n');
  const blocks = [];
  let i = 0;
  const isBlank = (s) => s == null || s.trim() === '';

  while (i < lines.length) {
    const line = lines[i];

    // 코드 펜스
    const fenceMatch = /^```(\S*)\s*$/.exec(line);
    if (fenceMatch) {
      const lang = normalizeCodeLang(fenceMatch[1]);
      const codeLines = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i])) {
        codeLines.push(lines[i]);
        i++;
      }
      if (i < lines.length) i++; // 닫는 펜스 소비
      blocks.push({
        object: 'block',
        type: 'code',
        code: {
          language: lang,
          rich_text: chunkRichText(codeLines.join('\n')),
        },
      });
      continue;
    }

    // divider
    if (/^[-*_]{3,}\s*$/.test(line)) {
      blocks.push({ object: 'block', type: 'divider', divider: {} });
      i++;
      continue;
    }

    // heading (#, ##, ### → heading_1/2/3; 섹션 자체가 heading_2 이므로 h1,h2도 heading_3으로 다운시프트)
    const headingMatch = /^(#{1,6})\s+(.*)$/.exec(line);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const type = level <= 2 ? 'heading_3' : 'heading_3';
      blocks.push({
        object: 'block',
        type,
        [type]: { rich_text: parseInline(headingMatch[2]) },
      });
      i++;
      continue;
    }

    // quote (연속 > 줄 묶음)
    if (/^>\s?/.test(line)) {
      const quoteLines = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) {
        quoteLines.push(lines[i].replace(/^>\s?/, ''));
        i++;
      }
      blocks.push({
        object: 'block',
        type: 'quote',
        quote: { rich_text: parseInline(quoteLines.join('\n')) },
      });
      continue;
    }

    // 테이블 (다음 줄이 separator 인지 확인)
    if (/^\s*\|/.test(line) && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1])) {
      const rows = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) { rows.push(lines[i]); i++; }
      const tb = parseTable(rows);
      if (tb) blocks.push(tb);
      continue;
    }

    // bulleted list
    const bm = /^\s*[-*+]\s+(.*)$/.exec(line);
    if (bm) {
      blocks.push({
        object: 'block',
        type: 'bulleted_list_item',
        bulleted_list_item: { rich_text: parseInline(bm[1]) },
      });
      i++;
      continue;
    }

    // numbered list
    const nm = /^\s*\d+\.\s+(.*)$/.exec(line);
    if (nm) {
      blocks.push({
        object: 'block',
        type: 'numbered_list_item',
        numbered_list_item: { rich_text: parseInline(nm[1]) },
      });
      i++;
      continue;
    }

    // 빈 줄
    if (isBlank(line)) { i++; continue; }

    // paragraph (연속 평문 줄 묶음)
    const paraLines = [line];
    i++;
    while (i < lines.length) {
      const next = lines[i];
      if (isBlank(next)) break;
      if (/^(#{1,6})\s/.test(next)) break;
      if (/^```/.test(next)) break;
      if (/^[-*_]{3,}\s*$/.test(next)) break;
      if (/^>\s?/.test(next)) break;
      if (/^\s*[-*+]\s+/.test(next)) break;
      if (/^\s*\d+\.\s+/.test(next)) break;
      if (/^\s*\|/.test(next)) break;
      paraLines.push(next);
      i++;
    }
    blocks.push({
      object: 'block',
      type: 'paragraph',
      paragraph: { rich_text: parseInline(paraLines.join('\n')) },
    });
  }

  if (!blocks.length) {
    blocks.push({ object: 'block', type: 'paragraph', paragraph: { rich_text: [{ type: 'text', text: { content: '(없음)' } }] } });
  }
  return blocks;
}

// 인라인 마크다운: **bold**, *italic*/_italic_, `code`, [text](url)
function parseInline(text) {
  const segs = [];
  const re = /(\*\*([^*]+?)\*\*|__([^_]+?)__|\*([^*\n]+?)\*|_([^_\n]+?)_|`([^`\n]+?)`|\[([^\]]+?)\]\((https?:\/\/[^\s)]+)\))/g;
  let last = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) pushText(segs, text.slice(last, m.index), null);
    if (m[2] != null || m[3] != null) pushText(segs, m[2] || m[3], { bold: true });
    else if (m[4] != null || m[5] != null) pushText(segs, m[4] || m[5], { italic: true });
    else if (m[6] != null) pushText(segs, m[6], { code: true });
    else if (m[7] != null) pushText(segs, m[7], null, m[8]);
    last = m.index + m[0].length;
  }
  if (last < text.length) pushText(segs, text.slice(last), null);
  if (!segs.length) pushText(segs, text || '', null);
  return segs;
}

function pushText(segs, content, annotations, url) {
  if (!content) return;
  // 2000자 쪼개기
  for (let i = 0; i < content.length; i += 1900) {
    const chunk = content.slice(i, i + 1900);
    const seg = { type: 'text', text: { content: chunk } };
    if (url) seg.text.link = { url };
    if (annotations) seg.annotations = annotations;
    segs.push(seg);
  }
}

function chunkRichText(text) {
  const chunks = [];
  const t = String(text || '');
  if (!t) return [{ type: 'text', text: { content: '' } }];
  for (let i = 0; i < t.length; i += 1900) chunks.push({ type: 'text', text: { content: t.slice(i, i + 1900) } });
  return chunks;
}

function normalizeCodeLang(lang) {
  const l = String(lang || '').toLowerCase().trim();
  const known = ['abap','arduino','bash','basic','c','clojure','coffeescript','c++','c#','css','dart','diff','docker','elixir','elm','erlang','flow','fortran','f#','gherkin','glsl','go','graphql','groovy','haskell','html','java','javascript','json','julia','kotlin','latex','less','lisp','livescript','lua','makefile','markdown','matlab','mermaid','nix','objective-c','ocaml','pascal','perl','php','plain text','powershell','prolog','protobuf','python','r','reason','ruby','rust','sass','scala','scheme','scss','shell','sql','swift','typescript','vb.net','verilog','vhdl','visual basic','webassembly','xml','yaml'];
  if (known.includes(l)) return l;
  if (l === 'js') return 'javascript';
  if (l === 'ts') return 'typescript';
  if (l === 'sh') return 'shell';
  if (l === 'py') return 'python';
  return 'plain text';
}

function parseTable(rows) {
  if (rows.length < 2) return null;
  const cells = rows.map(splitTableRow);
  // rows[1] 은 separator — 헤더는 rows[0], 데이터는 rows.slice(2)
  const header = cells[0];
  const body = cells.slice(2);
  const width = header.length;
  if (width === 0) return null;

  const normalize = (row) => {
    const out = row.slice(0, width);
    while (out.length < width) out.push('');
    return out;
  };

  const tableRows = [
    { object: 'block', type: 'table_row', table_row: { cells: header.map((c) => parseInline(c)) } },
    ...body.map((r) => ({ object: 'block', type: 'table_row', table_row: { cells: normalize(r).map((c) => parseInline(c)) } })),
  ];
  return {
    object: 'block',
    type: 'table',
    table: {
      table_width: width,
      has_column_header: true,
      has_row_header: false,
      children: tableRows,
    },
  };
}

function splitTableRow(row) {
  return String(row).trim().replace(/^\|/, '').replace(/\|\s*$/, '').split('|').map((s) => s.trim());
}

// ── utils ─────────────────────────────────────────────────────────
function truncate(s, n) {
  if (!s) return '';
  s = String(s);
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
}

function toKSTISO(date) {
  // Notion date 는 timezone 있는 ISO 받음
  const d = new Date(date.getTime() + 9 * 60 * 60 * 1000);
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const mi = String(d.getUTCMinutes()).padStart(2, '0');
  const ss = String(d.getUTCSeconds()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}+09:00`;
}
