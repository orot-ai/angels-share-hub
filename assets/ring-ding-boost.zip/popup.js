(function () {
  const MSG_SOURCE = 'notion-ai-bot';
  const DEFAULTS = { sound: 'ding', volume: 1.0, logEnabled: true };
  const soundSelect = document.getElementById('sound');
  const volumeInput = document.getElementById('volume');
  const volumeText = document.getElementById('volumeText');
  const previewBtn = document.getElementById('preview');
  const logEnabled = document.getElementById('logEnabled');
  const memCard = document.getElementById('memCard');
  const memValue = document.getElementById('memValue');
  const memLimit = document.getElementById('memLimit');
  const memBar = document.getElementById('memBar');
  const memStatus = document.getElementById('memStatus');
  const continueBtn = document.getElementById('continueSession');
  const authCard = document.getElementById('authCard');
  const authState = document.getElementById('authState');
  const authWorkspace = document.getElementById('authWorkspace');
  const authConnectBtn = document.getElementById('authConnect');
  const authRefreshBtn = document.getElementById('authRefresh');
  const authHint = document.getElementById('authHint');

  const MISISO_GIFT_URL_PROD = 'https://misiso.com/gifts/ring-ding-boost';
  const MISISO_GIFT_URL_DEV = 'http://localhost:3000/gifts/ring-ding-boost';

  // ── 메모리 상태 표시 ────────────────────────────────────────────
  async function getActiveNotionTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/notion\.so/.test(tab.url || '')) return null;
    return tab;
  }

  async function refreshMem() {
    const tab = await getActiveNotionTab();
    if (!tab) {
      memValue.textContent = '—';
      memStatus.textContent = '노션 탭에서만 측정됩니다';
      memBar.style.width = '0%';
      memCard.classList.remove('warn', 'crit');
      continueBtn.disabled = true;
      return;
    }
    continueBtn.disabled = false;
    chrome.runtime.sendMessage({ source: MSG_SOURCE, type: 'mem-query', tabId: tab.id }, (resp) => {
      if (!resp || !resp.ok) return;
      const { mb = 0, limitMb = 0, warn = 1500, crit = 2000 } = resp;
      memValue.textContent = mb ? mb.toLocaleString() : '측정 중';
      memLimit.textContent = limitMb ? `/ ${limitMb.toLocaleString()}` : '';
      const pct = limitMb ? Math.min(100, Math.round((mb / limitMb) * 100)) : 0;
      memBar.style.width = `${pct}%`;
      memCard.classList.remove('warn', 'crit');
      if (mb >= crit) {
        memCard.classList.add('crit');
        memStatus.textContent = '🚨 위험 — 지금 새 채팅으로 이어가세요';
      } else if (mb >= warn) {
        memCard.classList.add('warn');
        memStatus.textContent = '⚠️ 경고 — 곧 정리하는 게 좋아요';
      } else if (mb > 0) {
        memStatus.textContent = '✅ 안전';
      } else {
        memStatus.textContent = '측정 대기 중 (최대 5초)';
      }
    });
  }
  refreshMem();
  setInterval(refreshMem, 2000);

  // ── 이어가기 버튼 ──────────────────────────────────────────────
  // 현재 탭의 ?t=기존ID 에 저장된 대화를 DB 에서 불러와 요약하도록
  // 새 세션(?t=new) 에 pending prompt 를 sessionStorage 에 꽂고 URL 변경.
  // content.js 가 ?t=new 로드 시 자동으로 AI 입력창에 주입.
  function parseNotionUrl(urlStr) {
    try {
      const u = new URL(urlStr);
      return {
        sessionId: u.searchParams.get('t') || '',
        baseUrl: `${u.origin}${u.pathname}`,
      };
    } catch {
      return { sessionId: '', baseUrl: urlStr };
    }
  }

  async function getActiveSessionId(tabId, fallbackUrl) {
    // URL 의 ?t= 값이 "new" 가 아니면 그걸 사용, "new" 이면 content.js 가 localStorage 에
    // 캐시해둔 마지막 실제 세션 ID 사용. 이게 "열려있던 대화의 진짜 세션 ID".
    const { sessionId } = parseNotionUrl(fallbackUrl);
    if (sessionId && sessionId !== 'new') return sessionId;
    try {
      const [injected] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: () => {
          try { return localStorage.getItem('rdb_last_session_id') || null; } catch { return null; }
        },
      });
      return injected?.result || '';
    } catch {
      return '';
    }
  }

  async function buildContinuePrompt(originalUrl, resolvedSessionId) {
    const { baseUrl } = parseNotionUrl(originalUrl);
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ source: MSG_SOURCE, type: 'get-db-info' }, (resp) => {
        const dbId = (resp && resp.dbId) || '';
        const dbUrl = dbId ? `https://www.notion.so/${dbId.replace(/-/g, '')}` : '(DB 설정 안됨)';
        const filterClause = resolvedSessionId
          ? `"채팅 세션 ID" 속성이 정확히 "${resolvedSessionId}" 인 레코드`
          : `"페이지 base URL" 속성이 "${baseUrl}" 이고 "시각" 이 최근 1시간 이내인 레코드`;
        resolve(
`이전 채팅 맥락을 불러와 요약해줘.

노션 DB 주소: ${dbUrl}
필터: ${filterClause}

해당 레코드들을 "시각" 속성 오름차순으로 모두 읽고:
1. 이 세션에서 다루던 작업/주제 한 줄 요약
2. 핵심 결정·합의 사항 3~5개
3. 아직 미해결/진행 중인 포인트 (있으면)

을 먼저 정리해줘. 그 다음 그 맥락을 기억한 상태에서 내가 던지는 다음 요청을 이어서 처리해.`
        );
      });
    });
  }

  continueBtn.addEventListener('click', async () => {
    const tab = await getActiveNotionTab();
    if (!tab) { alert('노션 탭에서만 동작합니다'); return; }
    continueBtn.disabled = true;
    continueBtn.textContent = '준비 중…';

    const originalUrl = tab.url;
    const resolvedSessionId = await getActiveSessionId(tab.id, originalUrl);
    console.log('[RingDingDone popup] resolved sessionId:', resolvedSessionId);
    const prompt = await buildContinuePrompt(originalUrl, resolvedSessionId);

    try {
      // 페이지 리로드 없이: 노션 UI 의 "새 채팅 시작" 버튼 click → 세션 전환 → composer 주입 → 전송
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        args: [prompt],
        func: async (promptText) => {
          const wait = (ms) => new Promise((r) => setTimeout(r, ms));

          // 1) 노션 AI 채팅창의 "새 채팅" 버튼 = svg.chatBubblePlus 를 감싸는 버튼.
          //    aria-label "새 채팅 시작" 은 사이드바의 전역 새 채팅이라 다른 버튼임.
          const chatBubblePlusSvg = document.querySelector('svg.chatBubblePlus');
          const newChatBtn = chatBubblePlusSvg
            ? chatBubblePlusSvg.closest('[role="button"], button')
            : null;
          if (newChatBtn) {
            newChatBtn.click();
            console.log('[RingDingDone] AI 새 채팅 버튼 클릭');
            await wait(800);
          } else {
            console.warn('[RingDingDone] AI 새 채팅 버튼 (chatBubblePlus) 못 찾음');
          }

          // 2) AI composer 찾기 (마지막 것 = 플로팅 채팅창)
          const findComposer = () =>
            Array.from(
              document.querySelectorAll('div[contenteditable="true"][placeholder^="AI"]'),
            ).pop();
          let composer = findComposer();
          for (let i = 0; i < 30 && !composer; i++) {
            await wait(200);
            composer = findComposer();
          }
          if (!composer) return { ok: false, error: 'composer-not-found' };

          // 3) 프롬프트 주입
          composer.focus();
          try {
            const range = document.createRange();
            range.selectNodeContents(composer);
            range.collapse(false);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
          } catch {}
          document.execCommand('insertText', false, promptText);
          await wait(500);

          // 4) 전송 버튼 click (tag 무관)
          const sendBtn =
            document.querySelector('[aria-label="AI 메시지 제출하기"]') ||
            document.querySelector('[aria-label*="제출"]') ||
            document.querySelector('[aria-label*="Submit"]');
          if (sendBtn && !sendBtn.disabled) {
            sendBtn.click();
            return { ok: true, sent: true };
          }
          return { ok: true, sent: false, reason: 'send-btn-unavailable' };
        },
      });
      window.close();
    } catch (e) {
      console.warn('[RingDingDone popup] continue failed', e);
      continueBtn.disabled = false;
      continueBtn.textContent = '🫧 채팅 새로 시작 (맥락 유지)';
      alert('실패: ' + (e && e.message));
    }
  });

  for (const [key, def] of Object.entries(NOTION_AI_BOT_SOUNDS)) {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = def.label;
    soundSelect.appendChild(opt);
  }

  chrome.storage.sync.get(DEFAULTS, (cfg) => {
    soundSelect.value = cfg.sound in NOTION_AI_BOT_SOUNDS ? cfg.sound : DEFAULTS.sound;
    const pct = Math.round((cfg.volume ?? DEFAULTS.volume) * 100);
    volumeInput.value = pct;
    volumeText.textContent = `${pct}%`;
    logEnabled.checked = cfg.logEnabled !== false; // 기본 true
  });

  function currentVolume() {
    return Number(volumeInput.value) / 100;
  }

  soundSelect.addEventListener('change', () => {
    chrome.storage.sync.set({ sound: soundSelect.value });
    playPreview();
  });

  volumeInput.addEventListener('input', () => {
    volumeText.textContent = `${volumeInput.value}%`;
  });

  volumeInput.addEventListener('change', () => {
    chrome.storage.sync.set({ volume: currentVolume() });
    playPreview();
  });

  previewBtn.addEventListener('click', playPreview);

  logEnabled.addEventListener('change', () => {
    chrome.storage.sync.set({ logEnabled: logEnabled.checked });
  });

  let popupCtx = null;
  function playPreview() {
    const sound = NOTION_AI_BOT_SOUNDS[soundSelect.value];
    if (!sound) return;
    const volume = currentVolume();
    if (volume <= 0) return;

    try {
      if (!popupCtx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        popupCtx = new AC();
      }
      if (popupCtx.state === 'suspended') popupCtx.resume().catch(() => {});

      const t0 = popupCtx.currentTime;
      for (const n of sound.notes) {
        const osc = popupCtx.createOscillator();
        const gain = popupCtx.createGain();
        osc.type = n.type || 'sine';
        osc.frequency.value = n.freq;
        const peak = Math.max(0.0001, n.vol * volume);
        gain.gain.setValueAtTime(0, t0 + n.start);
        gain.gain.linearRampToValueAtTime(peak, t0 + n.start + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0008, t0 + n.start + n.dur);
        osc.connect(gain).connect(popupCtx.destination);
        osc.start(t0 + n.start);
        osc.stop(t0 + n.start + n.dur + 0.05);
      }
    } catch (e) {
      console.warn('[RingDingDone popup]', e);
    }
  }

  // ── 미시소 연결 상태 카드 ───────────────────────────────────────
  function updateAuthUi(state) {
    authCard.classList.remove('connected', 'pending');
    if (!state || !state.ok) {
      authState.textContent = '상태 조회 실패';
      authHint.textContent = '네트워크 또는 백그라운드 오류';
      return;
    }
    if (state.connected) {
      authCard.classList.add('connected');
      authState.textContent = '✅ 연결됨';
      authWorkspace.textContent = state.workspaceName || '';
      authHint.textContent = state.source === 'misiso'
        ? '미시소 OAuth 토큰 사용 중'
        : state.source === 'config'
          ? '로컬 config.js fallback 사용 중'
          : '';
      authConnectBtn.textContent = '미시소에서 관리';
      return;
    }
    authCard.classList.add('pending');
    if (state.reason === 'login-required') {
      authState.textContent = '⚠️ 로그인 필요';
      authHint.textContent = '미시소에 로그인 후 /gifts/ring-ding-boost 에서 연결하세요';
    } else if (state.reason === 'not-connected') {
      authState.textContent = '⚠️ 노션 연결 필요';
      authHint.textContent = '선물 페이지에서 "노션 연결하기" 클릭';
    } else {
      authState.textContent = '⚠️ 미연결';
      authHint.textContent = '미시소 선물 페이지에서 노션 연결 필요';
    }
    authWorkspace.textContent = '';
    authConnectBtn.textContent = '미시소 연결';
  }

  function refreshAuth({ force = false } = {}) {
    const type = force ? 'auth-refresh' : 'auth-status';
    chrome.runtime.sendMessage({ source: MSG_SOURCE, type }, (resp) => {
      updateAuthUi(resp);
    });
  }

  authConnectBtn.addEventListener('click', () => {
    // 프로덕션 우선, 로컬 개발 시에는 사용자가 직접 /localhost 로 이동.
    chrome.tabs.create({ url: MISISO_GIFT_URL_PROD });
  });

  authRefreshBtn.addEventListener('click', () => {
    authHint.textContent = '새로고침 중…';
    refreshAuth({ force: true });
  });

  refreshAuth();
  // popup 열려있는 동안 주기 갱신 (토큰 만료/새로 연결됐을 때 빠르게 반영)
  setInterval(() => refreshAuth(), 5000);
})();
