(function () {
  var previewIframe = document.getElementById('preview');
  var errorEl = document.getElementById('error');
  var pendingHtml = null;

  // sandbox iframe → 이 페이지로의 메시지 릴레이
  window.addEventListener('message', function (e) {
    // sandbox/preview.html는 null origin (manifest sandbox CSP)
    if (e.origin !== 'null' && !e.origin.startsWith('chrome-extension://')) return;
    if (!e.data) return;

    // sandbox 준비 완료 → 대기 중 HTML 전송
    if (e.data.type === 'SANDBOX_READY' && pendingHtml) {
      previewIframe.contentWindow.postMessage({ type: 'RENDER', html: pendingHtml }, '*');
      pendingHtml = null;
    }

    // Notion API 프록시 릴레이: inner iframe fetch interceptor → service worker
    if (e.data.type === '__NP_REQ') {
      var reqId = e.data.id;
      chrome.runtime.sendMessage({
        type: 'NOTION_API_PROXY',
        request: { method: e.data.method, path: e.data.path, body: e.data.body }
      }, function (result) {
        if (!previewIframe.contentWindow) return;
        result = result || { error: 'NO_RESPONSE', status: 500 };
        previewIframe.contentWindow.postMessage({
          type: '__NP_RES',
          id: reqId,
          body: result.data,
          status: result.status || 500,
          err: result.error || null
        }, '*');
      });
    }
  });

  // storage에서 HTML 읽어서 sandbox/preview.html을 통해 렌더링
  // sandbox/preview.html의 manifest sandbox CSP가 inner srcdoc iframe에 상속되어
  // 인라인 스크립트와 chrome-extension:// lib 파일이 정상 동작함.
  chrome.storage.local.get('fullscreenHtml', function (data) {
    if (!data.fullscreenHtml) {
      errorEl.classList.add('visible');
      return;
    }
    pendingHtml = data.fullscreenHtml;
    // SANDBOX_READY 수신 전에 onload 폴백으로도 전송 (50ms 지연)
    previewIframe.onload = function () {
      if (pendingHtml) {
        setTimeout(function () {
          if (pendingHtml) {
            previewIframe.contentWindow.postMessage({ type: 'RENDER', html: pendingHtml }, '*');
            pendingHtml = null;
          }
        }, 50);
      }
    };
    previewIframe.src = '../sandbox/preview.html?t=' + Date.now();
  });
})();
