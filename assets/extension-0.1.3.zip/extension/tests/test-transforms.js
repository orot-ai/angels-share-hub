/**
 * test-transforms.js
 * Plain Node.js tests for utils/code-transform.js utility functions.
 * Run: node extension/tests/test-transforms.js
 */

'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

// ── Bootstrap global namespace ────────────────────────────────────────────────

const globalThis_ = global;

// 1. constants.js must load first (defines REGEX, CDN_URLS)
const constantsSrc = fs.readFileSync(
  path.resolve(__dirname, '../utils/constants.js'),
  'utf8'
);
// The IIFE targets `globalThis` or `self`; provide `self` alias
global.self = global;
eval(constantsSrc); // eslint-disable-line no-eval

// 2. Load code-transform.js (depends on CodePreviewerUtils.REGEX / CDN_URLS)
const transformSrc = fs.readFileSync(
  path.resolve(__dirname, '../utils/code-transform.js'),
  'utf8'
);
eval(transformSrc); // eslint-disable-line no-eval

const utils = global.CodePreviewerUtils;

// ── Test runner ───────────────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log('PASS  ' + name);
    passed++;
  } catch (err) {
    console.error('FAIL  ' + name);
    console.error('      ' + err.message);
    failed++;
  }
}

function eq(actual, expected, msg) {
  if (actual !== expected) {
    throw new Error(
      (msg ? msg + '\n      ' : '') +
      'Expected: ' + JSON.stringify(expected) + '\n' +
      '      Got:      ' + JSON.stringify(actual)
    );
  }
}

function contains(str, substr, msg) {
  if (typeof str !== 'string' || !str.includes(substr)) {
    throw new Error(
      (msg ? msg + '\n      ' : '') +
      JSON.stringify(str) + ' does not contain ' + JSON.stringify(substr)
    );
  }
}

function notContains(str, substr, msg) {
  if (typeof str === 'string' && str.includes(substr)) {
    throw new Error(
      (msg ? msg + '\n      ' : '') +
      JSON.stringify(str) + ' should NOT contain ' + JSON.stringify(substr)
    );
  }
}

// ── rewriteBareImports ────────────────────────────────────────────────────────

test('rewriteBareImports: bare import → esm.sh', function () {
  const result = utils.rewriteBareImports("import React from 'react';");
  contains(result, 'https://esm.sh/react', 'should prepend esm.sh');
});

test('rewriteBareImports: URL import unchanged', function () {
  const code = "import foo from 'https://esm.sh/foo';";
  const result = utils.rewriteBareImports(code);
  eq(result, code, 'https URL import must not be rewritten');
});

test('rewriteBareImports: relative import unchanged', function () {
  const code = "import bar from './bar';";
  const result = utils.rewriteBareImports(code);
  eq(result, code, 'relative import must not be rewritten');
});

test('rewriteBareImports: parent-relative import unchanged', function () {
  const code = "import baz from '../baz';";
  const result = utils.rewriteBareImports(code);
  eq(result, code, '../ import must not be rewritten');
});

test('rewriteBareImports: side-effect bare import → esm.sh', function () {
  const code = "import 'lodash';";
  const result = utils.rewriteBareImports(code);
  contains(result, 'https://esm.sh/lodash');
});

test('rewriteBareImports: dynamic import bare specifier → esm.sh', function () {
  const code = "const m = await import('lodash');";
  const result = utils.rewriteBareImports(code);
  contains(result, 'https://esm.sh/lodash');
});

test('rewriteBareImports: dynamic import URL unchanged', function () {
  const code = "const m = await import('https://esm.sh/lodash');";
  const result = utils.rewriteBareImports(code);
  eq(result, code);
});

// ── hasBareImports ────────────────────────────────────────────────────────────

test('hasBareImports: detects static bare import', function () {
  eq(utils.hasBareImports("import React from 'react';"), true);
});

test('hasBareImports: detects dynamic bare import', function () {
  eq(utils.hasBareImports("const x = import('lodash');"), true);
});

test('hasBareImports: detects await import', function () {
  eq(utils.hasBareImports("const x = await import('react');"), true);
});

test('hasBareImports: URL import not bare', function () {
  eq(utils.hasBareImports("import foo from 'https://esm.sh/foo';"), false);
});

test('hasBareImports: relative import not bare', function () {
  eq(utils.hasBareImports("import foo from './foo';"), false);
});

test('hasBareImports: empty/null returns false', function () {
  eq(utils.hasBareImports(''), false);
  eq(utils.hasBareImports(null), false);
});

// ── convertAwaitImports ───────────────────────────────────────────────────────

test('convertAwaitImports: default pattern (.default)', function () {
  const code = "const React = (await import('react')).default;";
  const result = utils.convertAwaitImports(code);
  contains(result, "import React from 'react'", 'default pattern');
  notContains(result, 'await import', 'should remove await import');
});

test('convertAwaitImports: destructuring with alias', function () {
  const code = "const { useState: state, useEffect: effect } = await import('react');";
  const result = utils.convertAwaitImports(code);
  contains(result, 'import', 'destructuring alias');
  contains(result, 'useState as state', 'alias preserved');
  contains(result, 'useEffect as effect', 'second alias preserved');
  notContains(result, 'await import');
});

test('convertAwaitImports: namespace pattern (no .default)', function () {
  const code = "const ReactDOM = await import('react-dom');";
  const result = utils.convertAwaitImports(code);
  contains(result, "import * as ReactDOM from 'react-dom'", 'namespace pattern');
  notContains(result, 'await import');
});

test('convertAwaitImports: null/empty passthrough', function () {
  eq(utils.convertAwaitImports(''), '');
  eq(utils.convertAwaitImports(null), null);
});

// ── stripRelativeImports ──────────────────────────────────────────────────────

test('stripRelativeImports: strips ./ named import', function () {
  const code = "import Foo from './Foo';";
  const result = utils.stripRelativeImports(code);
  notContains(result, "import Foo from './Foo'", 'should be stripped');
});

test('stripRelativeImports: strips ../ import', function () {
  const code = "import utils from '../utils';";
  const result = utils.stripRelativeImports(code);
  notContains(result, "import utils from '../utils'");
});

test('stripRelativeImports: strips side-effect relative import', function () {
  const code = "import './styles.css';";
  const result = utils.stripRelativeImports(code);
  notContains(result, "import './styles.css'");
});

test('stripRelativeImports: keeps bare/URL imports', function () {
  const code = "import React from 'react';";
  const result = utils.stripRelativeImports(code);
  contains(result, "import React from 'react'", 'bare import must remain');
});

// ── stripExports ──────────────────────────────────────────────────────────────

test('stripExports: export default function', function () {
  const code = "export default function App() { return null; }";
  const result = utils.stripExports(code);
  notContains(result, 'export default function', 'export keyword removed');
  contains(result, 'function App()', 'function declaration kept');
});

test('stripExports: export default expression → var _default', function () {
  const code = "export default 42;";
  const result = utils.stripExports(code);
  contains(result, 'var _default = 42', 'expression wrapped in var');
  notContains(result, 'export default');
});

test('stripExports: named export declaration', function () {
  const code = "export const greeting = 'hello';";
  const result = utils.stripExports(code);
  notContains(result, 'export const', 'export keyword stripped');
  contains(result, "const greeting = 'hello'", 'declaration kept');
});

test('stripExports: export {} removed', function () {
  const code = "export { foo, bar };";
  const result = utils.stripExports(code);
  notContains(result, 'export {', 'export {} stripped');
});

test('stripExports: export * from removed', function () {
  const code = "export * from 'lodash';";
  const result = utils.stripExports(code);
  notContains(result, 'export *', 'export * stripped');
});

// ── ensureReactImport ─────────────────────────────────────────────────────────

test('ensureReactImport: adds React and ReactDOM when missing', function () {
  const code = "function App() { return <div/>; }";
  const result = utils.ensureReactImport(code);
  contains(result, "import React from 'react'", 'React import added');
  contains(result, "import ReactDOM from 'react-dom/client'", 'ReactDOM import added');
});

test('ensureReactImport: skips React when already present (default import)', function () {
  const code = "import React from 'react';\nimport ReactDOM from 'react-dom/client';\nfunction App(){}";
  const result = utils.ensureReactImport(code);
  // Should not duplicate React import
  const reactCount = (result.match(/import React from/g) || []).length;
  eq(reactCount, 1, 'React import should appear exactly once');
});

test('ensureReactImport: adds ReactDOM when React present but ReactDOM missing', function () {
  const code = "import React from 'react';\nfunction App(){}";
  const result = utils.ensureReactImport(code);
  contains(result, "import ReactDOM from 'react-dom/client'", 'ReactDOM import added');
});

test('ensureReactImport: adds React + ReactDOM when only named react import present', function () {
  const code = "import { useState } from 'react';\nfunction App(){}";
  const result = utils.ensureReactImport(code);
  contains(result, "import React from 'react'", 'React default import added');
});

test('ensureReactImport: null/empty passthrough', function () {
  eq(utils.ensureReactImport(''), '');
  eq(utils.ensureReactImport(null), null);
});

// ── decodeUnicodeEscapes ──────────────────────────────────────────────────────

test('decodeUnicodeEscapes: decodes \\u{XXXX} form', function () {
  const code = "var s = '\\u{1F600}';";
  const result = utils.decodeUnicodeEscapes(code);
  // \u{1F600} is the grinning face emoji
  contains(result, '\uD83D\uDE00', 'code-point escape decoded');
  notContains(result, '\\u{1F600}', 'raw escape removed');
});

test('decodeUnicodeEscapes: decodes \\uXXXX (4-hex) form', function () {
  // JSX 텍스트 노드에서 \uXXXX가 Babel에 의해 리터럴로 처리되는 버그를 막기 위해
  // 4자리 형식도 디코딩한다. JS 스트링 리터럴에서는 \u0041 → 'A'와 동등하므로 안전.
  const code = "var s = '\\u0041';";
  const result = utils.decodeUnicodeEscapes(code);
  contains(result, 'A', '4-digit \\u escape decoded to actual char');
  notContains(result, '\\u0041', 'raw escape removed');
});

test('decodeUnicodeEscapes: decodes Korean \\uXXXX in JSX text node', function () {
  const code = '<button>\\uc11c\\ube44\\uc2a4</button>';
  const result = utils.decodeUnicodeEscapes(code);
  contains(result, '서비스', 'Korean chars decoded');
  notContains(result, '\\uc11c', 'raw escape removed');
});

test('decodeUnicodeEscapes: decodes emoji surrogate pair', function () {
  const code = '<div>\\ud83e\\udd43</div>';
  const result = utils.decodeUnicodeEscapes(code);
  contains(result, '🥃', 'emoji decoded from surrogate pair');
  notContains(result, '\\ud83e', 'raw escape removed');
});

test('decodeUnicodeEscapes: null/empty passthrough', function () {
  eq(utils.decodeUnicodeEscapes(''), '');
  eq(utils.decodeUnicodeEscapes(null), null);
});

// ── looksLikeJSX ─────────────────────────────────────────────────────────────

test('looksLikeJSX: detects createRoot (React API)', function () {
  eq(utils.looksLikeJSX("createRoot(document.getElementById('root'))"), true);
});

test('looksLikeJSX: detects JSX tags (uppercase component)', function () {
  eq(utils.looksLikeJSX('return <App />;'), true);
});

test('looksLikeJSX: detects return <div>', function () {
  eq(utils.looksLikeJSX('return <div>hello</div>;'), true);
});

test('looksLikeJSX: detects from "react" import', function () {
  eq(utils.looksLikeJSX("import React from 'react';"), true);
});

test('looksLikeJSX: false for plain JS', function () {
  eq(utils.looksLikeJSX('const x = 1 + 2;'), false);
});

test('looksLikeJSX: false for null/empty', function () {
  eq(utils.looksLikeJSX(''), false);
  eq(utils.looksLikeJSX(null), false);
});

// ── isEntryFile ───────────────────────────────────────────────────────────────

test('isEntryFile: detects createRoot', function () {
  eq(utils.isEntryFile("createRoot(document.getElementById('root')).render(<App />);"), true);
});

test('isEntryFile: detects ReactDOM.render', function () {
  eq(utils.isEntryFile("ReactDOM.render(<App />, document.getElementById('root'));"), true);
});

test('isEntryFile: false for component-only file', function () {
  eq(utils.isEntryFile("export default function App() { return <div/>; }"), false);
});

test('isEntryFile: false for null/empty', function () {
  eq(utils.isEntryFile(''), false);
  eq(utils.isEntryFile(null), false);
});

// ── Summary ───────────────────────────────────────────────────────────────────

console.log('');
console.log('Results: ' + passed + ' passed, ' + failed + ' failed');

if (failed > 0) {
  process.exit(1);
}
