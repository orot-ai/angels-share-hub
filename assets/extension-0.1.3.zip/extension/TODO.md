# Extension 개발 TODO

## 완료된 작업
- [x] manifest.json 작성
- [x] background/service-worker.js (Notion API, 토큰 관리, 메시지 허브, 캐시)
- [x] utils/notion-api.js (참고용)
- [x] content/content-script.js — 노션 URL에서 page_id 추출 + SPA 네비게이션 감지
- [x] sidepanel/index.html — Side Panel UI (toolbar + error + iframe)
- [x] sidepanel/preview.js — 프리뷰 빌드 (HTML/CSS/JS/JSX/TSX) + 렌더링
- [x] sidepanel/styles.css — Side Panel 스타일
- [x] popup/index.html — 연결 상태 + 토큰 수동 입력 (개발용)
- [x] popup/popup.js — 상태 체크 + 토큰 저장 로직
- [x] icons/ — 아이콘 생성 (16/48/128)

## 테스트 (다음 단계)
- [ ] chrome://extensions에서 로드하여 동작 확인
- [ ] HTML/CSS/JS 코드블록 프리뷰 테스트
- [ ] JSX 코드블록 (React) 프리뷰 테스트
- [ ] TSX 코드블록 프리뷰 테스트
- [ ] Tailwind 클래스 적용 테스트
- [ ] 토큰 없을 때 에러 표시 테스트
- [ ] 노션 외 사이트에서의 동작 테스트
- [ ] 페이지 이동 시 page_id 변경 감지 테스트

## 나중에 (misiso.com 연동 후)
- [ ] externally_connectable 토큰 수신 테스트
- [ ] popup에서 토큰 수동 입력 UI 제거
- [ ] Chrome Web Store 등록
