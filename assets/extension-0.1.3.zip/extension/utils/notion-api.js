const NOTION_API = 'https://api.notion.com/v1';
const NOTION_VERSION = '2022-06-28';

/**
 * 페이지의 모든 블록 조회 (페이지네이션 처리)
 */
async function fetchAllBlocks(pageId, token) {
  const blocks = [];
  let cursor = undefined;

  do {
    const url = new URL(`${NOTION_API}/blocks/${pageId}/children`);
    url.searchParams.set('page_size', '100');
    if (cursor) url.searchParams.set('start_cursor', cursor);

    const res = await fetch(url.toString(), {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Notion-Version': NOTION_VERSION,
      },
    });

    if (res.status === 401) {
      throw new Error('TOKEN_EXPIRED');
    }
    if (res.status === 429) {
      const retryAfter = parseInt(res.headers.get('Retry-After') || '1');
      await new Promise(r => setTimeout(r, retryAfter * 1000));
      continue;
    }
    if (!res.ok) {
      throw new Error(`API_ERROR_${res.status}`);
    }

    const data = await res.json();
    blocks.push(...data.results);
    cursor = data.has_more ? data.next_cursor : undefined;
  } while (cursor);

  return blocks;
}

/**
 * 코드블록만 필터링하고 language별로 분류
 */
function extractCode(blocks) {
  const code = {
    html: [],
    css: [],
    javascript: [],
    jsx: [],
    tsx: [],
  };

  for (const block of blocks) {
    if (block.type !== 'code') continue;

    const lang = block.code.language?.toLowerCase();
    const text = block.code.rich_text
      .map(t => t.plain_text)
      .join('');

    if (lang in code) {
      code[lang].push(text);
    }
  }

  return {
    html: code.html.join('\n'),
    css: code.css.join('\n'),
    js: code.javascript.join('\n'),
    jsx: code.jsx.join('\n'),
    tsx: code.tsx.join('\n'),
  };
}

/**
 * 페이지의 last_edited_time 조회 (캐시 판단용)
 */
async function getPageLastEdited(pageId, token) {
  const res = await fetch(`${NOTION_API}/pages/${pageId}`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Notion-Version': NOTION_VERSION,
    },
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.last_edited_time;
}
