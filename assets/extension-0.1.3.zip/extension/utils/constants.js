(function (global) {
  'use strict';

  var ns = global.CodePreviewerUtils = global.CodePreviewerUtils || {};

  ns.CDN_URLS = Object.assign({}, ns.CDN_URLS, {
    react: 'https://unpkg.com/react@18/umd/react.production.min.js',
    reactDom: 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js',
    babel: 'https://unpkg.com/@babel/standalone/babel.min.js',
    tailwind: 'https://cdn.tailwindcss.com',
    esmBase: 'https://esm.sh/'
  });

  ns.ERROR_MESSAGES = Object.assign({}, ns.ERROR_MESSAGES, {
    NO_TOKEN: 'Notion 연결이 필요합니다',
    TOKEN_EXPIRED: 'Notion 토큰이 만료되었습니다. 재연결해주세요',
    NO_PAGE: '노션 페이지를 열어주세요',
    NO_ACCESS: '이 페이지에 접근 권한이 없습니다. Integration에 페이지를 공유해주세요',
    PAGE_NOT_FOUND: '페이지를 찾을 수 없습니다',
    NO_CODE_BLOCKS: '이 페이지에 코드블록이 없습니다',
    RATE_LIMITED: 'Notion API 요청 횟수 초과. 잠시 후 다시 시도해주세요',
    GITHUB_TOKEN_EXPIRED: 'GitHub 토큰이 만료되었습니다. 다시 로그인해주세요',
    GITHUB_RATE_LIMITED: 'GitHub API 요청 횟수 초과. 잠시 후 다시 시도해주세요',
    NO_CODE: '배포할 코드가 없습니다.',
    DEPLOY_FAILED: '배포에 실패했습니다'
  });

  ns.REGEX = Object.assign({}, ns.REGEX, {
    PAGE_ID_TITLE_HEX: /-([a-f0-9]{32})(?:[?#]|$)/i,
    PAGE_ID_PURE_HEX: /\/([a-f0-9]{32})(?:[?#]|$)/i,
    PAGE_ID_UUID: /([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i,
    REACT_LIKE: /(?:ReactDOM|createRoot|React\.|useState|useEffect|useRef|useCallback|useMemo|useContext|useReducer)/,
    JSX_TAG: /<[A-Z][a-zA-Z]|(?:return|=>)\s*\(?<[a-zA-Z]/,
    REACT_IMPORT: /from\s+['"]react['"]/,
    BARE_IMPORT_STATIC: /import\s+(?:.*?\s+from\s+)?['"](?![./])(?!https?:\/\/)[^'"]+['"]/,
    BARE_IMPORT_DYNAMIC: /import\s*\(\s*['"](?![./])(?!https?:\/\/)[^'"]+['"]\s*\)/,
    ENTRY_FILE: /(?:createRoot|ReactDOM\.render)/,
    JAVASCRIPT_LIKE_LANG: /^(?:javascript|typescript)$/i,
    JSX_LIKE_LANG: /^(?:jsx|tsx)$/i
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
