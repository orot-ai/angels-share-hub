(function (global) {
  'use strict';

  var ns = global.CodePreviewerUtils = global.CodePreviewerUtils || {};
  var REGEX = ns.REGEX || {};

  function isJavaScriptLikeFile(file) {
    if (!file) return false;
    if (REGEX.JAVASCRIPT_LIKE_LANG.test(file.lang || '')) return true;
    if (file.filename && /\.(?:js|ts|jsx|tsx|mjs)$/i.test(file.filename)) return true;
    return false;
  }

  function isJsxLikeFile(file) {
    if (!file) return false;
    if (REGEX.JSX_LIKE_LANG.test(file.lang || '')) return true;
    if (!isJavaScriptLikeFile(file)) return false;
    if (file.filename && /\.(?:jsx|tsx)$/i.test(file.filename)) return true;
    return ns.looksLikeJSX(file.code || '');
  }

  function appendFileBlock(parts, file, includeLabels, strip) {
    var block = file.code || '';
    if (strip) block = ns.stripRelativeImports(ns.stripExports(block));
    if (includeLabels && file.filename) {
      parts.push('// --- ' + file.filename + ' ---\n' + block);
      return;
    }
    parts.push(block);
  }

  function buildScriptTag(mode, src, name) {
    if (!src) return '';
    var safeSrc = ns.escapeHtmlAttr(src);
    if (mode === 'preview') {
      return '<script src="' + safeSrc + '" onerror="console.error(\'[로드 실패] ' + name + ': ' + src + '\')"><\/script>\n';
    }
    if (mode === 'export' && (name === 'React' || name === 'ReactDOM')) {
      return '<script crossorigin src="' + safeSrc + '"><\/script>\n';
    }
    return '<script src="' + safeSrc + '"><\/script>\n';
  }

  function buildHTML(code, files, options) {
    code = code || {};
    files = files || [];
    options = options || {};

    var mode = options.mode || 'preview';
    var libUrls = options.libUrls || {};
    var includeLabels = mode !== 'deploy';
    var html = code.html || '';
    var css = code.css || '';
    var js = code.js || '';
    var jsx = code.jsx || '';
    var tsx = code.tsx || '';

    var namedCss = files.filter(function (f) { return f.lang === 'css' || (f.filename && /\.css$/i.test(f.filename)); });
    var namedHtml = files.filter(function (f) { return f.lang === 'html' || (f.filename && /\.html?$/i.test(f.filename)); });
    var namedJsxFiles = files.filter(function (f) { return isJsxLikeFile(f) && namedCss.indexOf(f) === -1 && namedHtml.indexOf(f) === -1; });
    var namedJsFiles = files.filter(function (f) {
      return isJavaScriptLikeFile(f) && !isJsxLikeFile(f) && namedCss.indexOf(f) === -1 && namedHtml.indexOf(f) === -1;
    });

    for (var ci = 0; ci < namedCss.length; ci++) css += '\n' + namedCss[ci].code;
    for (var hi = 0; hi < namedHtml.length; hi++) html += '\n' + namedHtml[hi].code;

    if (js && !jsx && !tsx && ns.looksLikeJSX(js)) {
      jsx = js;
      js = '';
    }

    var hasJSX = !!(jsx || tsx || namedJsxFiles.length > 0);
    var allJsxParts = [];
    if (namedJsxFiles.length > 0) {
      var nonEntry = namedJsxFiles.filter(function (f) { return !ns.isEntryFile(f.code); });
      var entry = namedJsxFiles.filter(function (f) { return ns.isEntryFile(f.code); });
      var ordered = nonEntry.concat(entry);
      for (var i = 0; i < ordered.length; i++) appendFileBlock(allJsxParts, ordered[i], includeLabels, false);
    }
    if (jsx) allJsxParts.push(jsx);
    if (tsx) allJsxParts.push(tsx);

    var mergedJsx = allJsxParts.join(';\n\n');
    mergedJsx = ns.convertAwaitImports(mergedJsx);

    var allJs = namedJsFiles.map(function (f) {
      var c = f.code;
      if (includeLabels && f.filename) return '// --- ' + f.filename + ' ---\n' + c;
      return c;
    });
    if (js) allJs.push(js);
    var mergedJs = allJs.join(';\n\n');
    mergedJs = ns.convertAwaitImports(mergedJs);

    // If JSX blocks exist and mergedJs also contains JSX syntax,
    // merge it into mergedJsx so it goes through Babel (avoids SyntaxError on raw <App/>)
    // and keeps everything in one script scope.
    if (hasJSX && mergedJs && ns.looksLikeJSX(mergedJs)) {
      mergedJsx = mergedJsx + ';\n\n' + mergedJs;
      mergedJs = '';
    }

    var hasImports = ns.hasBareImports(mergedJsx + '\n' + mergedJs);
    var jsHasImports = ns.hasBareImports(mergedJs);
    var head = '';

    if (options.bootstrapScript) head += options.bootstrapScript + '\n';

    if (mode === 'deploy') {
      head += '<meta property="og:type" content="website"/>\n';
      head += '<meta property="og:title" content="Notion Code Preview"/>\n';
      head += '<meta property="og:description" content="Built with Notion Code Previewer"/>\n';
      if (options.ogBaseUrl) {
        var ogImageUrl = ns.escapeHtmlAttr(options.ogBaseUrl + 'og-image.png');
        head += '<meta property="og:image" content="' + ogImageUrl + '"/>\n';
        head += '<meta property="og:image:width" content="1200"/>\n';
        head += '<meta property="og:image:height" content="630"/>\n';
        head += '<meta name="twitter:card" content="summary_large_image"/>\n';
        head += '<meta name="twitter:image" content="' + ogImageUrl + '"/>\n';
      }
    }

    // Favicon 자동 생성 (export/deploy 모드)
    if (mode === 'export' || mode === 'deploy') {
      head += '<link rel="icon" href="data:image/svg+xml,' + encodeURIComponent('<svg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 32 32\'><rect width=\'32\' height=\'32\' rx=\'6\' fill=\'%236366f1\'/><text x=\'16\' y=\'22\' text-anchor=\'middle\' font-size=\'18\' fill=\'white\' font-family=\'sans-serif\'>N</text></svg>') + '"/>\n';
    }

    head += buildScriptTag(mode, libUrls.tailwind, 'Tailwind');
    if (css) head += '<style>\n' + ns.escapeForStyle(css) + '\n</style>\n';

    var bodyEnd = '';

    var STRIP_PLUGIN_DEF =
      'var __stripPlugin=function(){return{visitor:{' +
      'ImportDeclaration:function(path){var src=path.node.source.value;if(src.indexOf("./")===0||src.indexOf("../")===0)path.remove();},' +
      'ExportDefaultDeclaration:function(path){var decl=path.node.declaration;if(decl.type==="FunctionDeclaration"||decl.type==="ClassDeclaration"){path.replaceWith(decl);}else{path.replaceWith({type:"VariableDeclaration",kind:"var",declarations:[{type:"VariableDeclarator",id:{type:"Identifier",name:"_default"},init:decl}]});}},' +
      'ExportNamedDeclaration:function(path){if(path.node.declaration){path.replaceWith(path.node.declaration);}else{path.remove();}},' +
      'ExportAllDeclaration:function(path){path.remove();}' +
      '}};};\n';

    // JSX text node 유니코드 이스케이프 디코딩
    // Babel은 JSX text(`<div>\uC11C</div>`)와 JSX 어트리뷰트 문자열(`placeholder="\uC11C"`)에서
    // \uXXXX를 JS 이스케이프가 아닌 리터럴 문자로 취급 (JSX 파싱 규칙).
    // JS 문자열 리터럴(`'\uC11C'`)은 런타임이 처리하므로 JSXText + JSXAttribute StringLiteral만 타겟팅.
    var DECODE_PLUGIN_DEF =
      'var __jsxDecodePlugin=function(){' +
      'function _d(v){' +
      'v=v.replace(/\\\\u\\{([0-9a-fA-F]+)\\}/g,function(_,h){return String.fromCodePoint(parseInt(h,16));});' +
      'v=v.replace(/\\\\u([0-9a-fA-F]{4})/g,function(_,h){return String.fromCharCode(parseInt(h,16));});' +
      'return v;}' +
      'return{visitor:{' +
      'JSXText:function(p){p.node.value=_d(p.node.value);},' +
      'StringLiteral:function(p){' +
      'if(!p.parent||p.parent.type!=="JSXAttribute")return;' +
      'p.node.value=_d(p.node.value);' +
      '}}}};\n';

    // 여러 파일을 하나의 스크립트로 병합 시 const/let 중복 선언 에러 방지
    // (예: 두 파일 모두 `const ITEMS_PER_PAGE = 6` 선언 시 Babel이 "already declared" 에러)
    // 동일 이름이 최상위 레벨에 중복 선언되면 첫 번째를 유지하고 이후를 제거한다.
    var DEDUPE_PLUGIN_DEF =
      'var __dedupePlugin=function(){var _s={};return{visitor:{' +
      'VariableDeclaration:function(p){' +
      'if(p.parent.type!=="Program")return;' +
      'if(p.node.kind!=="const"&&p.node.kind!=="let")return;' +
      'var kept=[];for(var i=0;i<p.node.declarations.length;i++){' +
      'var d=p.node.declarations[i];var n=d.id&&d.id.type==="Identifier"?d.id.name:null;' +
      'if(n&&_s[n]){}else{if(n)_s[n]=true;kept.push(d);}' +
      '}if(kept.length===0){p.remove();}else{p.node.declarations=kept;}' +
      '}}}};\n';

    if (hasJSX) {
      if (!hasImports) {
        head += buildScriptTag(mode, libUrls.react, 'React');
        head += buildScriptTag(mode, libUrls.reactDom, 'ReactDOM');
      }
      head += buildScriptTag(mode, libUrls.babel, 'Babel');
      head += '<script>if(window.Babel)Babel.disableScriptTags=true;</script>\n';

      if (!html || (html.indexOf('id="root"') === -1 && html.indexOf("id='root'") === -1)) {
        html = '<div id="root"></div>\n' + html;
      }

      if (hasImports) {
        mergedJsx = ns.ensureReactImport(mergedJsx);
        mergedJsx = ns.rewriteBareImports(mergedJsx);
        bodyEnd += '<script type="module">\n';
        bodyEnd += STRIP_PLUGIN_DEF;
        bodyEnd += DEDUPE_PLUGIN_DEF;
        bodyEnd += DECODE_PLUGIN_DEF;
        bodyEnd += 'var __code=' + ns.escapeForScript(JSON.stringify(mergedJsx)) + ';\n';
        bodyEnd += 'var __result=Babel.transform(__code,{filename:"app.tsx",presets:["react","typescript"],plugins:[__stripPlugin,__dedupePlugin,__jsxDecodePlugin],generatorOpts:{jsescOption:{minimal:true}},sourceType:"module"});\n';
        bodyEnd += 'var __s=document.createElement("script");__s.type="module";__s.textContent=__result.code;document.head.appendChild(__s);\n';
        bodyEnd += '<\/script>\n';
      } else {
        bodyEnd += '<script>\n';
        bodyEnd += STRIP_PLUGIN_DEF;
        bodyEnd += DEDUPE_PLUGIN_DEF;
        bodyEnd += DECODE_PLUGIN_DEF;
        bodyEnd += 'var __code=' + ns.escapeForScript(JSON.stringify(mergedJsx)) + ';\n';
        bodyEnd += 'var __result=Babel.transform(__code,{filename:"app.tsx",presets:["react","typescript"],plugins:[__stripPlugin,__dedupePlugin,__jsxDecodePlugin],generatorOpts:{jsescOption:{minimal:true}}});\n';
        bodyEnd += 'eval(__result.code);\n';
        bodyEnd += '<\/script>\n';
      }

      if (mergedJs) {
        var jsHasTS = /(?::\s*[A-Z]\w*[\s<|&]|:\s*(?:string|number|boolean|any|void|never|unknown)\b|interface\s+\w|type\s+\w+\s*[<=]|<\w+>|as\s+\w+\b)/.test(mergedJs);
        if (jsHasTS) {
          // TS in JS path — Babel 변환 필요 (Babel은 이미 JSX 경로에서 로드됨)
          if (jsHasImports) {
            var jsCode = ns.rewriteBareImports(mergedJs);
            bodyEnd += '<script type="module">\n';
            bodyEnd += STRIP_PLUGIN_DEF;
            bodyEnd += DEDUPE_PLUGIN_DEF;
            bodyEnd += 'var __jsCode=' + ns.escapeForScript(JSON.stringify(jsCode)) + ';\n';
            bodyEnd += 'var __jsResult=Babel.transform(__jsCode,{filename:"app.ts",presets:["typescript"],plugins:[__stripPlugin,__dedupePlugin,__jsxDecodePlugin],generatorOpts:{jsescOption:{minimal:true}},sourceType:"module"});\n';
            bodyEnd += 'var __s=document.createElement("script");__s.type="module";__s.textContent=__jsResult.code;document.head.appendChild(__s);\n';
            bodyEnd += '<\/script>\n';
          } else {
            bodyEnd += '<script>\n';
            bodyEnd += STRIP_PLUGIN_DEF;
            bodyEnd += DEDUPE_PLUGIN_DEF;
            bodyEnd += 'var __jsCode=' + ns.escapeForScript(JSON.stringify(mergedJs)) + ';\n';
            bodyEnd += 'var __jsResult=Babel.transform(__jsCode,{filename:"app.ts",presets:["typescript"],plugins:[__stripPlugin,__dedupePlugin,__jsxDecodePlugin],generatorOpts:{jsescOption:{minimal:true}}});\n';
            bodyEnd += 'eval(__jsResult.code);\n';
            bodyEnd += '<\/script>\n';
          }
        } else if (jsHasImports) {
          bodyEnd += '<script type="module">\n' + ns.escapeForScript(ns.stripRelativeImports(ns.rewriteBareImports(mergedJs))) + '\n<\/script>\n';
        } else {
          bodyEnd += '<script>\n' + ns.escapeForScript(ns.stripRelativeImports(ns.stripExports(mergedJs))) + '\n<\/script>\n';
        }
      }
    } else if (mergedJs) {
      // TypeScript 문법 감지: 타입 어노테이션(: type), interface, type 키워드 등
      var hasTypeScript = /(?::\s*[A-Z]\w*[\s<|&]|:\s*(?:string|number|boolean|any|void|never|unknown)\b|interface\s+\w|type\s+\w+\s*[<=]|<\w+>|as\s+\w+\b)/.test(mergedJs);
      if (hasTypeScript) {
        // TS는 Babel로 변환 필요
        head += buildScriptTag(mode, libUrls.babel, 'Babel');
        head += '<script>if(window.Babel)Babel.disableScriptTags=true;</script>\n';
        if (jsHasImports) {
          mergedJs = ns.rewriteBareImports(mergedJs);
          bodyEnd += '<script type="module">\n';
          bodyEnd += STRIP_PLUGIN_DEF;
          bodyEnd += DEDUPE_PLUGIN_DEF;
          bodyEnd += 'var __code=' + ns.escapeForScript(JSON.stringify(mergedJs)) + ';\n';
          bodyEnd += 'var __result=Babel.transform(__code,{filename:"app.ts",presets:["typescript"],plugins:[__stripPlugin,__dedupePlugin,__jsxDecodePlugin],generatorOpts:{jsescOption:{minimal:true}},sourceType:"module"});\n';
          bodyEnd += 'var __s=document.createElement("script");__s.type="module";__s.textContent=__result.code;document.head.appendChild(__s);\n';
          bodyEnd += '<\/script>\n';
        } else {
          bodyEnd += '<script>\n';
          bodyEnd += STRIP_PLUGIN_DEF;
          bodyEnd += DEDUPE_PLUGIN_DEF;
          bodyEnd += 'var __code=' + ns.escapeForScript(JSON.stringify(mergedJs)) + ';\n';
          bodyEnd += 'var __result=Babel.transform(__code,{filename:"app.ts",presets:["typescript"],plugins:[__stripPlugin,__dedupePlugin,__jsxDecodePlugin],generatorOpts:{jsescOption:{minimal:true}}});\n';
          bodyEnd += 'eval(__result.code);\n';
          bodyEnd += '<\/script>\n';
        }
      } else if (jsHasImports) {
        bodyEnd += '<script type="module">\n' + ns.escapeForScript(ns.stripRelativeImports(ns.rewriteBareImports(mergedJs))) + '\n<\/script>\n';
      } else {
        bodyEnd += '<script>\n' + ns.escapeForScript(ns.stripRelativeImports(ns.stripExports(mergedJs))) + '\n<\/script>\n';
      }
    }

    return '<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/>' + head + '</head><body>' + html + bodyEnd + '</body></html>';
  }

  ns.buildHTML = buildHTML;
})(typeof globalThis !== 'undefined' ? globalThis : self);
