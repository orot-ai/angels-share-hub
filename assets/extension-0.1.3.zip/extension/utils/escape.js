(function (global) {
  'use strict';

  var ns = global.CodePreviewerUtils = global.CodePreviewerUtils || {};

  function escapeForScript(code) {
    return String(code).replace(/<\/script/gi, '<\\/script');
  }

  function escapeForStyle(code) {
    return String(code).replace(/<\/style/gi, '<\\/style');
  }

  function escapeHtmlAttr(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  Object.assign(ns, {
    escapeForScript: escapeForScript,
    escapeForStyle: escapeForStyle,
    escapeHtmlAttr: escapeHtmlAttr
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
