(function (global) {
  'use strict';

  var ns = global.CodePreviewerUtils = global.CodePreviewerUtils || {};
  var REGEX = ns.REGEX || {};
  var CDN_URLS = ns.CDN_URLS || {};
  var ESM_BASE = CDN_URLS.esmBase || 'https://esm.sh/';

  function rewriteBareImports(code) {
    if (!code) return code;
    code = code.replace(
      /(from\s+['"])((?![./])(?!https?:\/\/)[^'"]+)(['"])/g,
      function (_, pre, specifier, post) {
        return pre + ESM_BASE + specifier + post;
      }
    );
    code = code.replace(
      /^(\s*import\s+['"])((?![./])(?!https?:\/\/)[^'"]+)(['"])/gm,
      function (_, pre, specifier, post) {
        return pre + ESM_BASE + specifier + post;
      }
    );
    code = code.replace(
      /(import\s*\(\s*['"])((?![./])(?!https?:\/\/)[^'"]+)(['"]\s*\))/g,
      function (_, pre, specifier, post) {
        return pre + ESM_BASE + specifier + post;
      }
    );
    return code;
  }

  function hasBareImports(code) {
    if (!code) return false;
    return REGEX.BARE_IMPORT_STATIC.test(code) || REGEX.BARE_IMPORT_DYNAMIC.test(code);
  }

  // Known limitation: these await-import rewrites intentionally handle only simple
  // bindings. Nested destructuring needs a real parser rather than regexes.
  function convertAwaitImports(code) {
    if (!code) return code;
    code = code.replace(
      /^\s*(?:const|let|var)\s+(\w+)\s*=\s*\(await\s+import\(['"]([^'"]+)['"]\)\)\.default\s*;?\s*$/gm,
      'import $1 from \'$2\';'
    );
    code = code.replace(
      /^\s*(?:const|let|var)\s+(\{[^}]+\})\s*=\s*await\s+import\(['"]([^'"]+)['"]\)\s*;?\s*$/gm,
      function (_, bindings, pkg) {
        var fixed = bindings.replace(/(\w+)\s*:\s*(\w+)/g, '$1 as $2');
        return 'import ' + fixed + ' from \'' + pkg + '\';';
      }
    );
    code = code.replace(
      /^\s*(?:const|let|var)\s+(\w+)\s*=\s*await\s+import\(['"]([^'"]+)['"]\)\s*;?\s*$/gm,
      'import * as $1 from \'$2\';'
    );
    return code;
  }

  // Known limitation: when a stripped relative import supplied local bindings,
  // those identifiers are still lost after merge. Fixing that correctly needs a parser.
  function stripRelativeImports(code) {
    return code
      .replace(/^\s*import\s+.*?\s+from\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '')
      .replace(/^\s*import\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '')
      .replace(/^\s*export\s+.*?\s+from\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '');
  }

  function stripExports(code) {
    return code
      .replace(/^\s*export\s+default\s+/gm, function (match, offset, str) {
        var rest = str.slice(offset + match.length);
        if (/^(?:function|class)\b/.test(rest)) return '';
        return 'var _default = ';
      })
      .replace(/^\s*export\s*\{[^}]*\}\s*;?\s*$/gm, '')
      .replace(/^\s*export\s*\*\s*from\s+['"][^'"]+['"]\s*;?\s*$/gm, '')
      .replace(/^\s*export\s+/gm, '');
  }

  function ensureReactImport(code) {
    if (!code) return code;
    var hasReactDefault = /import\s+React[\s,{]/.test(code) || /import\s+\*\s+as\s+React/.test(code);
    var hasAnyReactImport = REGEX.REACT_IMPORT.test(code);
    var hasReactDOMImport = /from\s+['"]react-dom/.test(code);
    if (hasReactDefault) {
      if (!hasReactDOMImport) return "import ReactDOM from 'react-dom/client';\n" + code;
      return code;
    }
    if (hasAnyReactImport) {
      var additions = "import React from 'react';\n";
      if (!hasReactDOMImport) additions += "import ReactDOM from 'react-dom/client';\n";
      return additions + code;
    }
    return "import React from 'react';\nimport ReactDOM from 'react-dom/client';\n" + code;
  }

  function decodeUnicodeEscapes(code) {
    if (!code) return code;
    // \u{XXXX} (ES2015+ 코드포인트 이스케이프)
    code = code.replace(/\\u\{([0-9a-fA-F]+)\}/g, function (_, hex) {
      return String.fromCodePoint(parseInt(hex, 16));
    });
    // \uXXXX (4자리 유니코드 이스케이프)
    // JS 스트링 리터럴에서는 엔진이 알아서 처리하지만, JSX 텍스트 노드에서는
    // Babel이 리터럴 문자로 처리해서 \uXXXX가 그대로 렌더링되는 버그 수정.
    // 서로게이트 쌍(\ud83e\udd43)도 각각 fromCharCode 후 JS 내부 UTF-16에서 자동으로 합쳐짐.
    code = code.replace(/\\u([0-9a-fA-F]{4})/g, function (_, hex) {
      return String.fromCharCode(parseInt(hex, 16));
    });
    return code;
  }

  function looksLikeJSX(code) {
    if (!code) return false;
    return REGEX.REACT_LIKE.test(code) || REGEX.JSX_TAG.test(code) || REGEX.REACT_IMPORT.test(code);
  }

  function isEntryFile(code) {
    return REGEX.ENTRY_FILE.test(code || '');
  }

  Object.assign(ns, {
    rewriteBareImports: rewriteBareImports,
    hasBareImports: hasBareImports,
    convertAwaitImports: convertAwaitImports,
    stripRelativeImports: stripRelativeImports,
    stripExports: stripExports,
    ensureReactImport: ensureReactImport,
    decodeUnicodeEscapes: decodeUnicodeEscapes,
    looksLikeJSX: looksLikeJSX,
    isEntryFile: isEntryFile
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
