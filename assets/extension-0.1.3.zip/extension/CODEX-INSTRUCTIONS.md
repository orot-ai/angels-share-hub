# Notion Code Previewer — Chrome Extension 개발 지시서

> Codex에게 주는 작업 지시서. 이 문서를 읽고 Extension을 완성해주세요.

---

## 프로젝트 개요

노션 페이지의 코드블록(HTML/CSS/JS/JSX/TSX)을 읽어서 Chrome Side Panel에서 실시간 프리뷰를 보여주는 Chrome Extension.

## 이미 만들어진 파일

- `manifest.json` — Manifest V3 기본 구조 완성됨
- `background/service-worker.js` — Notion API 호출, 토큰 관리, 메시지 허브, 캐시 로직 완성됨
- `utils/notion-api.js` — Notion API 래퍼 (참고용, service-worker에 인라인됨)

## 만들어야 할 파일

### 1. `content/content-script.js`

**역할**: 노션 페이지 URL에서 page_id를 추출하고, URL 변경을 감지하여 Service Worker에 알림.

**요구사항**:
- 노션 URL 패턴에서 page_id 추출 (32자리 hex)
  - 패턴 1: `notion.so/{workspace}/{title}-{32hex}`
  - 패턴 2: `notion.so/{workspace}/{32hex}`
  - 패턴 3: UUID 형태 (하이픈 포함) → 하이픈 제거
- 노션은 SPA이므로 URL 변경을 감지해야 함:
  - `history.pushState` / `history.replaceState` 가로채기
  - `popstate` 이벤트 리스너
  - `<title>` MutationObserver (노션이 페이지 이동 시 title 변경)
- page_id가 변경되면 `chrome.runtime.sendMessage({ type: 'PAGE_CHANGED', pageId })` 전송

### 2. `sidepanel/index.html`

**구조**:
```
┌─────────────────────────────┐
│ [status text]   [🔄 Refresh]│  ← toolbar
├─────────────────────────────┤
│                             │
│  [에러 메시지]              │  ← error-container (기본 숨김)
│  [misiso.com 링크]          │
│                             │
├─────────────────────────────┤
│                             │
│  [iframe 프리뷰]            │  ← flex:1, 전체 높이 차지
│                             │
└─────────────────────────────┘
```

### 3. `sidepanel/preview.js`

**역할**: 프리뷰 빌드 + 렌더링

**프리뷰 빌드 로직**:
- `html`, `css`, `js`, `jsx`, `tsx` 코드를 받아서 하나의 HTML 문서를 생성
- JSX/TSX가 있으면 React 모드:
  - React 18 CDN: `https://unpkg.com/react@18/umd/react.production.min.js`
  - ReactDOM 18 CDN: `https://unpkg.com/react-dom@18/umd/react-dom.production.min.js`
  - Babel Standalone: `https://unpkg.com/@babel/standalone/babel.min.js`
  - `<script type="text/babel" data-presets="react,typescript">`
- JSX/TSX가 없으면 일반 모드:
  - `<script>` 태그로 JS 실행
- Tailwind CSS CDN 항상 주입: `https://cdn.tailwindcss.com`
- `iframe.srcdoc`에 생성된 HTML을 설정

**이벤트 처리**:
- Refresh 버튼 클릭 → `chrome.runtime.sendMessage({ type: 'FETCH_CODE', pageId })`
- 쿨다운 1초 (Rate Limit 보호)
- Service Worker로부터 `PAGE_CHANGED` 메시지 수신 → currentPageId 업데이트
- 초기 로드 시 `GET_STATUS`로 현재 상태 확인

**에러 표시**:
- `NO_TOKEN` / `TOKEN_EXPIRED` → "Notion 연결이 필요합니다" + misiso.com 링크
- `NO_PAGE` → "노션 페이지를 열어주세요"
- 기타 → 에러 메시지 표시

### 4. `sidepanel/styles.css`

- 심플한 스타일. body는 flex column, 100vh
- toolbar: flex, space-between, 배경 #f7f7f7, 하단 border
- status: font-size 12px, color #666
- refresh 버튼: 작은 버튼, hover 시 배경 변경, disabled 시 opacity 0.5
- error-container: padding 20px, 중앙 정렬
- iframe: flex 1, border none, width 100%

### 5. `popup/index.html` + `popup/popup.js`

**간단한 popup**:
- 제목: "Notion Code Previewer"
- Notion 연결 상태 표시 (connected / disconnected)
- "misiso.com에서 설정하기 →" 링크
- 개발 중에는 토큰 수동 입력 필드 추가:
  - input 필드 + "저장" 버튼
  - `chrome.storage.local.set({ notionToken: inputValue })`로 저장
  - 이렇게 하면 OAuth 없이 Internal Integration 토큰으로 테스트 가능

### 6. 아이콘 생성

`icons/` 폴더에 간단한 아이콘 필요:
- icon16.png (16x16)
- icon48.png (48x48)
- icon128.png (128x128)
- 디자인: 심플하게 코드 brackets `</>` 또는 노션 스타일의 아이콘
- SVG로 만들어서 PNG로 변환하거나, canvas로 생성

---

## 기술 스택

- Chrome Extension Manifest V3
- Chrome Side Panel API
- Notion API v2022-06-28
- Babel Standalone (CDN) — JSX/TSX 트랜스파일
- React 18 (CDN) — JSX 프리뷰용
- Tailwind CSS (CDN) — 자동 주입

## 테스트 방법

1. `chrome://extensions` → 개발자 모드 ON → "압축해제된 확장 프로그램 로드" → `extension/` 폴더 선택
2. Popup에서 Notion Internal Integration 토큰 입력: `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`
3. 노션에서 코드블록이 있는 페이지 열기
4. Extension 아이콘 클릭 → Side Panel 열림
5. Refresh 클릭 → 프리뷰 확인

## 주의사항

- Service Worker는 이미 완성됨. 수정하지 말 것.
- manifest.json도 완성됨. 수정하지 말 것.
- `sidePanel.setPanelBehavior({ openPanelOnActionClick: true })` 가 service-worker에 이미 설정되어 있으므로, action 클릭 시 Side Panel이 열림. popup은 별도로 접근 (우클릭 등).
- iframe sandbox: `sandbox="allow-scripts allow-same-origin"` — Tailwind CDN 로드에 allow-same-origin 필요
- Babel Standalone은 ~3MB, 첫 로드 느릴 수 있음
