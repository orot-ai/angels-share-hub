// sidepanel/preview.js
(function () {
  'use strict';

  var statusEl = document.getElementById('status');
  var refreshBtn = document.getElementById('refresh');
  var errorContainer = document.getElementById('error-container');
  var errorMessage = document.getElementById('error-message');
  var errorLink = document.getElementById('error-link');
  var previewIframe = document.getElementById('preview');
  var consolePanel = document.getElementById('console-panel');
  var consoleLog = document.getElementById('console-log');
  var toggleConsoleBtn = document.getElementById('toggle-console');
  var clearConsoleBtn = document.getElementById('clear-console');
  var copyConsoleBtn = document.getElementById('copy-console');
  var fullscreenBtn = document.getElementById('fullscreen');
  var downloadZipBtn = document.getElementById('download-zip');
  var deployGithubBtn = document.getElementById('deploy-github');
  var deployBar = document.getElementById('deploy-bar');
  var deployStatus = document.getElementById('deploy-status');
  var deployUrl = document.getElementById('deploy-url');
  var deployCloseBtn = document.getElementById('deploy-close');
  var githubReconnectBtn = document.getElementById('github-reconnect');

  var lockPageBtn = document.getElementById('lock-page');

  var currentPageId = null;
  var currentCode = null; // 현재 프리뷰 중인 코드 데이터 저장
  var currentFiles = []; // 이름 있는 파일 목록
  var currentPreviewHtml = null; // 전체화면 전달용
  var isLoading = false;
  var consoleVisible = false;
  var errorCount = 0;
  var pendingHtml = null; // sandbox ready 전에 렌더 요청이 오면 대기
  var isPageLocked = false; // true면 자동 페이지 전환 방지
  var utils = globalThis.CodePreviewerUtils || {};
  var sharedCdnUrls = utils.CDN_URLS || {};
  var ERROR_MESSAGES = utils.ERROR_MESSAGES || {};
  var REGEX = utils.REGEX || {};

  // === Notion API fetch 인터셉터 (sandbox iframe 안에 주입) ===
  // 학생 코드에서 fetch('/api/notion/...') 호출 시 service worker를 통해 Notion API를 대신 호출.
  // 로컬 Next.js에서는 실제 API route가 같은 경로를 처리하므로 코드 변경 없이 동작.
  function buildFetchInterceptor() {
    return [
      '<script>',
      '(function(){',
      '  var __np={};var __ni=0;',
      '  window.addEventListener("message",function(e){',
      '    if(!e.data||e.data.type!=="__NP_RES")return;',
      '    var r=__np[e.data.id];if(!r)return;',
      '    delete __np[e.data.id];',
      '    if(e.data.err){r.reject(new Error(e.data.err));}',
      '    else{r.resolve(new Response(JSON.stringify(e.data.body),{status:e.data.status,headers:{"Content-Type":"application/json"}}));}',
      '  });',
      '  var _f=window.fetch;',
      '  window.fetch=function(url,opts){',
      '    var u=typeof url==="string"?url:String(url);',
      '    if(!u.startsWith("/api/notion/"))return _f.apply(this,arguments);',
      '    var path=u.slice("/api/notion".length);',
      '    var method=(opts&&opts.method)||"GET";',
      '    var body;try{body=opts&&opts.body?JSON.parse(opts.body):undefined;}catch(e){body=opts&&opts.body;}',
      '    var id=++__ni;',
      '    return new Promise(function(resolve,reject){',
      '      __np[id]={resolve:resolve,reject:reject};',
      '      parent.postMessage({type:"__NP_REQ",id:id,method:method,path:path,body:body},"*");',
      '    });',
      '  };',
      '})();',
      '<\/script>'
    ].join('');
  }

  // === URL에서 page_id 추출 ===
  function extractPageId(url) {
    if (!url) return null;
    try {
      var u = new URL(url);
      if (!u.hostname.endsWith('notion.so') && !u.hostname.endsWith('notion.site')) return null;
      var path = u.pathname;
      // 패턴 1: title-{32hex}
      var m = path.match(REGEX.PAGE_ID_TITLE_HEX || /-([a-f0-9]{32})(?:[?#]|$)/i);
      if (m) return m[1].toLowerCase();
      // 패턴 2: 순수 {32hex} (경로 끝)
      m = path.match(REGEX.PAGE_ID_PURE_HEX || /\/([a-f0-9]{32})(?:[?#]|$)/i);
      if (m) return m[1].toLowerCase();
      // 패턴 3: UUID 형태 (8-4-4-4-12)
      m = path.match(REGEX.PAGE_ID_UUID || /([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i);
      if (m) return m[1].replace(/-/g, '').toLowerCase();
      return null;
    } catch (e) { return null; }
  }

  async function getActiveTab() {
    try {
      var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      return tabs[0] || null;
    } catch (e) { return null; }
  }

  async function getActiveTabPageId() {
    var tab = await getActiveTab();
    return extractPageId(tab && tab.url);
  }

  // === 콘솔 패널 ===
  function addConsoleEntry(type, text) {
    var entry = document.createElement('div');
    entry.className = 'log-entry ' + type;
    entry.textContent = text;
    consoleLog.appendChild(entry);
    consoleLog.scrollTop = consoleLog.scrollHeight;
    if (type === 'error') {
      errorCount++;
      toggleConsoleBtn.classList.add('has-errors');
      toggleConsoleBtn.textContent = '\uD83D\uDC1B ' + errorCount;
      if (!consoleVisible) {
        consoleVisible = true;
        consolePanel.style.display = 'flex';
      }
    }
  }

  function clearConsole() {
    consoleLog.innerHTML = '';
    errorCount = 0;
    toggleConsoleBtn.classList.remove('has-errors');
    toggleConsoleBtn.textContent = '\uD83D\uDC1B';
  }

  toggleConsoleBtn.addEventListener('click', function () {
    consoleVisible = !consoleVisible;
    consolePanel.style.display = consoleVisible ? 'flex' : 'none';
  });

  clearConsoleBtn.addEventListener('click', clearConsole);

  copyConsoleBtn.addEventListener('click', function () {
    var entries = consoleLog.querySelectorAll('.log-entry');
    var text = Array.from(entries).map(function (el) {
      var level = el.classList.contains('error') ? '[ERROR]' : el.classList.contains('warn') ? '[WARN]' : '[LOG]';
      return level + ' ' + el.textContent;
    }).join('\n');
    navigator.clipboard.writeText(text).then(function () {
      copyConsoleBtn.textContent = 'Copied!';
      setTimeout(function () { copyConsoleBtn.textContent = 'Copy'; }, 1500);
    });
  });

  // === sandbox iframe 메시지 수신 (콘솔 캡처 + ready 신호 + Notion 프록시 릴레이) ===
  window.addEventListener('message', function (e) {
    // sandbox origin은 'null' (string)
    if (e.origin !== 'null' && !e.origin.startsWith('chrome-extension://')) return;
    if (!e.data) return;
    // 콘솔/에러 메시지
    if (e.data.__console) {
      addConsoleEntry(e.data.level, e.data.text);
    }
    // sandbox 준비 완료 → 대기 중인 HTML 전송
    if (e.data.type === 'SANDBOX_READY' && pendingHtml) {
      previewIframe.contentWindow.postMessage({ type: 'RENDER', html: pendingHtml }, '*');
      pendingHtml = null;
    }
    // Notion API 프록시 릴레이: sandbox fetch 인터셉터 → service worker → Notion API
    if (e.data.type === '__NP_REQ') {
      var reqId = e.data.id;
      chrome.runtime.sendMessage({
        type: 'NOTION_API_PROXY',
        request: { method: e.data.method, path: e.data.path, body: e.data.body }
      }, function (result) {
        if (!previewIframe.contentWindow) return;
        result = result || { error: 'NO_RESPONSE', status: 500 };
        previewIframe.contentWindow.postMessage({
          type: '__NP_RES',
          id: reqId,
          body: result.data,
          status: result.status || 500,
          err: result.error || null
        }, '*');
      });
    }
  });

  // === 로컬 라이브러리 URL (side panel에서 chrome API 접근 가능) ===
  var LIB_URLS = {
    tailwind: chrome.runtime.getURL('lib/tailwindcss.js'),
    react: chrome.runtime.getURL('lib/react.min.js'),
    reactDom: chrome.runtime.getURL('lib/react-dom.min.js'),
    babel: chrome.runtime.getURL('lib/babel.min.js'),
    html2canvas: chrome.runtime.getURL('lib/html2canvas.min.js'),
  };

  // === 프리뷰 HTML 빌드 ===
  // iframe 내부에 주입: 콘솔/에러 캡처 + IntersectionObserver 패치
  function buildBootstrapScript(html2canvasUrl) {
    return buildFetchInterceptor() + [
      '<script>',
      '(function(){',
      '  function send(level,args){',
      '    try{',
      '      var text=Array.prototype.slice.call(args).map(function(a){',
      '        if(a instanceof Error)return a.message+"\\n"+(a.stack||"");',
      '        if(typeof a==="object")try{return JSON.stringify(a,null,2)}catch(e){return String(a)}',
      '        return String(a);',
      '      }).join(" ");',
      '      parent.postMessage({__console:true,level:level,text:text},"*");',
      '    }catch(e){}',
      '  }',
      '  var oE=console.error,oW=console.warn,oL=console.log;',
      '  console.error=function(){send("error",arguments);oE.apply(console,arguments)};',
      '  console.warn=function(){send("warn",arguments);oW.apply(console,arguments)};',
      '  console.log=function(){send("log",arguments);oL.apply(console,arguments)};',
      '  window.onerror=function(msg,src,line,col,err){',
      '    var d=msg;',
      '    if(line)d+=" (line "+line+(col?":"+col:"")+")";',
      '    if(err&&err.stack)d+="\\n"+err.stack;',
      '    send("error",[d]);',
      '  };',
      '  window.addEventListener("unhandledrejection",function(e){',
      '    send("error",["Unhandled Promise: "+(e.reason&&e.reason.message||e.reason||"unknown")]);',
      '  });',
      // IntersectionObserver: 네이티브 동작 유지 (Side Panel에서 정상 스크롤 감지)
      // 스크린샷 캡처 리스너 (html2canvas 동적 로드)
      '  window.addEventListener("message",function(e){',
      '    if(e.data&&e.data.type==="CAPTURE_SCREENSHOT"){',
      '      var s=document.createElement("script");',
      '      s.src="' + html2canvasUrl + '";',
      '      s.onload=function(){',
      '        html2canvas(document.body,{',
      '          useCORS:true,allowTaint:true,',
      '          width:1200,height:630,scale:1,',
      '          windowWidth:1200,windowHeight:630',
      '        }).then(function(canvas){',
      '          parent.postMessage({type:"SCREENSHOT_RESULT",dataUrl:canvas.toDataURL("image/png")},"*");',
      '        }).catch(function(err){',
      '          parent.postMessage({type:"SCREENSHOT_RESULT",error:err.message},"*");',
      '        });',
      '      };',
      '      s.onerror=function(){',
      '        parent.postMessage({type:"SCREENSHOT_RESULT",error:"html2canvas load failed"},"*");',
      '      };',
      '      document.head.appendChild(s);',
      '    }',
      '  });',
      '})();',
      '<\/script>'
    ].join('\n');
  }

  function buildPreviewHTML(code, files) {
    return utils.buildHTML(code, files, {
      mode: 'preview',
      libUrls: {
        tailwind: LIB_URLS.tailwind,
        react: LIB_URLS.react,
        reactDom: LIB_URLS.reactDom,
        babel: LIB_URLS.babel
      },
      bootstrapScript: buildBootstrapScript(LIB_URLS.html2canvas)
    });
  }

  function buildExportHTML(code, files) {
    return utils.buildHTML(code, files, {
      mode: 'export',
      libUrls: {
        tailwind: sharedCdnUrls.tailwind,
        react: sharedCdnUrls.react,
        reactDom: sharedCdnUrls.reactDom,
        babel: sharedCdnUrls.babel
      }
    });
  }

  // === UI 상태 관리 ===

  function showLoading() {
    isLoading = true;
    statusEl.textContent = '\uBD88\uB7EC\uC624\uB294 \uC911...';
    errorContainer.style.display = 'none';
    deployBar.style.display = 'none';
    clearConsole();
  }

  function showError(errorCode) {
    isLoading = false;
    currentCode = null;
    currentFiles = [];
    previewIframe.style.display = 'none';
    errorContainer.style.display = 'flex';
    errorMessage.textContent = ERROR_MESSAGES[errorCode] || ('\uC624\uB958: ' + errorCode);
    errorLink.style.display = (errorCode === 'NO_TOKEN' || errorCode === 'TOKEN_EXPIRED') ? 'inline' : 'none';
    statusEl.textContent = ERROR_MESSAGES[errorCode] ? errorCode : '\uC624\uB958';
  }

  function showPreview(previewHtml, cached) {
    isLoading = false;
    errorContainer.style.display = 'none';
    previewIframe.style.display = 'block';

    // sandbox iframe 완전 리로드 (캐시 버스터로 이전 상태 제거)
    pendingHtml = previewHtml;
    previewIframe.src = '../sandbox/preview.html?t=' + Date.now();
    // onload 시에도 전송 시도 (SANDBOX_READY가 안 올 경우 대비)
    previewIframe.onload = function () {
      if (pendingHtml) {
        setTimeout(function () {
          if (pendingHtml) {
            previewIframe.contentWindow.postMessage({ type: 'RENDER', html: pendingHtml }, '*');
            pendingHtml = null;
          }
        }, 50);
      }
    };

    statusEl.textContent = cached ? '\uD504\uB9AC\uBDF0 (\uCE90\uC2DC)' : '\uD504\uB9AC\uBDF0 \uC5C5\uB370\uC774\uD2B8\uB428';
  }

  // === 코드 가져오기 + 렌더링 ===
  var _fetchRequestId = 0;

  async function fetchAndRender(pageId) {
    if (!pageId) { showError('NO_PAGE'); return; }
    // No isLoading guard — the _fetchRequestId counter already discards stale results,
    // so a new call during loading will simply supersede the previous one.
    var requestId = ++_fetchRequestId;
    showLoading();

    try {
      var res = await chrome.runtime.sendMessage({ type: 'FETCH_CODE', pageId: pageId });
      // race condition: 새 요청이 시작되었으면 이 응답은 무시
      if (requestId !== _fetchRequestId) {
        isLoading = false;
        return;
      }
      if (!res || res.error) { showError(res ? res.error : 'UNKNOWN'); return; }

      // 디버그: 추출된 코드 정보
      var codeInfo = [];
      if (res.code.html) codeInfo.push('HTML: ' + res.code.html.length + 'chars');
      if (res.code.css) codeInfo.push('CSS: ' + res.code.css.length + 'chars');
      if (res.code.js) codeInfo.push('JS: ' + res.code.js.length + 'chars');
      if (res.code.jsx) codeInfo.push('JSX: ' + res.code.jsx.length + 'chars');
      if (res.code.tsx) codeInfo.push('TSX: ' + res.code.tsx.length + 'chars');
      addConsoleEntry('log', '[Code Previewer] \uCD94\uCD9C\uB41C \uCF54\uB4DC: ' + codeInfo.join(', '));
      if (res.debugInfo) {
        addConsoleEntry('log', '[Code Previewer] \uBE14\uB85D \uC815\uBCF4: \uC804\uCCB4 ' + res.debugInfo.totalBlocks + '\uAC1C, \uCF54\uB4DC\uBE14\uB85D ' + res.debugInfo.codeBlocks + '\uAC1C');
        addConsoleEntry('log', '[Code Previewer] \uC5B8\uC5B4\uBCC4: ' + JSON.stringify(res.debugInfo.languages));
      }
      if (res.code.js && !res.code.jsx && !res.code.tsx && utils.looksLikeJSX(res.code.js)) {
        addConsoleEntry('log', '[Code Previewer] JS에서 React API 감지 → Babel 트랜스파일 모드로 전환');
      }

      currentCode = res.code;
      currentFiles = res.files || [];
      currentPreviewHtml = buildPreviewHTML(res.code, currentFiles);
      showPreview(currentPreviewHtml, res.cached);
    } catch (err) {
      if (requestId !== _fetchRequestId) { isLoading = false; return; }
      showError(err.message || 'UNKNOWN');
    }
  }

  // === Refresh ===
  refreshBtn.addEventListener('click', async function () {
    if (isLoading) return;
    var pageId = await getActiveTabPageId();
    if (pageId) currentPageId = pageId;

    if (currentPageId) {
      // 캐시 무효화
      await chrome.runtime.sendMessage({ type: 'CLEAR_CACHE' }).catch(function () {});
    }
    await fetchAndRender(currentPageId);
  });

  // === 페이지 고정 ===
  lockPageBtn.addEventListener('click', function () {
    isPageLocked = !isPageLocked;
    lockPageBtn.classList.toggle('active', isPageLocked);
    lockPageBtn.title = isPageLocked
      ? '페이지 고정 중 — 클릭하여 해제'
      : '현재 페이지 고정 (자동 페이지 전환 방지)';
  });

  // === PAGE_CHANGED 메시지 수신 ===
  chrome.runtime.onMessage.addListener(function (message) {
    if (message.type !== 'PAGE_CHANGED') return;
    if (isPageLocked) return;
    getActiveTab().then(function (tab) {
      if (typeof message.tabId === 'number' && (!tab || tab.id !== message.tabId)) return;
      if (message.pageId !== currentPageId) {
        currentPageId = message.pageId;
        fetchAndRender(currentPageId);
      }
    }).catch(function () {});
  });

  // === 탭 URL 폴링 (2초) ===
  setInterval(function () {
    if (isPageLocked) return;
    getActiveTabPageId().then(function (pageId) {
      if (pageId && pageId !== currentPageId) {
        currentPageId = pageId;
        fetchAndRender(currentPageId);
      } else if (!pageId && currentPageId) {
        // pageId 없는 Notion 경로(홈, 검색 등)로 이동 시 초기화
        currentPageId = null;
        currentCode = null;
        currentFiles = [];
        showError('NO_PAGE');
      }
    }).catch(function () {});
  }, 2000);

  // === Next.js ZIP 빌더 ===

  // Next.js 모드 감지: currentFiles 중 경로에 '/'가 있거나 Next.js 특정 디렉토리로 시작하면 Next.js 프로젝트로 판단
  function isNextjsMode(files) {
    if (!files || files.length === 0) return false;
    return files.some(function (f) {
      return f.filename && f.filename.includes('/');
    });
  }

  var NEXTJS_NOTION_PROXY_ROUTE = [
    'import { NextResponse } from \'next/server\';',
    '',
    '// Notion API 프록시 — Notion Code Previewer에 의해 자동 생성.',
    '// fetch(\'/api/notion/databases/{id}/query\', { method: \'POST\', body: ... }) 형태로 사용.',
    'export async function POST(',
    '  request: Request,',
    '  { params }: { params: Promise<{ path: string[] }> }',
    ') {',
    '  const { path } = await params;',
    '  const notionPath = \'/\' + path.join(\'/\');',
    '  const body = await request.json().catch(() => undefined);',
    '  const res = await fetch(`https://api.notion.com/v1${notionPath}`, {',
    '    method: \'POST\',',
    '    headers: {',
    '      \'Authorization\': `Bearer ${process.env.NOTION_API_KEY}`,',
    '      \'Notion-Version\': \'2022-06-28\',',
    '      \'Content-Type\': \'application/json\',',
    '    },',
    '    body: body ? JSON.stringify(body) : undefined,',
    '  });',
    '  const data = await res.json();',
    '  return NextResponse.json(data, { status: res.status });',
    '}',
    '',
    'export async function GET(',
    '  _request: Request,',
    '  { params }: { params: Promise<{ path: string[] }> }',
    ') {',
    '  const { path } = await params;',
    '  const notionPath = \'/\' + path.join(\'/\');',
    '  const res = await fetch(`https://api.notion.com/v1${notionPath}`, {',
    '    headers: {',
    '      \'Authorization\': `Bearer ${process.env.NOTION_API_KEY}`,',
    '      \'Notion-Version\': \'2022-06-28\',',
    '    },',
    '  });',
    '  const data = await res.json();',
    '  return NextResponse.json(data, { status: res.status });',
    '}',
  ].join('\n');

  var NEXTJS_PACKAGE_JSON = function (name) {
    return JSON.stringify({
      name: name,
      version: '0.1.0',
      private: true,
      scripts: { dev: 'next dev', build: 'next build', start: 'next start' },
      dependencies: { next: '^15.0.0', react: '^19.0.0', 'react-dom': '^19.0.0' },
      devDependencies: {
        typescript: '^5',
        '@types/node': '^20',
        '@types/react': '^19',
        '@types/react-dom': '^19',
        tailwindcss: '^4',
      },
    }, null, 2);
  };

  var NEXTJS_TSCONFIG = JSON.stringify({
    compilerOptions: {
      target: 'ES2017',
      lib: ['dom', 'dom.iterable', 'esnext'],
      allowJs: true,
      skipLibCheck: true,
      strict: true,
      noEmit: true,
      esModuleInterop: true,
      module: 'esnext',
      moduleResolution: 'bundler',
      resolveJsonModule: true,
      isolatedModules: true,
      jsx: 'preserve',
      incremental: true,
      plugins: [{ name: 'next' }],
      paths: { '@/*': ['./*'] },
    },
    include: ['next-env.d.ts', '**/*.ts', '**/*.tsx', '.next/types/**/*.ts'],
    exclude: ['node_modules'],
  }, null, 2);

  var NEXTJS_ENV_LOCAL = [
    '# Notion API Key',
    '# developers.notion.com에서 Integration 생성 후 입력',
    'NOTION_API_KEY=your_notion_api_key_here',
  ].join('\n');

  var NEXTJS_GITIGNORE = [
    'node_modules/',
    '.next/',
    '.env.local',
    'out/',
  ].join('\n');

  async function buildNextjsZip(files, pageName) {
    var zip = new JSZip();
    var projectName = (pageName || 'my-project')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'my-project';

    // 사용자 파일 — 캡션 경로 그대로
    for (var i = 0; i < files.length; i++) {
      zip.file(files[i].filename, files[i].code);
    }

    // Notion API 프록시 route 자동 생성
    zip.file('app/api/notion/[...path]/route.ts', NEXTJS_NOTION_PROXY_ROUTE);

    // 보일러플레이트
    zip.file('package.json', NEXTJS_PACKAGE_JSON(projectName));
    zip.file('tsconfig.json', NEXTJS_TSCONFIG);
    zip.file('.env.local', NEXTJS_ENV_LOCAL);
    zip.file('.gitignore', NEXTJS_GITIGNORE);

    var blob = await zip.generateAsync({ type: 'blob' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = projectName + '-nextjs.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // === 전체화면 보기 ===
  fullscreenBtn.addEventListener('click', async function () {
    if (!currentPreviewHtml) {
      addConsoleEntry('warn', '[Code Previewer] 먼저 Refresh로 프리뷰를 로드해주세요.');
      return;
    }
    // 전체화면은 sandbox/preview.html을 통해 렌더링 (manifest sandbox CSP 적용).
    // buildPreviewHTML은 로컬 chrome-extension:// lib URL + fetch interceptor를 이미 포함.
    // CDN URL HTML(buildExportHTML)은 manifest sandbox CSP가 차단하므로 사용 불가.
    await chrome.storage.local.set({ fullscreenHtml: currentPreviewHtml });
    chrome.tabs.create({ url: chrome.runtime.getURL('fullscreen/index.html') });
  });

  // === ZIP 다운로드 ===
  downloadZipBtn.addEventListener('click', async function () {
    if (!currentCode) {
      addConsoleEntry('warn', '[Code Previewer] 다운로드할 코드가 없습니다. 먼저 노션 페이지를 열어주세요.');
      return;
    }

    try {
      downloadZipBtn.disabled = true;
      downloadZipBtn.textContent = '⏳';

      // Next.js 모드: 파일 경로 기반 코드블록이 있으면 Next.js 프로젝트로 다운로드
      if (isNextjsMode(currentFiles)) {
        addConsoleEntry('log', '[Code Previewer] Next.js 프로젝트로 다운로드 시작...');
        await buildNextjsZip(currentFiles, currentPageId || 'notion-project');
        addConsoleEntry('log', '[Code Previewer] Next.js ZIP 다운로드 완료. pnpm install && pnpm dev 로 시작하세요.');
        addConsoleEntry('log', '[Code Previewer] .env.local 에 NOTION_API_KEY를 입력하면 Notion DB 연동이 활성화됩니다.');
        return;
      }

      var zip = new JSZip();

      // 통합 HTML 파일 (CDN URL 사용 — 외부에서 정상 동작)
      zip.file('index.html', buildExportHTML(currentCode, currentFiles));

      // 개별 파일 (존재하는 것만)
      if (currentCode.css) {
        zip.file('style.css', currentCode.css);
      }
      if (currentCode.js) {
        zip.file('script.js', currentCode.js);
      }
      if (currentCode.jsx) {
        zip.file('App.jsx', currentCode.jsx);
      }
      if (currentCode.tsx) {
        zip.file('App.tsx', currentCode.tsx);
      }
      if (currentCode.html) {
        zip.file('template.html', currentCode.html);
      }
      // 이름 있는 파일들 (src/ 하위에 저장하여 기본 파일명과 충돌 방지)
      for (var fi = 0; fi < currentFiles.length; fi++) {
        zip.file('src/' + currentFiles[fi].filename, currentFiles[fi].code);
      }

      var blob = await zip.generateAsync({ type: 'blob' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'notion-code-preview.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      addConsoleEntry('log', '[Code Previewer] ZIP 다운로드 완료');
    } catch (err) {
      addConsoleEntry('error', '[Code Previewer] ZIP 생성 실패: ' + (err.message || err));
    } finally {
      downloadZipBtn.disabled = false;
      downloadZipBtn.textContent = '💾';
    }
  });

  // === 스크린샷 캡처 ===
  function captureScreenshot() {
    return new Promise(function (resolve, reject) {
      var timeout = setTimeout(function () {
        window.removeEventListener('message', handler);
        reject(new Error('Screenshot timeout'));
      }, 10000);

      function handler(e) {
        if (e.data && e.data.type === 'SCREENSHOT_RESULT') {
          clearTimeout(timeout);
          window.removeEventListener('message', handler);
          if (e.data.error) reject(new Error(e.data.error));
          else resolve(e.data.dataUrl);
        }
      }
      window.addEventListener('message', handler);
      previewIframe.contentWindow.postMessage({ type: 'CAPTURE_SCREENSHOT' }, '*');
    });
  }

  // === GitHub 배포 ===
  function showDeployBar(message, type, showReconnect) {
    deployBar.style.display = 'flex';
    deployBar.className = type || '';
    deployStatus.textContent = message;
    if (type !== 'success') {
      deployUrl.style.display = 'none';
    }
    githubReconnectBtn.style.display = showReconnect ? 'inline-block' : 'none';
  }

  deployCloseBtn.addEventListener('click', function () {
    deployBar.style.display = 'none';
  });

  githubReconnectBtn.addEventListener('click', async function () {
    githubReconnectBtn.style.display = 'none';
    showDeployBar('GitHub 재연결 중...', 'loading');
    await chrome.storage.local.remove('githubToken');
    deployGithubBtn.click();
  });

  deployGithubBtn.addEventListener('click', async function () {
    if (!currentCode) {
      addConsoleEntry('warn', '[Deploy] 배포할 코드가 없습니다. 먼저 노션 페이지를 열어주세요.');
      return;
    }
    if (!currentPageId) {
      addConsoleEntry('warn', '[Deploy] 페이지 ID를 확인할 수 없습니다.');
      return;
    }

    try {
      deployGithubBtn.disabled = true;
      deployGithubBtn.classList.add('deploying');

      // 1단계: GitHub 토큰 확인/획득
      var tokenCheck = await chrome.runtime.sendMessage({ type: 'GITHUB_CHECK_TOKEN' });
      if (!tokenCheck.hasToken) {
        showDeployBar('GitHub 로그인 중...', 'loading');
        addConsoleEntry('log', '[Deploy] GitHub OAuth 시작...');
        var authRes = await chrome.runtime.sendMessage({ type: 'GITHUB_AUTH' });
        if (authRes.error) {
          showDeployBar('GitHub 로그인 실패: ' + authRes.error, 'error', true);
          addConsoleEntry('error', '[Deploy] OAuth 실패: ' + authRes.error);
          return;
        }
        addConsoleEntry('log', '[Deploy] GitHub 연결 완료!');
      }

      // 2단계: 스크린샷 캡처 (best-effort)
      var screenshotDataUrl = null;
      try {
        showDeployBar('프리뷰 스크린샷 캡처 중...', 'loading');
        addConsoleEntry('log', '[Deploy] OG 이미지용 스크린샷 캡처 중...');
        screenshotDataUrl = await captureScreenshot();
        addConsoleEntry('log', '[Deploy] 스크린샷 캡처 완료');
      } catch (screenshotErr) {
        addConsoleEntry('warn', '[Deploy] 스크린샷 캡처 실패 (OG 이미지 없이 배포): ' + screenshotErr.message);
      }

      // 3단계: 배포
      showDeployBar('GitHub에 배포 중...', 'loading');
      addConsoleEntry('log', '[Deploy] GitHub 배포 시작...');
      addConsoleEntry('log', '[Deploy] GitHub Pages는 공개 저장소에서만 무료입니다. 코드가 공개됩니다.');

      var res = await chrome.runtime.sendMessage({
        type: 'GITHUB_DEPLOY',
        code: currentCode,
        files: currentFiles,
        pageId: currentPageId,
        screenshotDataUrl: screenshotDataUrl
      });

      if (res.error) {
        var errorMsg = res.error;
        if (res.error === 'GITHUB_TOKEN_EXPIRED') {
          addConsoleEntry('log', '[Deploy] GitHub 토큰 만료 — 재인증 후 자동 재배포...');
          var reAuthRes = await chrome.runtime.sendMessage({ type: 'GITHUB_AUTH' });
          if (!reAuthRes.error) {
            // 재인증 성공 → 배포 재시도
            showDeployBar('재인증 완료, 다시 배포 중...', 'loading');
            res = await chrome.runtime.sendMessage({
              type: 'GITHUB_DEPLOY',
              code: currentCode,
              files: currentFiles,
              pageId: currentPageId,
              screenshotDataUrl: screenshotDataUrl
            });
            if (!res.error) {
              // 재배포 성공 — 아래 성공 처리로 진행
              showDeployBar('배포 완료! (첫 배포 시 1~2분 후 접속 가능)', 'success');
              deployUrl.href = res.url;
              deployUrl.textContent = res.url;
              deployUrl.style.display = 'inline';
              addConsoleEntry('log', '[Deploy] 재배포 완료: ' + res.url);
              addConsoleEntry('log', '[Deploy] GitHub Repo: ' + res.repo);
              if (res.proxyRegisterError) {
                addConsoleEntry('error', '[Deploy] DB 연동 실패 — ' + res.proxyRegisterError);
              } else {
                addConsoleEntry('log', '[Deploy] DB 연동 등록 완료.');
              }
              return;
            }
            errorMsg = res.error;
          } else {
            errorMsg = 'GitHub 재인증 실패: ' + reAuthRes.error;
          }
        } else if (res.error === 'NO_CODE') {
          errorMsg = '배포할 코드가 없습니다.';
        }
        var isAuthError = errorMsg.includes('재인증') || errorMsg.includes('토큰') || errorMsg.includes('OAuth');
        showDeployBar(errorMsg, 'error', isAuthError);
        addConsoleEntry('error', '[Deploy] 실패: ' + errorMsg);
        return;
      }

      showDeployBar('배포 완료! (첫 배포 시 1~2분 후 접속 가능)', 'success');
      deployUrl.href = res.url;
      deployUrl.textContent = res.url;
      deployUrl.style.display = 'inline';
      addConsoleEntry('log', '[Deploy] 배포 완료: ' + res.url);
      addConsoleEntry('log', '[Deploy] GitHub Repo: ' + res.repo);
      addConsoleEntry('log', '[Deploy] 첫 배포는 GitHub Pages 활성화에 1~2분 소요됩니다.');
      if (res.proxyRegisterError) {
        addConsoleEntry('error', '[Deploy] DB 연동 실패 — ' + res.proxyRegisterError);
        addConsoleEntry('warn', '[Deploy] DB 연동 없이 배포됨. 배포 페이지에서 DB 연동이 동작하지 않습니다.');
      } else {
        addConsoleEntry('log', '[Deploy] DB 연동 등록 완료.');
      }
    } catch (err) {
      showDeployBar('배포 실패: ' + (err.message || '알 수 없는 오류'), 'error');
      addConsoleEntry('error', '[Deploy] 오류: ' + (err.message || err));
    } finally {
      deployGithubBtn.disabled = false;
      deployGithubBtn.classList.remove('deploying');
    }
  });

  // === 초기 로드 ===
  async function init() {
    var data = await chrome.storage.local.get('notionToken');
    if (!data.notionToken) { showError('NO_TOKEN'); return; }
    var pageId = await getActiveTabPageId();
    if (pageId) {
      currentPageId = pageId;
      fetchAndRender(currentPageId);
    } else {
      showError('NO_PAGE');
    }
  }

  init();
})();
