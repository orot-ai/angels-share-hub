// content/content-script.js
// 노션 URL에서 page_id를 추출하고 URL 변경을 감지하여 Service Worker에 알림

(function () {
  'use strict';

  let currentPageId = null;
  let lastUrl = '';

  function extractPageId(url) {
    try {
      const u = new URL(url);
      if (!u.hostname.endsWith('notion.so') && !u.hostname.endsWith('notion.site')) return null;

      const pathname = u.pathname;

      // title-{32hex} 패턴
      const titleHex = pathname.match(/-([a-f0-9]{32})(?:[?#]|$)/i);
      if (titleHex) return titleHex[1].toLowerCase();

      // 순수 {32hex} 패턴 (경로 끝)
      const segments = pathname.split('/').filter(Boolean);
      const lastSeg = segments[segments.length - 1] ?? '';
      const pureHex = lastSeg.match(/^([a-f0-9]{32})$/i);
      if (pureHex) return pureHex[1].toLowerCase();

      // UUID 형태 (8-4-4-4-12)
      const uuid = pathname.match(
        /([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i
      );
      if (uuid) return uuid[1].replace(/-/g, '').toLowerCase();

      return null;
    } catch {
      return null;
    }
  }

  let pollTimer = null;

  function onUrlChange() {
    try {
      if (!chrome.runtime?.id) {
        // context 무효화 — 폴링·이벤트 정리
        if (pollTimer) clearInterval(pollTimer);
        window.removeEventListener('popstate', onUrlChange);
        // H-O1: history 패치 복구 — 이중 래핑 방지
        history.pushState = origPush;
        history.replaceState = origReplace;
        return;
      }
    } catch {
      if (pollTimer) clearInterval(pollTimer);
      // H-O1: context 접근 실패 시에도 history 패치 복구
      history.pushState = origPush;
      history.replaceState = origReplace;
      return;
    }

    const url = window.location.href;
    if (url === lastUrl) return;
    lastUrl = url;

    const pageId = extractPageId(url);
    if (pageId && pageId !== currentPageId) {
      currentPageId = pageId;
      chrome.runtime.sendMessage({ type: 'PAGE_CHANGED', pageId }).catch(() => {});
    }
  }

  // pushState / replaceState 가로채기
  const origPush = history.pushState;
  const origReplace = history.replaceState;

  history.pushState = function (...args) {
    origPush.apply(this, args);
    onUrlChange();
  };
  history.replaceState = function (...args) {
    origReplace.apply(this, args);
    onUrlChange();
  };

  window.addEventListener('popstate', onUrlChange);

  // URL 폴링 (노션 SPA가 pushState 안 쓰는 경우 대비)
  pollTimer = setInterval(onUrlChange, 1000);

  // 초기 실행
  onUrlChange();
})();
