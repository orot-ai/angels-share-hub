# service-worker.js 코드 리뷰 보고서

**파일 경로:** `extension/background/service-worker.js`
**리뷰 날짜:** 2026-03-30
**총 라인 수:** 717

---

## 요약

| 심각도 | 건수 |
|--------|------|
| Critical | 3 |
| High | 7 |
| Medium | 6 |
| Low | 5 |
| **합계** | **21** |

---

## 1. `extractFilename` / `extractCode` — 정확성 및 엣지 케이스

---

### [HIGH-01] `extractFilename`: 캡션 정규식이 경로 구분자 `\` 를 허용하지 않음

**위치:** line 43

```js
if (caption && /^[\w./\-]+\.\w+$/.test(caption)) return caption;
```

**문제:**
- 윈도우 스타일 경로(`components\Button.jsx`)는 매칭 실패.
- 캡션에 공백 포함 경로(`my component/Button.jsx`)도 실패.
- `\w` 는 `[a-zA-Z0-9_]` 이므로 파일명에 `-`, `@` 등이 포함될 경우도 실패. 예: `@types/react.d.ts`.

**수정:**
```js
if (caption && /^[\w./@\-\\]+\.\w+$/.test(caption)) return caption;
```
또는 캡션 검증을 단순화:
```js
if (caption && /\.\w+$/.test(caption) && !/\s/.test(caption)) return caption;
```

---

### [MEDIUM-01] `extractFilename`: 첫 줄 주석 파일명 정규식이 공백 포함 경로를 차단함

**위치:** line 47

```js
const commentMatch = firstLine?.match(/^\/\/\s*(\S+\.\w+)\s*$/);
```

**문제:**
- `// src/components/Button.jsx` — 정상 동작.
- `// Button Component.jsx` — `\S+` 이 공백을 포함하지 않으므로 `Button` 만 캡처되어 `Button.jsx` 가 아닌 `Button` 이 되어 조건 실패.
- 실제로는 큰 문제가 아닐 수 있으나, `(\S+\.\w+)` 에서 `\S+` 내에 이미 `.` 이 포함될 수 있어 탐욕적 매칭 시 의도와 다른 파일명을 추출할 위험이 있음. 예: `// app.config.js` → `app.config.js` (이 경우는 정상이지만, `// app.v2.config.js` → `app.v2.config.js` 정상, 의도적인지 확인 필요).

**수정 제안:** 현재 동작은 대부분 의도적이나 주석으로 명시 필요.

---

### [HIGH-02] `extractCode`: 첫 줄 주석 제거 조건이 반전되어 있음

**위치:** line 65-67

```js
if (filename && !((block.code.caption || []).length > 0)) {
  text = text.replace(/^\/\/\s*\S+\.\w+\s*\n/, '');
}
```

**문제:**
- `caption.length > 0` 이면 캡션에서 파일명을 얻은 경우이므로 코드 첫 줄을 제거하면 안 됨.
- `!((block.code.caption || []).length > 0)` 는 `caption이 없을 때 true` 이므로, 캡션 없이 첫 줄 주석에서 파일명을 얻었을 때만 첫 줄을 제거함 — 로직 자체는 맞음.

**하지만 가독성 버그 위험이 높음.** 이중 부정(`!(...length > 0)`)은 `length === 0` 이지만, `extractFilename` 함수는 캡션이 있어도 캡션 정규식이 실패하면 주석에서 파일명을 가져올 수 있음. 이 경우:
- 캡션이 존재(`length > 0`)하지만 캡션 정규식 실패 → `extractFilename` 은 주석에서 파일명 추출
- `extractCode` 에서는 `caption.length > 0` 이므로 첫 줄 제거 안 함
- 결과: 코드에 `// filename.ext` 주석이 그대로 포함됨

**수정:**
```js
const filenameFromComment = (() => {
  const firstLine = block.code.rich_text.map(t => t.plain_text).join('').split('\n')[0]?.trim();
  return firstLine?.match(/^\/\/\s*(\S+\.\w+)\s*$/)?.[1] ?? null;
})();
if (filenameFromComment && filename === filenameFromComment) {
  text = text.replace(/^\/\/\s*\S+\.\w+\s*\n/, '');
}
```

---

### [MEDIUM-02] `extractCode`: `files` 배열에 언어 표준화가 없음

**위치:** line 70

```js
files.push({ filename, lang, code: text });
```

**문제:**
- `lang` 은 Notion API 에서 오는 원본값(`javascript`, `jsx`, `tsx` 등)이며 소문자 정규화는 되어 있음.
- 그러나 Notion 이 반환하는 언어 목록에 `"typescript"` 가 포함될 수 있는데 이 경우 `buildDeployHTML` 의 `namedJsxFiles` 필터에서 `f.lang === 'tsx'` 조건에 걸리지 않아 JSX 파일로 인식되지 않을 수 있음.

**수정 제안:**
```js
// lang 정규화 맵 추가
const langMap = { 'typescript': 'tsx', 'plain text': 'plaintext' };
const normalizedLang = langMap[lang] || lang;
files.push({ filename, lang: normalizedLang, code: text });
```

---

## 2. 토큰 관리 (`getToken`, `getGitHubToken`)

---

### [LOW-01] `getToken`: 토큰 만료 시간 검증 없음

**위치:** line 92-95

```js
async function getToken() {
  const { notionToken } = await chrome.storage.local.get('notionToken');
  return notionToken || null;
}
```

**문제:**
- `tokenSetAt` 은 `onMessageExternal` 의 `SET_TOKEN` 핸들러에서 저장되고 있으나 `getToken()` 에서는 전혀 확인하지 않음.
- `tokenSetAt` 필드가 저장된다는 것은 만료 시간 체크 기능을 의도한 것으로 보이나 구현이 누락됨.

**수정 제안:**
```js
async function getToken() {
  const { notionToken, tokenSetAt } = await chrome.storage.local.get(['notionToken', 'tokenSetAt']);
  // Notion internal integration token은 만료가 없으나, 일정 기간 후 재확인 유도 가능
  // 예: 90일 이상 지났으면 경고 (필요시 활성화)
  return notionToken || null;
}
```

---

### [LOW-02] `githubOAuth`: state 파라미터 검증 없음

**위치:** line 231-232, 248

```js
const state = Date.now().toString(36) + Math.random().toString(36).slice(2);
const authUrl = `...&state=${state}`;
// ...
const code = new URL(responseUrl).searchParams.get('code');
```

**문제:**
- `state` 를 생성하지만 콜백 URL 에서 `state` 를 검증하지 않음.
- CSRF 방어 목적의 `state` 파라미터가 유효성 확인 없이 무시됨.

**수정:**
```js
const returnedState = new URL(responseUrl).searchParams.get('state');
if (returnedState !== state) {
  reject(new Error('OAuth state mismatch'));
  return;
}
const code = new URL(responseUrl).searchParams.get('code');
```

---

### [MEDIUM-03] `githubOAuth`: `clearAllCachedAuthTokens` 는 GitHub OAuth 와 무관

**위치:** line 228

```js
try { await chrome.identity.clearAllCachedAuthTokens(); } catch {}
```

**문제:**
- `chrome.identity.clearAllCachedAuthTokens()` 는 Chrome의 `chrome.identity.getAuthToken()` (Google OAuth) 캐시를 지우는 API임.
- GitHub OAuth 는 `launchWebAuthFlow` 를 사용하므로 이 호출은 아무런 효과가 없음.
- 주석에는 "기존 캐시 제거 후 새 OAuth 시작"이라고 적혀 있어 의도와 실제 동작이 불일치.

**수정:** 이 라인을 제거하거나, 실제로 필요한 정리 작업으로 교체:
```js
// 기존 GitHub 토큰 제거 (재인증 강제)
await chrome.storage.local.remove('githubToken');
```

---

## 3. 캐시 관리 (`cache`, `PAGE_CHANGED`, `CLEAR_CACHE`)

---

### [HIGH-03] `PAGE_CHANGED`: 메시지를 자기 자신에게 재방송 시 무한 루프 위험

**위치:** line 140

```js
chrome.runtime.sendMessage({ type: 'PAGE_CHANGED', pageId: message.pageId }).catch(() => {});
```

**문제:**
- `chrome.runtime.onMessage` 리스너가 `PAGE_CHANGED` 를 받으면, 동일한 리스너가 다시 `PAGE_CHANGED` 를 발송함.
- Service Worker 자신도 `chrome.runtime.onMessage` 의 수신자이므로 이론적으로 재귀 루프가 발생할 수 있음.
- 실제로 Chrome extension 의 `sendMessage` 는 탭 컨텍스트가 없으면 서비스 워커 자신에게는 도달하지 않지만, 다른 Extension 페이지(사이드패널, 팝업 등)에는 전달됨. 이 경우 사이드패널이 또 `PAGE_CHANGED` 메시지를 보내는 구조라면 루프가 발생함.
- 발신 탭 ID를 기록해 필터링하는 구조가 권장됨.

**수정 제안:**
```js
// 원본 sender 탭 ID 포함하여 재방송, 수신측에서 origin 확인
chrome.runtime.sendMessage({
  type: 'PAGE_CHANGED',
  pageId: message.pageId,
  fromContentScript: true  // 재처리 방지 플래그
}).catch(() => {});
// 리스너 상단에 플래그 체크 추가
if (message.fromContentScript) return; // 재방송된 메시지 무시
```

---

### [LOW-03] `CLEAR_CACHE`: `sendResponse` 미호출

**위치:** line 143-147

```js
case 'CLEAR_CACHE':
  cache.pageId = null;
  cache.code = null;
  cache.files = null;
  break;
```

**문제:**
- `sendResponse` 를 호출하지 않으면 발신자의 응답 콜백이 영원히 pending 상태가 됨.
- 발신자가 응답을 기다리는 경우 리소스 누수 발생.

**수정:**
```js
case 'CLEAR_CACHE':
  cache.pageId = null;
  cache.code = null;
  cache.files = null;
  sendResponse({ success: true });
  break;
```

---

### [LOW-04] `PAGE_CHANGED`: `sendResponse` 미호출

**위치:** line 134-141

```js
case 'PAGE_CHANGED':
  // ...
  break;
```

**문제:** `CLEAR_CACHE` 와 동일하게 `sendResponse` 가 없음. 발신자(content script)가 응답을 기다리지 않는다면 무해하지만, 방어적으로 추가하는 것이 좋음.

**수정:**
```js
sendResponse({ success: true });
break;
```

---

## 4. 유틸리티 함수 정규식 정확성

---

### [HIGH-04] `rewriteBareImportsSW`: 두 번째 패턴과 세 번째 패턴이 중복 처리됨

**위치:** line 501-516

```js
// 패턴 1: from '...' 형태
code = code.replace(/(from\s+['"])((?![./])[^'"]+)(['"])/g, ...);
// 패턴 2: import '...' (사이드이펙트 임포트, 줄 시작)
code = code.replace(/^(\s*import\s+['"])((?![./])[^'"]+)(['"])/gm, ...);
// 패턴 3: import('...') 동적 임포트
code = code.replace(/(import\s*\(\s*['"])((?![./])[^'"]+)(['"]\s*\))/g, ...);
```

**문제:**
- 패턴 2는 `^` 와 `m` 플래그로 줄 시작을 강제하지만, `\s*` 가 `^` 바로 뒤에 있어 들여쓰기된 사이드이펙트 임포트는 처리됨.
- 그러나 이미 패턴 1이 적용된 코드에 패턴 2 가 다시 적용되므로 `from 'https://esm.sh/...'` 가 있는 줄을 패턴 2가 재검사함. `(?![./])` 네거티브 룩어헤드가 `h` 를 보므로 재매칭은 안 되지만, `https://esm.sh/...` 는 이미 패턴 1에서 처리됐으므로 패턴 2는 논리적으로 중복 가능성이 있음.
- 더 큰 문제: `import 'sideeffect-pkg'` 형태에서 패턴 1이 `from` 이 없는 사이드이펙트 임포트를 처리하지 못하고 패턴 2가 담당하는데, 패턴 2의 캡처그룹 prefix 가 `(\s*import\s+['"])` 이므로 `'` 기준으로 분리 시 패키지명 앞에 `esm.sh/` 가 붙지 않고 `pre + 'https://esm.sh/' + specifier + post` 로 올바르게 처리됨 — 이 부분은 정상.
- **실제 버그:** 패턴 2는 `m` 플래그를 사용하지만 `g` 플래그가 없음. 줄이 여러 개인 경우 첫 번째 매칭만 교체됨.

**수정:**
```js
code = code.replace(/^(\s*import\s+['"])((?![./])[^'"]+)(['"])/gm, ...);
//                                                                 ^^
//                                                       g 플래그 추가 (현재 없음)
```

**실제 코드 재확인 결과:** line 508 에 `/gm` 이 있음 — 이 경우 정상. 그러나 패턴 1(`/g`)이 이미 `from` 없는 임포트를 처리하지 못하므로 패턴 2는 필수적임. 두 패턴이 상호보완적으로 정상 동작함. 단, 순서가 중요함 (패턴 1 → 패턴 2 순서가 깨지면 이중 rewrite 발생 가능).

---

### [HIGH-05] `convertAwaitImportsSW`: `\(\)` 와 `\[\]` 없이 중괄호 내 바인딩 처리 — 복잡한 구조 파싱 실패

**위치:** line 537-551

```js
/^\s*(?:const|let|var)\s+(\{[^}]+\})\s*=\s*await\s+import\(['"]([^'"]+)['"]\)\s*;?\s*$/gm
```

**문제:**
- `const { foo, bar: baz } = await import('pkg')` → 정상 처리.
- `const { foo, bar: { nested } } = await import('pkg')` → `[^}]+` 이 첫 `}` 에서 멈추므로 실패.
- 중첩 구조 분해는 실제 사용 빈도가 낮으나, 실패 시 변환 없이 그대로 남아 런타임 에러 유발.

**수정 제안:** 중첩 구조 분해는 지원하지 않음을 주석으로 명시:
```js
// 단순 구조 분해만 지원. 중첩 구조 분해({ a: { b } })는 변환하지 않음.
```
또는 전처리 로직 강화.

---

### [MEDIUM-04] `hasBareImportsSW`: 동적 `import()` 패턴이 `await` 없이 사용되는 경우 미탐지

**위치:** line 519-521

```js
function hasBareImportsSW(code) {
  if (!code) return false;
  if (/import\s+(?:.*?\s+from\s+)?['"](?![./])[^'"]+['"]/.test(code)) return true;
  if (/await\s+import\s*\(\s*['"](?![./])[^'"]+['"]\s*\)/.test(code)) return true;
  return false;
}
```

**문제:**
- `import('pkg')` (await 없는 동적 임포트) 는 탐지하지 못함.
- `then(module => ...)` 패턴의 동적 임포트가 `hasBareImportsSW` 에서 `false` 를 반환하면 `rewriteBareImportsSW` 가 여전히 변환을 수행하지만, `buildDeployHTML` 에서 `hasImports` 플래그 분기에 영향을 줌.

**수정:**
```js
if (/(?:await\s+)?import\s*\(\s*['"](?![./])[^'"]+['"]\s*\)/.test(code)) return true;
```

---

### [LOW-05] `stripRelativeImportsSW`: `export ... from './...'` 형태 미처리

**위치:** line 523-527

```js
function stripRelativeImportsSW(code) {
  return code
    .replace(/^\s*import\s+.*?\s+from\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '')
    .replace(/^\s*import\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '');
}
```

**문제:**
- `export { foo } from './bar'` 또는 `export * from './utils'` 형태의 re-export 구문은 제거하지 않음.
- 멀티파일 코드를 하나로 병합할 때 이런 구문이 남아 있으면 런타임 에러 발생.

**수정:**
```js
function stripRelativeImportsSW(code) {
  return code
    .replace(/^\s*import\s+.*?\s+from\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '')
    .replace(/^\s*import\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '')
    .replace(/^\s*export\s+(?:\*|\{[^}]*\})\s+from\s+['"]\.\.?\/[^'"]+['"]\s*;?\s*$/gm, '');
}
```

---

### [MEDIUM-05] `ensureReactImportSW`: `ReactDOM` 임포트를 항상 추가하지만 불필요할 수 있음

**위치:** line 554-558

```js
function ensureReactImportSW(code) {
  if (!code) return code;
  if (/import\s+React[\s,{]/.test(code) || /import\s+\*\s+as\s+React/.test(code)) return code;
  return "import React from 'react';\nimport ReactDOM from 'react-dom/client';\n" + code;
}
```

**문제:**
- 이미 코드에 `import ReactDOM from 'react-dom/client'` 가 있어도 `import React` 가 없으면 둘 다 중복 추가됨.
- `ReactDOM` 이 코드에서 전혀 사용되지 않는 경우(예: 함수형 컴포넌트만 정의하고 렌더링은 외부에서 하는 패턴)에도 불필요하게 추가됨.

**수정:**
```js
function ensureReactImportSW(code) {
  if (!code) return code;
  let prefix = '';
  if (!/import\s+React[\s,{]/.test(code) && !/import\s+\*\s+as\s+React/.test(code)) {
    prefix += "import React from 'react';\n";
  }
  if (!/import\s+ReactDOM[\s,{]/.test(code) && !/import\s+\*\s+as\s+ReactDOM/.test(code)) {
    prefix += "import ReactDOM from 'react-dom/client';\n";
  }
  return prefix + code;
}
```

---

### [LOW-06] `isEntryFileSW`: `ReactDOM.render` 는 React 17 레거시 API

**위치:** line 531-533

```js
function isEntryFileSW(code) {
  return /(?:createRoot|ReactDOM\.render)/.test(code);
}
```

**문제:**
- `ReactDOM.render` 는 React 18에서 deprecated 됨. 현재 코드베이스가 React 18 (`react@18/umd`) 을 사용하므로, `ReactDOM.render` 를 엔트리 파일 탐지에 포함하면 레거시 코드를 잘못 처리할 수 있음.
- 큰 버그는 아니지만, 유지보수 측면에서 주석 추가 권장.

---

## 5. `buildDeployHTML` — 전체 흐름 및 `preview.js` 와의 일관성

---

### [CRITICAL-01] `buildDeployHTML`: OG 이미지 경로가 `og-image.png` 로 하드코딩되어 있으나 실제 파일이 생성 안 될 수 있음

**위치:** line 619-626

```js
if (ogBaseUrl) {
  var ogImageUrl = ogBaseUrl + 'og-image.png';
  head += '<meta property="og:image" content="' + ogImageUrl + '"/>\n';
  // ...
}
```

**문제:**
- `buildDeployHTML` 는 `githubDeploy` 내부에서 `og-image.png` blob 생성 전에 호출됨 (step 5 vs step 8-1).
- OG 이미지 생성(`step 8-1`)이 실패하면 `og-image.png` 가 배포되지 않지만, HTML 의 `<meta og:image>` 는 존재하는 URL을 참조함 → 404 OG 이미지.
- 이것은 배포 순서 상 필연적 문제이며, OG 이미지 생성 성공 여부에 따라 HTML 을 동적으로 생성하거나 두 단계로 분리해야 함.

**수정 방안 1 (권장):** OG 이미지 생성을 `buildDeployHTML` 호출 전에 수행:
```js
// step 5 전에 OG 이미지 base64를 먼저 생성
const ogBase64 = await generateOgImage(screenshotDataUrl);
const htmlContent = buildDeployHTML(code, pagesUrl, files, ogBase64 ? true : false);
// step 8-1에서는 이미 생성된 ogBase64 사용
```

**수정 방안 2:** OG 이미지 실패 시 HTML 에서 OG 태그도 제거.

---

### [CRITICAL-02] `buildDeployHTML`: HTML 인젝션 취약점 — `css`, `html`, `js` 내용이 이스케이프 없이 삽입됨

**위치:** line 630, 644, 666, 668

```js
if (css) head += '<style>\n' + css + '\n</style>\n';
// ...
if (mergedJs) bodyEnd += '<script>\n' + mergedJs + '\n<\/script>\n';
```

**문제:**
- Notion 코드 블록의 내용(`css`, `js`, `html`)이 직접 `<style>`, `<script>`, `<body>` 에 삽입됨.
- CSS에 `</style>` 이 포함되면 스타일 블록이 조기 종료됨.
- JS에 `</script>` 이 포함되면 스크립트 블록이 조기 종료됨.

**현재 완화 수단:**
- JS의 경우 `JSON.stringify(mergedJsx)` (line 648, 657) 로 인코딩하여 Babel 에 전달하므로 일부 경로는 안전함.
- 그러나 `mergedJs` (일반 JS, line 644, 666)는 직접 삽입됨.

**수정:**
```js
// </script> 를 방어적으로 이스케이프
const safeScript = (code) => code.replace(/<\/script>/gi, '<\\/script>');
if (mergedJs) bodyEnd += '<script>\n' + safeScript(mergedJs) + '\n<\/script>\n';
// CSS도 동일하게
const safeCss = (code) => code.replace(/<\/style>/gi, '<\\/style>');
if (css) head += '<style>\n' + safeCss(css) + '\n</style>\n';
```

---

### [CRITICAL-03] `buildDeployHTML`: XSS — `ogBaseUrl` 이 `<meta>` 에 이스케이프 없이 삽입됨

**위치:** line 619-626

```js
var ogImageUrl = ogBaseUrl + 'og-image.png';
head += '<meta property="og:image" content="' + ogImageUrl + '"/>\n';
```

**문제:**
- `ogBaseUrl` 은 `githubDeploy` 에서 `https://${owner}.github.io/${repoName}/` 으로 구성되는데, `owner` 와 `repoName` 은 GitHub API 응답에서 옴.
- 악의적인 GitHub 사용자명(`"><script>alert(1)</script>`)이 있으면 HTML 속성이 깨짐.
- GitHub 는 사용자명에 특수문자를 허용하지 않으므로 실제 위험도는 낮지만, 방어적 이스케이프 필요.

**수정:**
```js
function escapeHtmlAttr(str) {
  return String(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
head += '<meta property="og:image" content="' + escapeHtmlAttr(ogImageUrl) + '"/>\n';
```

---

### [MEDIUM-06] `buildDeployHTML`: `looksLikeJSXCode` 함수가 지역 변수로 재정의됨 (전역과 불일치)

**위치:** line 579

```js
var looksLikeJSXCode = function (c) { return /(?:ReactDOM|createRoot|React\.|useState|useEffect|useRef|useCallback|useMemo|useContext|useReducer)/.test(c); };
```

**문제:**
- 파일 다른 위치에 동명의 전역 함수가 있어야 정상이나, `looksLikeJSXCode` 는 `buildDeployHTML` 내부에만 지역 함수로 정의됨.
- 이름이 동일하다는 것은 `preview.js` 에서 복사한 코드임을 암시하며, 전역 상태에서는 정의되지 않아 다른 함수에서 호출 시 `ReferenceError` 발생.
- 실제로는 외부에서 호출하지 않으므로 현재 동작은 문제없음. 그러나 유지보수 시 전역으로 추출하면서 내부 정의를 지우지 않으면 중복이 발생함.

**수정:** 전역 함수로 분리:
```js
function looksLikeJSXCode(c) {
  return /(?:ReactDOM|createRoot|React\.|useState|useEffect|useRef|useCallback|useMemo|useContext|useReducer)/.test(c);
}
// buildDeployHTML 내부의 var looksLikeJSXCode = ... 제거
```

---

## 6. `githubDeploy` — 파일 처리, API 호출, 에러 처리

---

### [HIGH-06] `githubDeploy`: `files` 파라미터가 `buildDeployHTML` 에 전달되지만 `deployFiles` blob 배열에는 포함되지 않음

**위치:** line 330, 345-365

```js
const htmlContent = buildDeployHTML(code, pagesUrl, files); // files 사용됨

const deployFiles = [{ path: 'index.html', content: htmlContent }];
if (code.css) deployFiles.push({ path: 'style.css', content: code.css });
if (code.js) deployFiles.push({ path: 'script.js', content: code.js });
if (code.jsx) deployFiles.push({ path: 'App.jsx', content: code.jsx });
if (code.tsx) deployFiles.push({ path: 'App.tsx', content: code.tsx });
// files 배열의 개별 파일은 추가하지 않음
```

**문제:**
- `buildDeployHTML` 는 `files` 내 CSS/HTML 파일을 병합하여 `index.html` 에 인라인함.
- 그러나 `files` 내의 JS/JSX/TSX 파일도 `buildDeployHTML` 에서 병합하여 `index.html` 에 인라인되므로, 개별 파일로는 배포되지 않음.
- 이는 의도적일 수 있으나, 멀티파일 프로젝트를 별개 파일로 배포하려는 사용자 기대에 어긋남.
- 추가로 `style.css`, `script.js` 등이 별도 파일로 업로드되지만 `index.html` 에서 이 파일들을 `<link>` 나 `<script src>` 로 참조하지 않으므로 사실상 데드 파일임.

**수정 방안 A (단순화):** `deployFiles` 에서 `css`, `js`, `jsx`, `tsx` 개별 파일 업로드를 제거 (이미 `index.html` 에 인라인되므로 불필요):
```js
const deployFiles = [{ path: 'index.html', content: htmlContent }];
// css/js/jsx/tsx 개별 파일은 index.html 에 인라인되므로 별도 배포 불필요
```

**수정 방안 B (완전 멀티파일):** `index.html` 에서 외부 파일을 참조하도록 `buildDeployHTML` 수정.

---

### [HIGH-07] `githubDeploy`: `repoCheckRes` 가 `404` 도 아니고 `ok` 도 아닌 경우 (`401`, `403`, `500` 등) 처리 후 코드가 계속 실행됨

**위치:** line 306-326

```js
const repoCheckRes = await githubFetch(`/repos/${owner}/${repoName}`, token);
if (repoCheckRes.status === 404) {
  // 레포 생성 후 2초 대기
} else if (!repoCheckRes.ok) {
  throw new Error('Failed to check repo: ' + repoCheckRes.status);
}
// 여기서 실행 계속 = 레포 존재
```

**문제:**
- 이 부분은 정상 처리됨. 다만 `githubFetch` 가 `401` 에서 `throw` 를 하므로, `401` 은 `else if` 에 도달하지 않음.
- `githubFetch` 는 `401` 에서만 `throw` 하고 나머지 에러 상태는 `res` 를 그대로 반환함. 따라서 `500` 이 오면 `else if (!repoCheckRes.ok)` 에서 정상적으로 에러를 던짐 — 정상 동작.
- **실제 문제 없음.** 단, `githubFetch` 의 비일관적 에러 처리(401만 throw, 나머지는 caller 책임)가 혼란의 원인.

**권고:** `githubFetch` 의 에러 처리 방식을 문서화하거나, 일관되게 throw:
```js
async function githubFetch(path, token, options = {}) {
  // ...
  // 주석: 401은 자동 처리 후 throw, 나머지 에러는 caller가 res.ok로 확인
}
```

---

## 7. `githubOAuth` — 캐시 제거, state 파라미터 (앞 섹션에서 커버됨)

[MEDIUM-03], [LOW-02] 참조.

---

## 8. `onMessageExternal` — origin 체크 보안

---

### [MEDIUM-07] `onMessageExternal`: `sender.url` 이 아닌 `sender.origin` 을 사용해야 더 안전

**위치:** line 103

```js
const origin = sender.url ?? '';
// ...
const senderOrigin = new URL(origin).origin;
```

**문제:**
- Chrome Extensions 메시지 API 에서 `sender.url` 은 전체 URL(경로 포함)을 반환함.
- `sender.origin` 은 Chrome 80+ 에서 지원하며 origin 만 반환해 파싱 오버헤드 없이 직접 비교 가능.
- `sender.url` 을 `new URL()` 로 파싱하는 현재 방식은 URL 파싱 실패(malformed URL) 시 예외를 throw 하여 `catch` 블록에서 `unauthorized` 를 반환함 — 이는 의도적이고 안전함.
- 그러나 `sender.url` 이 없고 `sender.origin` 만 있는 경우(`?? ''` 로 인해 빈 문자열이 `new URL('')` 파싱 시 예외)를 놓칠 수 있음.

**수정:**
```js
const senderOrigin = sender.origin ?? (sender.url ? new URL(sender.url).origin : '');
if (!allowedOrigins.includes(senderOrigin)) {
  sendResponse({ error: 'unauthorized' });
  return;
}
```

---

## 9. 사이드패널 관리 (`isNotionUrl`, `updateSidePanelForTab`)

---

### [MEDIUM-08] `isNotionUrl`: 서브도메인 `*.notion.so` 를 허용하지 않음

**위치:** line 688-696

```js
function isNotionUrl(url) {
  if (!url) return false;
  try {
    const hostname = new URL(url).hostname;
    return hostname === 'www.notion.so' || hostname === 'notion.so' || hostname.endsWith('notion.site');
  } catch {
    return false;
  }
}
```

**문제:**
- Notion 은 팀/워크스페이스별 서브도메인을 제공하지 않지만, 미래에 기능이 추가될 수 있음.
- 현재 `hostname.endsWith('.notion.site')` 처리는 있으나 `hostname.endsWith('.notion.so')` 는 없음.
- `notion.site` 는 공유 페이지 도메인이므로 `endsWith('notion.site')` 가 맞음. 그러나 `teamname.notion.site` 형태도 있으므로 `endsWith('.notion.site')` (점 포함)으로 검사해야 더 정확.

**현재 코드:** `hostname.endsWith('notion.site')` — `somemaliciousnotion.site` 도 true 반환.

**수정:**
```js
return hostname === 'www.notion.so'
  || hostname === 'notion.so'
  || hostname.endsWith('.notion.so')
  || hostname === 'notion.site'
  || hostname.endsWith('.notion.site');
```

---

## 10. `onInstalled` 핸들러

---

### [LOW-07] `onInstalled`: 업데이트 시에도 무조건 설정 페이지 열림

**위치:** line 676-681

```js
chrome.runtime.onInstalled.addListener(async (details) => {
  const { notionToken } = await chrome.storage.local.get('notionToken');
  if (!notionToken) {
    chrome.tabs.create({ url: 'https://misiso.com/gifts/code-previewer/setup' });
  }
});
```

**문제:**
- `details.reason` 이 `'update'` 인 경우(Extension 업데이트)에도 토큰이 없으면 설정 페이지가 열림.
- 사용자가 토큰을 아직 설정하지 않은 상태에서 Extension 을 업데이트하면 불필요한 탭이 열려 UX 를 방해함.
- `details.reason === 'install'` 일 때만 열도록 제한하는 것이 일반적인 관행.

**수정:**
```js
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason !== 'install') return;
  const { notionToken } = await chrome.storage.local.get('notionToken');
  if (!notionToken) {
    chrome.tabs.create({ url: 'https://misiso.com/gifts/code-previewer/setup' });
  }
});
```

---

## 11. 변수 충돌, 미정의 참조, 데드 코드

---

### [HIGH-08] `GITHUB_AUTH` 핸들러: 반환된 토큰이 사용되지 않음 (데드 코드)

**위치:** line 158-161

```js
case 'GITHUB_AUTH':
  githubOAuth()
    .then(token => sendResponse({ success: true }))
    .catch(err => sendResponse({ error: err.message }));
  return true;
```

**문제:**
- `token` 파라미터가 선언되지만 전혀 사용되지 않음.
- ESLint `no-unused-vars` 경고 발생.

**수정:**
```js
.then(() => sendResponse({ success: true }))
```

---

### [MEDIUM-09] `GET_STATUS` 핸들러: `chrome.storage.local.get` 콜백과 `async/await` 혼용

**위치:** line 168-182

```js
case 'GET_STATUS':
  chrome.storage.local.get(['notionToken'], async (data) => {
    // ...
    sendResponse({ hasToken: !!data.notionToken, currentPageId: pageId });
  });
  return true;
```

**문제:**
- `chrome.storage.local.get` 은 Promise 를 반환하는 최신 API가 있음에도 콜백 형태를 사용하면서 내부에 `async` 함수를 사용함.
- `await chrome.tabs.query(...)` 예외가 발생하면 `sendResponse` 가 호출되지 않을 수 있음. 현재 `try {} catch {}` 로 감싸고 있으나 catch 블록이 비어있어 `pageId` 가 null 인 채로 `sendResponse` 가 호출됨 — 이는 의도적으로 보이나 에러 로그가 없음.

**수정 제안:**
```js
case 'GET_STATUS':
  (async () => {
    try {
      const data = await chrome.storage.local.get(['notionToken']);
      let pageId = cache.pageId;
      if (!pageId) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.url) {
          const m = tab.url.match(/-([a-f0-9]{32})(?:[?#]|$)/i)
            || tab.url.match(/\/([a-f0-9]{32})(?:[?#]|$)/i);
          if (m) { pageId = m[1].toLowerCase(); cache.pageId = pageId; }
        }
      }
      sendResponse({ hasToken: !!data.notionToken, currentPageId: pageId });
    } catch (err) {
      sendResponse({ hasToken: false, currentPageId: null });
    }
  })();
  return true;
```

---

## 12. 기타 미세 이슈

| ID | 위치 | 설명 | 심각도 |
|----|------|------|--------|
| MISC-01 | line 19 | `parseInt(res.headers.get('Retry-After') \|\| '2')` — `Retry-After` 가 날짜 형식으로 오면 `NaN`, `NaN * 1000 = NaN`, `setTimeout(r, NaN)` 은 즉시 실행됨. 숫자 형식만 처리하는 방어 코드 필요. | Low |
| MISC-02 | line 323 | `await new Promise(r => setTimeout(r, 2000))` — 레포 초기화 대기. 2초가 항상 충분하지 않을 수 있음. GitHub API 레이트리밋이나 느린 서버 상황에서 `git/ref/heads/main` 이 아직 없어 step 6 에서 실패 가능. 재시도 로직 필요. | Medium |
| MISC-03 | line 414 | `for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i])` — 대용량 이미지에서 문자열 연결이 느림. `String.fromCharCode(...bytes)` 또는 `TextDecoder` 사용 권장. | Low |
| MISC-04 | line 98 | `const cache = { pageId: null, code: null, files: null }` — Service Worker 는 비활성 시 메모리에서 해제됨. 재활성 시 캐시가 초기화되므로 `CLEAR_CACHE` 없이도 자연 만료됨. 이 동작을 주석으로 명시 필요. | Low |

---

## 우선순위별 수정 권고

### 즉시 수정 (Critical)
1. **[CRITICAL-02]** HTML 인젝션 방어 — `</script>`, `</style>` 이스케이프 추가
2. **[CRITICAL-03]** OG URL XSS 방어 — HTML 속성 이스케이프 추가
3. **[CRITICAL-01]** OG 이미지 생성 순서 재조정 — 생성 성공 여부에 따라 meta 태그 조건부 포함

### 단기 수정 (High)
4. **[HIGH-02]** `extractCode` 첫 줄 주석 제거 조건 명확화
5. **[HIGH-03]** `PAGE_CHANGED` 재방송 루프 방지 플래그 추가
6. **[HIGH-05]** `convertAwaitImportsSW` 중첩 구조 분해 미지원 명시 또는 처리
7. **[HIGH-06]** `deployFiles` 중복 업로드 제거 (인라인된 파일을 별도로 또 업로드하는 문제)
8. **[HIGH-08]** 미사용 `token` 파라미터 제거

### 중기 수정 (Medium)
9. **[MEDIUM-03]** `clearAllCachedAuthTokens` 제거 또는 실제 정리 로직으로 교체
10. **[MEDIUM-04]** `hasBareImportsSW` await 없는 동적 임포트 탐지 추가
11. **[MEDIUM-05]** `ensureReactImportSW` 중복 임포트 방지 개선
12. **[MEDIUM-06]** `looksLikeJSXCode` 전역 함수로 분리
13. **[MEDIUM-07]** `onMessageExternal` origin 체크 개선
14. **[MEDIUM-08]** `isNotionUrl` 서브도메인 정확도 개선
15. **[MEDIUM-09]** `GET_STATUS` async/await 일관성 개선

### 장기/저우선 (Low)
16. **[LOW-01]** `tokenSetAt` 활용 또는 필드 제거
17. **[LOW-02]** OAuth state 파라미터 검증 추가
18. **[LOW-03]**, **[LOW-04]** `sendResponse` 누락 케이스 보완
19. **[LOW-05]** `stripRelativeImportsSW` re-export 구문 처리 추가
20. **[LOW-07]** `onInstalled` 에서 `install` 이유 필터링
21. **[MISC-01~04]** 기타 방어 코드 추가

---

*이 보고서는 정적 분석을 기반으로 작성되었습니다. 런타임 환경에 따라 일부 이슈의 실제 영향도가 달라질 수 있습니다.*
