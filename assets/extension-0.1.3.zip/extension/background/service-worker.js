importScripts('../utils/constants.js', '../utils/escape.js', '../utils/code-transform.js', '../utils/html-builder.js');

const utils = self.CodePreviewerUtils || {};
const sharedCdnUrls = utils.CDN_URLS || {};

// === Notion API ===
const NOTION_API = 'https://api.notion.com/v1';
const NOTION_VERSION = '2022-06-28';

async function notionFetch(path, token, retryCount = 0) {
  const MAX_RETRIES = 3;
  const res = await fetch(`${NOTION_API}${path}`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Notion-Version': NOTION_VERSION,
    },
  });

  if (res.status === 401) throw new Error('TOKEN_EXPIRED');
  if (res.status === 403) throw new Error('NO_ACCESS');
  if (res.status === 404) throw new Error('PAGE_NOT_FOUND');
  if (res.status === 429) {
    if (retryCount >= MAX_RETRIES) throw new Error('RATE_LIMITED');
    const wait = parseInt(res.headers.get('Retry-After') || '2') || 2;
    await new Promise(r => setTimeout(r, wait * 1000));
    return notionFetch(path, token, retryCount + 1);
  }
  if (!res.ok) throw new Error(`API_ERROR_${res.status}`);
  return res.json();
}

async function fetchAllBlocks(pageId, token) {
  const blocks = [];

  async function fetchChildren(blockId) {
    let cursor = undefined;
    do {
      const params = new URLSearchParams({ page_size: '100' });
      if (cursor) params.set('start_cursor', cursor);
      const data = await notionFetch(`/blocks/${blockId}/children?${params}`, token);
      for (const block of data.results) {
        blocks.push(block);
        if (block.has_children) {
          await fetchChildren(block.id);
        }
      }
      cursor = data.has_more ? data.next_cursor : undefined;
    } while (cursor);
  }

  await fetchChildren(pageId);
  return blocks;
}

function extractFilename(block) {
  // 1. 캡션에서 파일명 추출 (공백 없는 파일명만)
  const caption = (block.code.caption || []).map(t => t.plain_text).join('').trim();
  if (caption && /^[^\s]+\.\w+$/.test(caption)) return { name: caption, source: 'caption' };
  // 2. 첫 줄 주석에서 파일명 추출: // filename.ext
  const text = block.code.rich_text.map(t => t.plain_text).join('');
  const firstLine = text.split('\n')[0]?.trim();
  const commentMatch = firstLine?.match(/^\/\/\s*(\S+\.\w+)\s*$/);
  if (commentMatch) return { name: commentMatch[1], source: 'comment' };
  return null;
}

function extractCode(blocks) {
  const code = { html: [], css: [], javascript: [], jsx: [], tsx: [] };
  const files = [];
  const debugInfo = { totalBlocks: blocks.length, codeBlocks: 0, languages: {} };
  for (const block of blocks) {
    if (block.type !== 'code') continue;
    debugInfo.codeBlocks++;
    const lang = block.code.language?.toLowerCase();
    let text = block.code.rich_text.map(t => t.plain_text).join('');
    debugInfo.languages[lang] = (debugInfo.languages[lang] || 0) + 1;

    const filenameResult = extractFilename(block);
    const filename = filenameResult ? filenameResult.name : null;
    // 첫 줄 주석 파일명이면 코드에서 제거
    if (filenameResult && filenameResult.source === 'comment') {
      text = text.replace(/^\/\/\s*\S+\.\w+\s*\n/, '');
    }

    if (filename) {
      files.push({ filename, lang: lang, code: text });
    }
    // TypeScript blocks go into tsx so they always get Babel treatment
    var targetLang = (lang === 'typescript') ? 'tsx' : lang;
    if (targetLang in code) {
      if (!filename) {
        code[targetLang].push(text);
      }
    }
  }
  return {
    code: {
      html: code.html.join('\n'),
      css: code.css.join('\n'),
      js: code.javascript.join('\n'),
      jsx: code.jsx.join('\n'),
      tsx: code.tsx.join('\n'),
    },
    files: files,
    debugInfo: debugInfo,
  };
}

// === 토큰 ===
async function getToken() {
  const { notionToken } = await chrome.storage.local.get('notionToken');
  return notionToken || null;
}

// === 캐시 ===
const cache = { pageId: null, code: null, files: null };

// === Notion API 응답 캐시 (프리뷰 세션 → 정적 배포용) ===
// 프리뷰 iframe이 /api/notion/... 를 호출할 때마다 응답을 기록.
// 배포 시 이 캐시를 정적 fetch 인터셉터로 변환 → 토큰 없이 동작하는 정적 사이트 생성.
// storage.local에도 저장 — MV3 서비스워커 재시작 시 인메모리 변수가 초기화되는 문제 방지.
const notionProxyCache = {};
let notionProxyCachePageId = null;

async function cacheNotionProxyResponse(pageId, method, path, body, data) {
  if (notionProxyCachePageId !== pageId) {
    Object.keys(notionProxyCache).forEach(k => delete notionProxyCache[k]);
    notionProxyCachePageId = pageId;
  }
  const key = `${method || 'GET'}:${path}:${body ? JSON.stringify(body) : ''}`;
  notionProxyCache[key] = data;
  chrome.storage.local.set({ notionProxyCacheData: notionProxyCache, notionProxyCachePageId: pageId });
}

async function restoreNotionProxyCache() {
  if (notionProxyCachePageId && Object.keys(notionProxyCache).length > 0) return;
  const stored = await chrome.storage.local.get(['notionProxyCacheData', 'notionProxyCachePageId']);
  if (stored.notionProxyCachePageId && stored.notionProxyCacheData) {
    notionProxyCachePageId = stored.notionProxyCachePageId;
    Object.assign(notionProxyCache, stored.notionProxyCacheData);
  }
}

// === 외부 메시지 (misiso.com → Extension) ===
chrome.runtime.onMessageExternal.addListener(
  (message, sender, sendResponse) => {
    const origin = sender.url ?? '';
    const allowedOrigins = ['https://misiso.com'];
    try {
      const senderOrigin = new URL(origin).origin;
      if (!allowedOrigins.includes(senderOrigin)) {
        sendResponse({ error: 'unauthorized' });
        return;
      }
    } catch {
      sendResponse({ error: 'unauthorized' });
      return;
    }
    switch (message.type) {
      case 'PING':
        sendResponse({ pong: true });
        break;
      case 'SET_TOKEN':
        chrome.storage.local.set({
          notionToken: message.token,
          tokenSetAt: Date.now(),
        }, () => sendResponse({ success: true }));
        return true;
      default:
        sendResponse({ error: 'unknown_type' });
    }
  }
);

// === 내부 메시지 ===
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'PAGE_CHANGED':
      // Guard: only process if from content-script (has sender.tab), not re-broadcast
      if (!sender.tab) break;
      if (cache.pageId !== message.pageId) {
        cache.code = null;
        cache.files = null;
      }
      cache.pageId = message.pageId;
      chrome.runtime.sendMessage({ type: 'PAGE_CHANGED', pageId: message.pageId, tabId: sender.tab.id }).catch(() => {});
      break;

    case 'CLEAR_CACHE':
      cache.pageId = null;
      cache.code = null;
      cache.files = null;
      break;

    case 'NOTION_API_PROXY':
      handleNotionProxy(message.request).then(sendResponse);
      return true;

    case 'FETCH_CODE':
      handleFetchCode(message.pageId).then(sendResponse);
      return true;

    case 'GITHUB_CHECK_TOKEN':
      getGitHubToken().then(token => sendResponse({ hasToken: !!token }));
      return true;

    case 'GITHUB_AUTH':
      githubOAuth()
        .then(() => sendResponse({ success: true }))
        .catch(err => sendResponse({ error: err.message }));
      return true;

    case 'GITHUB_DEPLOY':
      handleGitHubDeploy(message.code, message.pageId, message.screenshotDataUrl, message.files).then(sendResponse);
      return true;

    case 'GET_STATUS':
      chrome.storage.local.get(['notionToken'], async (data) => {
        let pageId = cache.pageId;
        if (!pageId) {
          try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab?.url) {
              const m = tab.url.match(/-([a-f0-9]{32})(?:[?#]|$)/i)
                || tab.url.match(/\/([a-f0-9]{32})(?:[?#]|$)/i);
              if (m) { pageId = m[1].toLowerCase(); cache.pageId = pageId; }
            }
          } catch {}
        }
        sendResponse({ hasToken: !!data.notionToken, currentPageId: pageId });
      });
      return true;
  }
});

// === 코드 추출 (캐시: pageId 기반만) ===
async function handleFetchCode(pageId) {
  const token = await getToken();
  if (!token) return { error: 'NO_TOKEN' };
  if (!pageId) return { error: 'NO_PAGE' };

  // 같은 페이지 + 캐시 있으면 캐시 반환
  if (cache.pageId === pageId && cache.code) {
    return { code: cache.code, files: cache.files || [], cached: true };
  }

  try {
    const blocks = await fetchAllBlocks(pageId, token);
    const result = extractCode(blocks);

    const isEmpty = !result.code.html && !result.code.css && !result.code.js && !result.code.jsx && !result.code.tsx && result.files.length === 0;
    if (isEmpty) return { error: 'NO_CODE_BLOCKS', debugInfo: result.debugInfo };

    cache.pageId = pageId;
    cache.code = result.code;
    cache.files = result.files;
    return { code: result.code, files: result.files, cached: false, debugInfo: result.debugInfo };
  } catch (err) {
    if (err.message === 'TOKEN_EXPIRED') {
      await chrome.storage.local.remove('notionToken');
    }
    return { error: err.message };
  }
}

// === Notion API 프록시 (프리뷰 iframe fetch 인터셉터용) ===
async function handleNotionProxy({ method, path, body }) {
  const token = await getToken();
  if (!token) return { error: 'NO_TOKEN', status: 401 };

  const url = `https://api.notion.com/v1${path}`;
  try {
    const res = await fetch(url, {
      method: method || 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    let data;
    try {
      data = await res.json();
    } catch {
      return { error: `API_ERROR_${res.status}`, status: res.status };
    }
    if (res.ok && data) {
      cacheNotionProxyResponse(cache.pageId, method || 'GET', path, body, data);
    }
    return { data, status: res.status };
  } catch (err) {
    return { error: err.message, status: 500 };
  }
}

// === GitHub Deploy ===
const GITHUB_CLIENT_ID = 'Ov23liAaBbpx4cUnuCKT';
const GITHUB_TOKEN_PROXY = 'https://misiso.com/api/github/token';
const NOTION_DEPLOY_REGISTER = 'https://misiso.com/api/notion/deploy-register';
const GITHUB_API = 'https://api.github.com';

async function getGitHubToken() {
  const { githubToken } = await chrome.storage.local.get('githubToken');
  return githubToken || null;
}

async function githubOAuth() {
  // Note: chrome.identity.clearAllCachedAuthTokens() is for Google OAuth tokens only,
  // not applicable to GitHub OAuth. The state parameter below handles cache busting.
  const redirectUrl = chrome.identity.getRedirectURL();
  // state parameter is used for cache busting only, not CSRF protection.
  // CSRF is mitigated by chrome.identity.launchWebAuthFlow which restricts the redirect URL.
  const state = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const authUrl = `https://github.com/login/oauth/authorize?client_id=${GITHUB_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUrl)}&scope=public_repo&state=${state}`;

  return new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, async (responseUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!responseUrl) {
        reject(new Error('OAuth cancelled'));
        return;
      }
      try {
        const code = new URL(responseUrl).searchParams.get('code');
        if (!code) {
          reject(new Error('No code in OAuth response'));
          return;
        }
        // misiso.com 서버를 통해 토큰 교환 (client_secret 서버에만 보관)
        const tokenRes = await fetch(GITHUB_TOKEN_PROXY, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code: code })
        });
        const tokenData = await tokenRes.json();
        if (tokenData.error) {
          reject(new Error(tokenData.error_description || tokenData.error));
          return;
        }
        await chrome.storage.local.set({ githubToken: tokenData.access_token });
        resolve(tokenData.access_token);
      } catch (err) {
        reject(err);
      }
    });
  });
}

async function githubFetch(path, token, options = {}, retryCount = 0) {
  const MAX_RETRIES = 3;
  const url = path.startsWith('https://') ? path : `${GITHUB_API}${path}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/vnd.github+json',
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  if (res.status === 401) {
    await chrome.storage.local.remove('githubToken');
    throw new Error('GITHUB_TOKEN_EXPIRED');
  }
  if (res.status === 403) {
    throw new Error('GITHUB_FORBIDDEN: insufficient permissions or rate limit exceeded');
  }
  if (res.status === 429) {
    if (retryCount >= MAX_RETRIES) throw new Error('GITHUB_RATE_LIMITED');
    const wait = parseInt(res.headers.get('Retry-After') || '60') || 60;
    await new Promise(r => setTimeout(r, wait * 1000));
    return githubFetch(path, token, options, retryCount + 1);
  }
  return res;
}

async function githubDeploy(code, pageId, screenshotDataUrl, files) {
  // 1. Get token (must already exist via GITHUB_AUTH)
  const token = await getGitHubToken();
  if (!token) throw new Error('GITHUB_TOKEN_EXPIRED');

  // 2. Get user info
  const userRes = await githubFetch('/user', token);
  if (!userRes.ok) throw new Error('Failed to get GitHub user info');
  const user = await userRes.json();
  const owner = user.login;

  // 3. Repo name
  const repoName = `notion-preview-${pageId.substring(0, 8)}`;
  let defaultBranch = 'main';

  // 4. Create repo if not exists
  const repoCheckRes = await githubFetch(`/repos/${owner}/${repoName}`, token);
  if (repoCheckRes.status === 404) {
    const createRes = await githubFetch('/user/repos', token, {
      method: 'POST',
      body: JSON.stringify({
        name: repoName,
        description: 'Deployed from Notion Code Previewer',
        homepage: `https://${owner}.github.io/${repoName}/`,
        auto_init: true,
        private: false
      })
    });
    if (!createRes.ok) {
      const err = await createRes.json();
      throw new Error('Failed to create repo: ' + (err.message || createRes.status));
    }
    const createdRepo = await createRes.json();
    defaultBranch = createdRepo.default_branch || defaultBranch;
    // Wait a moment for GitHub to initialize the repo
    await new Promise(r => setTimeout(r, 2000));
  } else if (!repoCheckRes.ok) {
    throw new Error('Failed to check repo: ' + repoCheckRes.status);
  } else {
    const existingRepo = await repoCheckRes.json();
    defaultBranch = existingRepo.default_branch || defaultBranch;
  }

  // 5. 서비스워커 재시작으로 인메모리 캐시가 비었을 경우 storage.local에서 복원
  await restoreNotionProxyCache();

  // 6. Build the HTML file with OG meta tags
  const pagesUrl = `https://${owner}.github.io/${repoName}/`;

  // misiso.com에 배포 등록 → deployKey 발급 (실시간 프록시용)
  // DB 데이터는 HTML에 박지 않음 — 프록시 경유로만 접근
  // 이미지: S3 URL → assets/ 로컬 경로 맵을 bootstrap에 주입, 프록시 응답 패치로 이미지 만료 방지
  let bootstrapScript = null;
  let imageAssetFiles = [];
  let deployKey = null;
  let urlToAsset = {};

  // 이미지 다운로드 — 실패해도 프록시 등록은 계속 진행
  if (notionProxyCachePageId === pageId && Object.keys(notionProxyCache).length > 0) {
    try {
      const result = await downloadNotionImages(Object.assign({}, notionProxyCache));
      urlToAsset = result.urlToAsset;
      imageAssetFiles = result.assetFiles;
    } catch { /* S3 다운로드 실패 — 이미지 없이 계속 */ }
  }

  // 프록시 등록 — 이미지 다운로드와 독립적으로 처리
  let proxyRegisterError = null;
  try {
    const notionToken = await getToken();
    if (!notionToken) throw new Error('PROXY_REG_FAIL: notionToken이 없음');
    const allowedPaths = notionProxyCachePageId === pageId && Object.keys(notionProxyCache).length > 0
      ? [...new Set(Object.keys(notionProxyCache).map(k => k.split(':')[1]))]
      : [];
    const allowedOrigin = `https://${owner}.github.io`;

    const regRes = await fetch(NOTION_DEPLOY_REGISTER, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notionToken, pageId, allowedPaths, allowedOrigin })
    });
    if (regRes.ok) {
      const regData = await regRes.json();
      deployKey = regData.deployKey || null;
      if (!deployKey) proxyRegisterError = 'PROXY_REG_FAIL: deployKey가 응답에 없음';
    } else {
      const errData = await regRes.json().catch(() => ({}));
      proxyRegisterError = `PROXY_REG_FAIL: 서버 ${regRes.status} — ${errData.error || '알 수 없음'}`;
    }
    if (deployKey) bootstrapScript = buildDeployInterceptorScript(deployKey, urlToAsset);
  } catch (e) {
    proxyRegisterError = proxyRegisterError || `PROXY_REG_FAIL: ${e.message}`;
  }

  const htmlContent = buildDeployHTML(code, pagesUrl, files, bootstrapScript);
  const encodedBranch = encodeURIComponent(defaultBranch);

  // 6. Get current ref
  const refRes = await githubFetch(`/repos/${owner}/${repoName}/git/ref/heads/${encodedBranch}`, token);
  if (!refRes.ok) throw new Error('Failed to get ref: ' + refRes.status);
  const refData = await refRes.json();
  const parentSha = refData.object.sha;

  // 7. Get current commit tree
  const commitRes = await githubFetch(`/repos/${owner}/${repoName}/git/commits/${parentSha}`, token);
  if (!commitRes.ok) throw new Error('Failed to get commit');
  const commitData = await commitRes.json();
  const baseTreeSha = commitData.tree.sha;

  // 8. Create blobs for each file (index.html + assets/ 이미지)
  const deployFiles = [
    { path: 'index.html', content: htmlContent, encoding: 'utf-8' },
    ...imageAssetFiles
  ];

  const treeItems = [];
  for (const file of deployFiles) {
    const blobRes = await githubFetch(`/repos/${owner}/${repoName}/git/blobs`, token, {
      method: 'POST',
      body: JSON.stringify({ content: file.content, encoding: file.encoding || 'utf-8' })
    });
    if (!blobRes.ok) throw new Error('Failed to create blob for ' + file.path);
    const blobData = await blobRes.json();
    treeItems.push({
      path: file.path,
      mode: '100644',
      type: 'blob',
      sha: blobData.sha
    });
  }

  // 8-1. OG 이미지 생성 (스크린샷 또는 Canvas 폴백)
  try {
    let ogBase64 = null;
    if (screenshotDataUrl) {
      ogBase64 = screenshotDataUrl.replace(/^data:image\/[^;]+;base64,/, '');
    }
    // 스크린샷 없으면 OffscreenCanvas로 직접 그리기
    if (!ogBase64) {
      const canvas = new OffscreenCanvas(1200, 630);
      const ctx = canvas.getContext('2d');
      // 배경
      ctx.fillStyle = '#0a0a1a';
      ctx.fillRect(0, 0, 1200, 630);
      // 카드
      ctx.fillStyle = '#1a1a2e';
      ctx.strokeStyle = '#2d2d4e';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(40, 40, 1120, 550, 24);
      ctx.fill();
      ctx.stroke();
      // 제목
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 48px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Notion Code Preview', 600, 260);
      // repo 이름
      ctx.fillStyle = '#8888aa';
      ctx.font = '24px sans-serif';
      ctx.fillText(repoName, 600, 320);
      // 버튼
      ctx.fillStyle = '#6c5ce7';
      ctx.beginPath();
      ctx.roundRect(440, 380, 320, 56, 28);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = '600 20px sans-serif';
      ctx.fillText('Live Preview', 600, 415);
      // 푸터
      ctx.fillStyle = '#555577';
      ctx.font = '16px sans-serif';
      ctx.fillText('Built with Notion Code Previewer', 600, 540);
      // PNG로 변환
      const pngBlob = await canvas.convertToBlob({ type: 'image/png' });
      const arrayBuf = await pngBlob.arrayBuffer();
      const bytes = new Uint8Array(arrayBuf);
      let binary = '';
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      ogBase64 = btoa(binary);
    }
    if (ogBase64) {
      const ogBlobRes = await githubFetch(`/repos/${owner}/${repoName}/git/blobs`, token, {
        method: 'POST',
        body: JSON.stringify({ content: ogBase64, encoding: 'base64' })
      });
      if (ogBlobRes.ok) {
        const ogBlobData = await ogBlobRes.json();
        treeItems.push({
          path: 'og-image.png',
          mode: '100644',
          type: 'blob',
          sha: ogBlobData.sha
        });
      }
    }
  } catch (ogErr) {
    // OG 이미지 실패해도 배포 계속
  }

  // 9. Create tree
  const treeRes = await githubFetch(`/repos/${owner}/${repoName}/git/trees`, token, {
    method: 'POST',
    body: JSON.stringify({ base_tree: baseTreeSha, tree: treeItems })
  });
  if (!treeRes.ok) throw new Error('Failed to create tree');
  const treeData = await treeRes.json();

  // 10. Create commit
  const newCommitRes = await githubFetch(`/repos/${owner}/${repoName}/git/commits`, token, {
    method: 'POST',
    body: JSON.stringify({
      message: 'Deploy from Notion Code Previewer',
      tree: treeData.sha,
      parents: [parentSha]
    })
  });
  if (!newCommitRes.ok) throw new Error('Failed to create commit');
  const newCommitData = await newCommitRes.json();

  // 11. Update ref
  const updateRefRes = await githubFetch(`/repos/${owner}/${repoName}/git/refs/heads/${encodedBranch}`, token, {
    method: 'PATCH',
    body: JSON.stringify({ sha: newCommitData.sha, force: true })
  });
  if (!updateRefRes.ok) throw new Error('Failed to update ref: ' + updateRefRes.status);

  // 12. Enable GitHub Pages (legacy mode = serve directly from branch)
  const pagesRes = await githubFetch(`/repos/${owner}/${repoName}/pages`, token, {
    method: 'POST',
    body: JSON.stringify({
      source: { branch: defaultBranch, path: '/' },
      build_type: 'legacy'
    })
  });
  if (pagesRes.status === 409) {
    // Already enabled — update source to make sure it's correct
    const putRes = await githubFetch(`/repos/${owner}/${repoName}/pages`, token, {
      method: 'PUT',
      body: JSON.stringify({
        source: { branch: defaultBranch, path: '/' },
        build_type: 'legacy'
      })
    });
    if (!putRes.ok) {
      console.warn('GitHub Pages PUT failed (status ' + putRes.status + '), Pages may activate later');
    }
  } else if (!pagesRes.ok && pagesRes.status !== 201) {
    console.warn('GitHub Pages POST failed (status ' + pagesRes.status + '), Pages may activate later');
  }

  // 13. Return the URL
  return { url: pagesUrl, repo: `https://github.com/${owner}/${repoName}`, proxyRegisterError };
}

async function handleGitHubDeploy(code, pageId, screenshotDataUrl, files) {
  if (!code) return { error: 'NO_CODE' };
  if (!pageId) return { error: 'NO_PAGE' };
  try {
    const result = await githubDeploy(code, pageId, screenshotDataUrl, files);
    return { success: true, url: result.url, repo: result.repo, proxyRegisterError: result.proxyRegisterError || null };
  } catch (err) {
    if (err.message === 'GITHUB_TOKEN_EXPIRED') {
      return { error: 'GITHUB_TOKEN_EXPIRED' };
    }
    return { error: err.message || 'DEPLOY_FAILED' };
  }
}

function buildDeployHTML(code, ogBaseUrl, files, bootstrapScript) {
  return utils.buildHTML(code, files, {
    mode: 'deploy',
    libUrls: {
      tailwind: sharedCdnUrls.tailwind,
      react: sharedCdnUrls.react,
      reactDom: sharedCdnUrls.reactDom,
      babel: sharedCdnUrls.babel
    },
    ogBaseUrl: ogBaseUrl,
    bootstrapScript: bootstrapScript || null
  });
}

// === 정적 배포용 헬퍼 ===

// Notion S3 이미지 URL을 모두 다운로드해 assets/ 파일로 변환.
// urlToAsset: { S3_URL → 'assets/img-xxx.ext' }
async function downloadNotionImages(dataMap) {
  const S3_RE = /https:\/\/prod-files-secure\.s3\.amazonaws\.com\/[^"'\s<>]+/g;
  const allUrls = [...new Set(JSON.stringify(dataMap).match(S3_RE) || [])];
  const urlToAsset = {};
  const assetFiles = [];

  await Promise.all(allUrls.map(async (url) => {
    try {
      const res = await fetch(url);
      if (!res.ok) return;
      const ct = res.headers.get('content-type') || '';
      const ext = ct.includes('png') ? 'png' : ct.includes('webp') ? 'webp'
        : ct.includes('gif') ? 'gif' : ct.includes('svg') ? 'svg' : 'jpg';
      const buf = await res.arrayBuffer();
      const bytes = new Uint8Array(buf);
      let bin = '';
      for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      const b64 = btoa(bin);
      let h = 0;
      for (let i = 0; i < url.length; i++) h = Math.imul(31, h) + url.charCodeAt(i) | 0;
      const hash = Math.abs(h).toString(36).padStart(8, '0');
      const assetPath = `assets/img-${hash}.${ext}`;
      urlToAsset[url] = assetPath;
      assetFiles.push({ path: assetPath, content: b64, encoding: 'base64' });
    } catch { /* S3 URL 만료 또는 네트워크 오류 — 건너뜀 */ }
  }));

  return { urlToAsset, assetFiles };
}

// 배포된 GitHub Pages용 fetch 인터셉터.
// misiso.com 프록시 경유 — DB 데이터를 HTML에 박지 않음 (보안).
// urlToAsset: { S3_URL → 'assets/img-xxx.ext' } — 프록시 응답에서 만료되는 S3 URL을 로컬 assets/로 교체.
function buildDeployInterceptorScript(deployKey, urlToAsset) {
  const safeKey = JSON.stringify(deployKey || null);
  const safeAssets = JSON.stringify(urlToAsset && Object.keys(urlToAsset).length > 0 ? urlToAsset : null);
  return [
    '<script>',
    '(function(){',
    '  var __k=' + safeKey + ';',
    '  var __a=' + safeAssets + ';',
    '  if(!__k)return;',
    '  var _f=window.fetch;',
    '  function patchUrls(data){',
    '    if(!__a)return data;',
    '    try{',
    '      var s=JSON.stringify(data);',
    '      var keys=Object.keys(__a);',
    '      for(var i=0;i<keys.length;i++){s=s.split(keys[i]).join(__a[keys[i]]);}',
    '      return JSON.parse(s);',
    '    }catch(e){return data;}',
    '  }',
    '  window.fetch=function(url,opts){',
    '    var u=typeof url==="string"?url:String(url);',
    '    if(!u.startsWith("/api/notion/"))return _f.apply(this,arguments);',
    '    var path=u.slice("/api/notion".length);',
    '    var method=(opts&&opts.method)||"GET";',
    '    var body;',
    '    try{body=opts&&opts.body?JSON.parse(opts.body):undefined;}catch(e){body=opts&&opts.body;}',
    '    return _f("https://misiso.com/api/notion/deploy-proxy",{',
    '      method:"POST",',
    '      headers:{"Content-Type":"application/json"},',
    '      body:JSON.stringify({deployKey:__k,path:path,method:method,body:body})',
    '    }).then(function(r){',
    '      var status=r.status;',
    '      return r.json().then(function(data){',
    '        return new Response(JSON.stringify(patchUrls(data)),{',
    '          status:status,',
    '          headers:{"Content-Type":"application/json"}',
    '        });',
    '      });',
    '    });',
    '  };',
    '})();',
    '<\/script>'
  ].join('\n');
}

// === 설치/업데이트 시 토큰 없으면 misiso.com으로 안내 ===
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason !== 'install') return;
  const { notionToken } = await chrome.storage.local.get('notionToken');
  if (!notionToken) {
    chrome.tabs.create({ url: 'https://misiso.com/gifts/code-previewer/setup' });
  }
});

// === Side Panel: 노션 페이지에서만 활성화 ===
// 기본값: 비활성화. 노션 페이지 탭에서만 활성화
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
chrome.sidePanel.setOptions({ enabled: false });

function isNotionUrl(url) {
  if (!url) return false;
  try {
    const hostname = new URL(url).hostname;
    return hostname === 'www.notion.so' || hostname === 'notion.so' || hostname === 'notion.site' || hostname.endsWith('.notion.site');
  } catch {
    return false;
  }
}

function updateSidePanelForTab(tabId, url) {
  const enabled = isNotionUrl(url);
  chrome.sidePanel.setOptions({ tabId, path: 'sidepanel/index.html', enabled }).catch(() => {});
}

// 탭 URL 변경 시
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    updateSidePanelForTab(tabId, changeInfo.url);
  }
});

// 탭 전환 시
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    updateSidePanelForTab(activeInfo.tabId, tab.url);
  } catch {}
});
