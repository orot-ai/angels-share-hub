// popup/popup.js
(function () {
  'use strict';

  const statusBadge = document.getElementById('status-badge');

  function updateStatus(hasToken) {
    if (hasToken) {
      statusBadge.textContent = 'Connected';
      statusBadge.className = 'status-badge connected';
    } else {
      statusBadge.textContent = 'Not connected';
      statusBadge.className = 'status-badge disconnected';
    }
  }

  // Open side panel
  document.getElementById('open-sidepanel').addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    // H-O3: chrome.tabs.query가 빈 결과를 반환할 수 있음
    if (!tabs || tabs.length === 0) {
      console.warn('No active tab found');
      window.close();
      return;
    }
    const tab = tabs[0];
    if (tab?.id) {
      try {
        await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: true });
        await chrome.sidePanel.open({ tabId: tab.id });
        window.close();
      } catch (err) {
        // fallback: windowId로 열기
        try {
          const win = await chrome.windows.getCurrent();
          await chrome.sidePanel.open({ windowId: win.id });
        } catch (fallbackErr) {
          console.error('Failed to open side panel via windowId fallback:', fallbackErr);
        }
        window.close();
      }
    }
  });

  // 초기 상태 확인
  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
    if (chrome.runtime.lastError || !response) return;
    updateStatus(response.hasToken);
  });
})();
